/**
 * Standalone Popup Blocker — no browser extension needed.
 *
 * Adapted from the ppop extension content-script.
 * Changes vs. the original:
 *  - Removed all port / CustomEvent / chrome-extension communication.
 *  - policy() always returns { block: true } for every popup / external
 *    navigation attempt — no remote decision needed.
 *  - simulate() returns a harmless Proxy window-lookalike (no recording).
 *  - aggressive is hard-wired to 3 (full mutation + frame protection).
 *  - The script is injected as early as possible (see layout.tsx).
 */
(function () {
  "use strict";

  /* ------------------------------------------------------------------ */
  /* Policy: always block popups / external navigation                   */
  /* ------------------------------------------------------------------ */
  /**
   * @param {string}      type    - event type label (unused, kept for parity)
   * @param {Element}     element - the element that triggered the action
   * @param {Event|null}  event   - the original DOM event (may be null)
   * @param {object}      extra   - additional metadata (unused here)
   * @returns {{ block: boolean }}
   */
  const policy = (type, element, event, extra = {}) => {
    /* ---- decide whether this navigation should be blocked ---- */

    const href =
      (element && (element.action || element.href)) || "";
    const target =
      (element && element.target) || "";

    // Always block window.open calls
    if (type === "window.open") {
      return { block: true };
    }

    // Block clicks / submits that open a new tab / window
    if (
      target === "_blank" ||
      target === "_new" ||
      /^https?:\/\//i.test(href)   // absolute external URL
    ) {
      return { block: true };
    }

    return { block: false };
  };

  /* ------------------------------------------------------------------ */
  /* Simulate a fake window so scripts that rely on window.open's return  */
  /* value don't crash.                                                   */
  /* ------------------------------------------------------------------ */
  const simulate = (root = {}, tree = []) =>
    new Proxy(root, {
      get(obj, key) {
        if (typeof root[key] === "function") {
          return function (...args) {
            /* swallow the call silently */
          };
        }
        return simulate(root[key] !== undefined ? root[key] : {}, [
          ...tree,
          key,
        ]);
      },
      set(obj, key, value) {
        return true; // silently accept all writes
      },
    });

  /* ------------------------------------------------------------------ */
  /* Core blocker                                                         */
  /* ------------------------------------------------------------------ */
  const aggressive = 3; // 1 = basic | 2 = +frame | 3 = +mutation
  const protected_ = new WeakMap(); // tracks already-instrumented windows

  const blocker = {};

  /* --- protect javascript:/data: iframes when their src is set --- */
  blocker.frame = (target) => {
    const { src, tagName } = target;
    if (src && (tagName === "IFRAME" || tagName === "FRAME")) {
      const s = src.toLowerCase();
      if (s.startsWith("javascript:") || s.startsWith("data:")) {
        try {
          blocker.install(target.contentWindow);
        } catch (e) { }
      }
    }
  };

  /* --- click interceptor (capture phase) --- */
  blocker.onclick = (e) => {
    const a = e.target.closest("[target]") || e.target.closest("a");
    if (a && policy("element.click", a, e).block) {
      MouseEvent.prototype.preventDefault.call(e);
      return true;
    }
  };

  /* --- install all protections into a given window object --- */
  blocker.install = (w = window) => {
    if (protected_.has(w)) return;

    let d;
    try {
      d = w.document;
      // Cross-origin frames throw on document access — skip them
      void d.documentElement;
    } catch (e) {
      return;
    }

    protected_.set(w, true);

    /* ---- Anchor click / dispatch proxy ---- */
    const { HTMLAnchorElement, HTMLFormElement } = w;

    HTMLAnchorElement.prototype.click = new Proxy(
      HTMLAnchorElement.prototype.click,
      {
        apply(target, self, args) {
          const { block } = policy("dynamic.a.click", self, null);
          return block ? undefined : Reflect.apply(target, self, args);
        },
      }
    );

    HTMLAnchorElement.prototype.dispatchEvent = new Proxy(
      HTMLAnchorElement.prototype.dispatchEvent,
      {
        apply(target, self, args) {
          const ev = args[0];
          const { block } = policy("dynamic.a.dispatch", self, ev);
          return block ? false : Reflect.apply(target, self, args);
        },
      }
    );

    /* ---- Form submit proxy ---- */
    HTMLFormElement.prototype.submit = new Proxy(
      HTMLFormElement.prototype.submit,
      {
        apply(target, self, args) {
          const { block } = policy("dynamic.form.submit", self, null);
          return block ? false : Reflect.apply(target, self, args);
        },
      }
    );

    HTMLFormElement.prototype.dispatchEvent = new Proxy(
      HTMLFormElement.prototype.dispatchEvent,
      {
        apply(target, self, args) {
          const { block } = policy("dynamic.form.dispatch", self, null);
          return block ? false : Reflect.apply(target, self, args);
        },
      }
    );

    /* ---- iframe / frame contentWindow + contentDocument protection ---- */
    if (aggressive > 1) {
      const { HTMLIFrameElement, HTMLFrameElement } = w;

      const wf = Object.getOwnPropertyDescriptor(
        HTMLFrameElement.prototype,
        "contentWindow"
      );
      Object.defineProperty(HTMLFrameElement.prototype, "contentWindow", {
        configurable: true,
        enumerable: true,
        get() {
          const cw = wf.get.call(this);
          try { blocker.install(cw); } catch (e) { }
          return cw;
        },
      });

      const wif = Object.getOwnPropertyDescriptor(
        HTMLIFrameElement.prototype,
        "contentWindow"
      );
      Object.defineProperty(HTMLIFrameElement.prototype, "contentWindow", {
        configurable: true,
        enumerable: true,
        get() {
          const cw = wif.get.call(this);
          try { blocker.install(cw); } catch (e) { }
          return cw;
        },
      });

      const cf = Object.getOwnPropertyDescriptor(
        HTMLFrameElement.prototype,
        "contentDocument"
      );
      Object.defineProperty(HTMLFrameElement.prototype, "contentDocument", {
        configurable: true,
        enumerable: true,
        get() {
          const cd = cf.get.call(this);
          try { blocker.install(cd.defaultView); } catch (e) { }
          return cd;
        },
      });

      const cif = Object.getOwnPropertyDescriptor(
        HTMLIFrameElement.prototype,
        "contentDocument"
      );
      Object.defineProperty(HTMLIFrameElement.prototype, "contentDocument", {
        configurable: true,
        enumerable: true,
        get() {
          const cd = cif.get.call(this);
          try { blocker.install(cd.defaultView); } catch (e) { }
          return cd;
        },
      });
    }

    /* ---- MutationObserver for dynamically injected iframes ---- */
    if (aggressive > 2) {
      new MutationObserver((mutations) => {
        for (const m of mutations) {
          for (const node of m.addedNodes) {
            if (node.nodeType !== 1) continue; // element nodes only
            blocker.frame(node);
            if (node.childElementCount) {
              node.querySelectorAll("iframe,frame").forEach(blocker.frame);
            }
          }
        }
      }).observe(d, { childList: true, subtree: true });
    }

    /* ---- Capture-phase click listener ---- */
    d.addEventListener("click", blocker.onclick, true);

    /* ---- window.open proxy ---- */
    w.open = new Proxy(w.open, {
      apply(target, self, args) {
        // Allow opens that target a named frame that already exists
        const name = args[1];
        if (name && typeof name === "string" && w.frames[name]) {
          return Reflect.apply(target, self, args);
        }

        const { block } = policy(
          "window.open",
          { href: args.length ? args[0] : "" },
          null,
          { args }
        );

        if (block) {
          // Return a fake window-like Proxy so scripts don't throw on the
          // return value (e.g. popup.location = …)
          return simulate(w);
        }

        return Reflect.apply(target, self, args);
      },
    });

    /* ---- Guard against document.write resetting the DOM listeners ---- */
    let dHTML = d.documentElement;
    d.write = new Proxy(d.write, {
      apply(target, self, args) {
        const r = Reflect.apply(target, self, args);
        if (dHTML !== self.documentElement) {
          dHTML = self.documentElement;
          self.addEventListener("click", blocker.onclick, true);
        }
        return r;
      },
    });
  };

  /* ------------------------------------------------------------------ */
  /* Bootstrap — protect the top-level window immediately               */
  /* ------------------------------------------------------------------ */
  blocker.install();
})();
