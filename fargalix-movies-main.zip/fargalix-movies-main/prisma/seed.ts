import { config } from "dotenv";

// tsx doesn't auto-load .env — do it manually before anything reads process.env
config();

import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";
import bcrypt from "bcryptjs";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

async function main() {
  // ─── Default site settings ───────────────────────────────────────────────
  const settings = [
    {
      key: "default_player",
      value: "vidfast",
      label: "Default Video Player",
      description: 'Choose the default player shown to users. Either "vidfast" or "vidsrc".',
    },
    {
      key: "site_name",
      value: "StreamVault",
      label: "Site Name",
      description: "Displayed in the browser tab and branding.",
    },
    {
      key: "maintenance_mode",
      value: "false",
      label: "Maintenance Mode",
      description: 'When "true", only admins can access the site.',
    },
    {
      key: "allow_registration",
      value: "true",
      label: "Allow Registration",
      description: 'When "false", new users cannot sign up.',
    },
  ];

  for (const s of settings) {
    await prisma.siteSetting.upsert({
      where: { key: s.key },
      update: {},
      create: { key: s.key, value: s.value, label: s.label, description: s.description },
    });
  }

  console.log("✓ Site settings seeded");

  // ─── Default admin user ───────────────────────────────────────────────────
  const adminEmail = "admin@streamvault.com";
  const existing = await prisma.user.findUnique({ where: { email: adminEmail } });

  if (!existing) {
    const hashed = await bcrypt.hash("Admin@123!", 12);
    await prisma.user.create({
      data: {
        email: adminEmail,
        username: "admin",
        password: hashed,
        role: "ADMIN",
      },
    });
    console.log("✓ Default admin created — email: admin@streamvault.com  password: Admin@123!");
    console.log("  ⚠  Change this password immediately after first login.");
  } else {
    console.log("✓ Admin user already exists — skipped");
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
