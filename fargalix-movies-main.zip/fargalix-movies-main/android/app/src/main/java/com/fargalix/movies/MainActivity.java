package com.fargalix.movies;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
