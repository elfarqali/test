const STORAGE_KEY = "sv_watch_history";
const MAX_ITEMS = 20;

export interface WatchItem {
  id: number;
  media_type: "movie" | "tv";
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  season?: number;
  episode?: number;
  timestamp: number;
}

export function getWatchHistory(): WatchItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as WatchItem[]) : [];
  } catch {
    return [];
  }
}

export function addToWatchHistory(item: Omit<WatchItem, "timestamp">) {
  if (typeof window === "undefined") return;
  try {
    const history = getWatchHistory().filter(
      (h) => !(h.id === item.id && h.media_type === item.media_type)
    );
    history.unshift({ ...item, timestamp: Date.now() });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history.slice(0, MAX_ITEMS)));
  } catch {
    // storage not available — silently skip
  }
}

export function removeFromWatchHistory(id: number, media_type: "movie" | "tv") {
  if (typeof window === "undefined") return;
  try {
    const history = getWatchHistory().filter(
      (h) => !(h.id === id && h.media_type === media_type)
    );
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  } catch {
    // storage not available — silently skip
  }
}
