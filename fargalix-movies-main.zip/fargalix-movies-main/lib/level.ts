/**
 * Level System — based on total watch time.
 *
 * Formula: Total hours required to REACH level N = N*(N-1)/2
 *   Level 1 → 2 requires 1 h  (total to be level 2 = 1 h)
 *   Level 2 → 3 requires 2 h  (total to be level 3 = 3 h)
 *   Level 3 → 4 requires 3 h  (total to be level 4 = 6 h)
 *   ...
 *   Level N → N+1 requires N h
 *
 * Inverse (level from hours H):
 *   Solve N*(N-1)/2 ≤ H  →  N = floor((1 + sqrt(1 + 8H)) / 2)
 */

export interface LevelData {
  level: number;               // current level (1–100)
  totalHours: number;          // total hours watched (rounded 1 dp)
  hoursAtCurrentLevel: number; // hours accumulated within current level
  hoursNeeded: number;         // hours span of current level (= level number)
  progressPercent: number;     // 0–100 % progress to next level
  isMaxLevel: boolean;
}

export function getLevelData(totalMinutes: number): LevelData {
  const hours = totalMinutes / 60;

  const rawLevel = Math.floor((1 + Math.sqrt(1 + 8 * hours)) / 2);
  const level = Math.min(Math.max(rawLevel, 1), 100);
  const isMaxLevel = level >= 100;

  // Hours required to reach current level
  const hoursToCurrentLevel = (level * (level - 1)) / 2;
  // Hours required to reach next level
  const hoursToNextLevel = (level * (level + 1)) / 2;
  // Span for this level
  const hoursNeeded = level; // = hoursToNextLevel - hoursToCurrentLevel
  // Progress within current level
  const hoursAtCurrentLevel = Math.max(hours - hoursToCurrentLevel, 0);
  const progressPercent = isMaxLevel
    ? 100
    : Math.min((hoursAtCurrentLevel / hoursNeeded) * 100, 100);

  return {
    level,
    totalHours: Math.round(hours * 10) / 10,
    hoursAtCurrentLevel: Math.round(hoursAtCurrentLevel * 10) / 10,
    hoursNeeded,
    progressPercent: Math.round(progressPercent * 10) / 10,
    isMaxLevel,
  };
}

/**
 * Estimate total watch minutes from ContinueWatching records.
 * Uses average content duration as a proxy.
 */
export function estimateWatchMinutes(
  records: Array<{ mediaType: string; progress: number }>
): number {
  return records.reduce((total, item) => {
    const avgDuration = item.mediaType === "MOVIE" ? 95 : 42; // minutes
    return total + (item.progress / 100) * avgDuration;
  }, 0);
}
