export interface TMDBMediaItem {
  id: number;
  title?: string;
  name?: string;
  poster_path: string | null;
  backdrop_path?: string | null;
  vote_average: number;
  release_date?: string;
  first_air_date?: string;
  media_type?: "movie" | "tv" | "person";
  overview: string;
}

export interface TMDBResponse {
  page: number;
  results: TMDBMediaItem[];
  total_pages: number;
  total_results: number;
}

export interface TMDBGenre {
  id: number;
  name: string;
}

export interface TMDBCastMember {
  id: number;
  name: string;
  character: string;
  profile_path: string | null;
  order: number;
}

export interface TMDBCrewMember {
  id: number;
  name: string;
  job: string;
  department: string;
  profile_path: string | null;
}

export interface TMDBCredits {
  cast: TMDBCastMember[];
  crew: TMDBCrewMember[];
}

export interface TMDBVideo {
  id: string;
  key: string;
  name: string;
  site: string;
  type: string;
  official: boolean;
}

export interface TMDBMovieDetail {
  id: number;
  title: string;
  original_title: string;
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  vote_average: number;
  vote_count: number;
  release_date: string;
  runtime: number | null;
  genres: TMDBGenre[];
  status: string;
  tagline: string;
  budget: number;
  revenue: number;
  production_countries: { iso_3166_1: string; name: string }[];
  spoken_languages: { iso_639_1: string; name: string }[];
  imdb_id: string | null;
}

export interface TMDBTVSeason {
  id: number;
  season_number: number;
  name: string;
  episode_count: number;
  poster_path: string | null;
  air_date: string | null;
}

export interface TMDBTVDetail {
  id: number;
  name: string;
  original_name: string;
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  vote_average: number;
  vote_count: number;
  first_air_date: string;
  last_air_date: string;
  number_of_seasons: number;
  number_of_episodes: number;
  genres: TMDBGenre[];
  status: string;
  tagline: string;
  seasons: TMDBTVSeason[];
  episode_run_time: number[];
  networks: { id: number; name: string; logo_path: string | null }[];
  origin_country: string[];
  production_countries: { iso_3166_1: string; name: string }[];
}

export interface TMDBTVEpisode {
  id: number;
  name: string;
  overview: string;
  episode_number: number;
  season_number: number;
  still_path: string | null;
  vote_average: number;
  air_date: string;
  runtime: number | null;
}

export interface TMDBSeasonDetail {
  id: number;
  season_number: number;
  name: string;
  overview: string;
  poster_path: string | null;
  air_date: string | null;
  episodes: TMDBTVEpisode[];
}

const BASE_URL = "https://api.themoviedb.org/3";
export const IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w500";
// w1280 is visually indistinguishable from /original on any current display
// but is 4-8× smaller in file size — a huge win for hero images.
export const IMAGE_BACKDROP_URL = "https://image.tmdb.org/t/p/w1280";
export const IMAGE_W300_URL = "https://image.tmdb.org/t/p/w300";

const EMPTY_RESPONSE: TMDBResponse = {
  page: 1,
  results: [],
  total_pages: 1,
  total_results: 0,
};

function buildUrl(endpoint: string, params: Record<string, string | number>): string {
  const bearerToken = process.env.NEXT_PUBLIC_TMDB_TOKEN;
  const apiKey = process.env.NEXT_PUBLIC_TMDB_API_KEY;
  const hasBearer = bearerToken && bearerToken !== "your_tmdb_read_access_token_here";
  const hasApiKey = apiKey && apiKey !== "your_tmdb_api_key_here";

  const searchParams = new URLSearchParams();
  if (!hasBearer && hasApiKey) {
    searchParams.set("api_key", apiKey!);
  }
  for (const [key, value] of Object.entries(params)) {
    searchParams.set(key, String(value));
  }

  return `${BASE_URL}${endpoint}?${searchParams.toString()}`;
}

function buildHeaders(): HeadersInit {
  const bearerToken = process.env.NEXT_PUBLIC_TMDB_TOKEN;
  const hasBearer = bearerToken && bearerToken !== "your_tmdb_read_access_token_here";
  return hasBearer
    ? { Authorization: `Bearer ${bearerToken}`, "Content-Type": "application/json" }
    : {};
}

function hasCredentials(): boolean {
  const bearerToken = process.env.NEXT_PUBLIC_TMDB_TOKEN;
  const apiKey = process.env.NEXT_PUBLIC_TMDB_API_KEY;
  const hasBearer = bearerToken && bearerToken !== "your_tmdb_read_access_token_here";
  const hasApiKey = apiKey && apiKey !== "your_tmdb_api_key_here";
  return !!(hasBearer || hasApiKey);
}

async function tmdbFetch(
  endpoint: string,
  params: Record<string, string | number> = {}
): Promise<TMDBResponse> {
  if (!hasCredentials()) {
    console.error("TMDB credentials not configured. Add NEXT_PUBLIC_TMDB_TOKEN or NEXT_PUBLIC_TMDB_API_KEY to .env.local");
    return EMPTY_RESPONSE;
  }

  const url = buildUrl(endpoint, params);
  const headers = buildHeaders();

  try {
    const response = await fetch(url, {
      headers,
      next: { revalidate: 21600 },
    });

    if (!response.ok) {
      console.error(`TMDB API error: ${response.status} ${response.statusText} for ${endpoint}`);
      return EMPTY_RESPONSE;
    }

    const data = (await response.json()) as TMDBResponse;

    // Filter out unreleased titles from list arrays so they don't show up on UI
    if (data.results && Array.isArray(data.results)) {
      const today = new Date().toISOString().split("T")[0]; // "YYYY-MM-DD"
      data.results = data.results.filter((item) => {
        // Skip filtering non-media items or if media_type is person
        if (item.media_type === "person") return true;

        // Grab release date string (TMDB format: YYYY-MM-DD)
        const d = item.release_date || item.first_air_date;

        // If TMDB hasn't set a release date at all, it's definitely unreleased
        if (!d || d.trim() === "") return false;

        // Only keep if the release date is today or in the past
        return d <= today;
      });
    }

    return data;
  } catch (error) {
    console.error(`TMDB fetch failed for ${endpoint}:`, error);
    return EMPTY_RESPONSE;
  }
}

/**
 * Fetch multiple pages and merge results into one flat array.
 * Deduplicates by id.
 */
async function fetchMergedPages(
  endpoint: string,
  pages: number[],
  extraParams: Record<string, string | number> = {}
): Promise<TMDBMediaItem[]> {
  const responses = await Promise.all(
    pages.map((p) => tmdbFetch(endpoint, { page: p, ...extraParams }))
  );
  const seen = new Set<number>();
  const merged: TMDBMediaItem[] = [];
  for (const res of responses) {
    for (const item of res.results) {
      if (!seen.has(item.id)) {
        seen.add(item.id);
        merged.push(item);
      }
    }
  }
  return merged;
}

// ─── Single-page fetchers (used by list pages with pagination) ───────────────

export async function getTrending(page: number = 1): Promise<TMDBResponse> {
  return tmdbFetch("/trending/all/week", { page });
}

export async function getPopularMovies(page: number = 1): Promise<TMDBResponse> {
  return tmdbFetch("/movie/popular", { page });
}

export async function getPopularSeries(page: number = 1): Promise<TMDBResponse> {
  return tmdbFetch("/tv/popular", { page });
}

export async function getNowPlayingMovies(page: number = 1): Promise<TMDBResponse> {
  return tmdbFetch("/movie/now_playing", { page });
}

export async function getTopRatedMovies(page: number = 1): Promise<TMDBResponse> {
  return tmdbFetch("/movie/top_rated", { page });
}

export async function getTopRatedSeries(page: number = 1): Promise<TMDBResponse> {
  return tmdbFetch("/tv/top_rated", { page });
}

export async function getTrendingMovies(page: number = 1): Promise<TMDBResponse> {
  return tmdbFetch("/trending/movie/week", { page });
}

export async function getTrendingSeries(page: number = 1): Promise<TMDBResponse> {
  return tmdbFetch("/trending/tv/week", { page });
}

// ─── Multi-page merged fetchers (used by homepage rows for 60+ items) ────────

export async function getTrendingMerged(): Promise<TMDBMediaItem[]> {
  const items = await fetchMergedPages("/trending/all/week", [1, 2]);
  return items.filter((i) => i.media_type !== "person");
}

export async function getPopularMoviesMerged(): Promise<TMDBMediaItem[]> {
  return fetchMergedPages("/movie/popular", [1, 2]);
}

export async function getPopularSeriesMerged(): Promise<TMDBMediaItem[]> {
  return fetchMergedPages("/tv/popular", [1, 2]);
}

export async function getNowPlayingMerged(): Promise<TMDBMediaItem[]> {
  return fetchMergedPages("/movie/now_playing", [1, 2]);
}

export async function getTopRatedMoviesMerged(): Promise<TMDBMediaItem[]> {
  return fetchMergedPages("/movie/top_rated", [1, 2]);
}

export async function getTopRatedSeriesMerged(): Promise<TMDBMediaItem[]> {
  return fetchMergedPages("/tv/top_rated", [1, 2]);
}

// ─── Search ───────────────────────────────────────────────────────────────────

export async function searchMulti(query: string, page: number = 1): Promise<TMDBResponse> {
  if (!query.trim()) return EMPTY_RESPONSE;
  return tmdbFetch("/search/multi", { query: encodeURIComponent(query), page });
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

export function getMediaTitle(item: TMDBMediaItem): string {
  return item.title ?? item.name ?? "Untitled";
}

export function getMediaYear(item: TMDBMediaItem): string {
  const date = item.release_date ?? item.first_air_date ?? "";
  return date ? new Date(date).getFullYear().toString() : "N/A";
}

export function getMediaType(item: TMDBMediaItem): string {
  if (item.media_type === "tv") return "Series";
  if (item.media_type === "movie") return "Movie";
  if (item.title) return "Movie";
  if (item.name) return "Series";
  return "Movie";
}

// ─── Detail fetchers ──────────────────────────────────────────────────────────

export async function getMovieDetail(id: string | number): Promise<TMDBMovieDetail | null> {
  if (!hasCredentials()) return null;
  const url = buildUrl(`/movie/${parseInt(String(id), 10)}`, { language: "en-US" });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return null;
    return res.json() as Promise<TMDBMovieDetail>;
  } catch {
    return null;
  }
}

export async function getTVDetail(id: string | number): Promise<TMDBTVDetail | null> {
  if (!hasCredentials()) return null;
  const url = buildUrl(`/tv/${parseInt(String(id), 10)}`, { language: "en-US" });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return null;
    return res.json() as Promise<TMDBTVDetail>;
  } catch {
    return null;
  }
}

export async function getMovieCredits(id: string | number): Promise<TMDBCredits> {
  if (!hasCredentials()) return { cast: [], crew: [] };
  const url = buildUrl(`/movie/${parseInt(String(id), 10)}/credits`, { language: "en-US" });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return { cast: [], crew: [] };
    return res.json() as Promise<TMDBCredits>;
  } catch {
    return { cast: [], crew: [] };
  }
}

export async function getTVCredits(id: string | number): Promise<TMDBCredits> {
  if (!hasCredentials()) return { cast: [], crew: [] };
  const url = buildUrl(`/tv/${parseInt(String(id), 10)}/credits`, { language: "en-US" });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return { cast: [], crew: [] };
    return res.json() as Promise<TMDBCredits>;
  } catch {
    return { cast: [], crew: [] };
  }
}

export async function getMovieVideos(id: string | number): Promise<TMDBVideo[]> {
  if (!hasCredentials()) return [];
  const url = buildUrl(`/movie/${parseInt(String(id), 10)}/videos`, { language: "en-US" });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return [];
    const data = await res.json() as { results: TMDBVideo[] };
    return data.results ?? [];
  } catch {
    return [];
  }
}

export async function getTVVideos(id: string | number): Promise<TMDBVideo[]> {
  if (!hasCredentials()) return [];
  const url = buildUrl(`/tv/${parseInt(String(id), 10)}/videos`, { language: "en-US" });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return [];
    const data = await res.json() as { results: TMDBVideo[] };
    return data.results ?? [];
  } catch {
    return [];
  }
}

export async function getTVSeasonDetail(
  tvId: string | number,
  season: number
): Promise<TMDBSeasonDetail | null> {
  if (!hasCredentials()) return null;
  const url = buildUrl(`/tv/${parseInt(String(tvId), 10)}/season/${season}`, { language: "en-US" });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return null;
    return res.json() as Promise<TMDBSeasonDetail>;
  } catch {
    return null;
  }
}

export async function getSimilarMovies(id: string | number): Promise<TMDBMediaItem[]> {
  if (!hasCredentials()) return [];
  const url = buildUrl(`/movie/${parseInt(String(id), 10)}/similar`, { language: "en-US", page: 1 });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return [];
    const data = await res.json() as TMDBResponse;
    return (data.results ?? []).map((i) => ({ ...i, media_type: "movie" as const }));
  } catch {
    return [];
  }
}

export async function getSimilarTV(id: string | number): Promise<TMDBMediaItem[]> {
  if (!hasCredentials()) return [];
  const url = buildUrl(`/tv/${parseInt(String(id), 10)}/similar`, { language: "en-US", page: 1 });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return [];
    const data = await res.json() as TMDBResponse;
    return (data.results ?? []).map((i) => ({ ...i, media_type: "tv" as const }));
  } catch {
    return [];
  }
}

export async function getTVKeywords(
  id: string | number
): Promise<{ id: number; name: string }[]> {
  if (!hasCredentials()) return [];
  const url = buildUrl(`/tv/${parseInt(String(id), 10)}/keywords`, {});
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return [];
    const data = await res.json() as { results: { id: number; name: string }[] };
    return data.results ?? [];
  } catch {
    return [];
  }
}

export async function getMovieKeywords(
  id: string | number
): Promise<{ id: number; name: string }[]> {
  if (!hasCredentials()) return [];
  const url = buildUrl(`/movie/${parseInt(String(id), 10)}/keywords`, {});
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return [];
    // Movie keywords use "keywords" key (TV uses "results")
    const data = await res.json() as { keywords: { id: number; name: string }[] };
    return data.keywords ?? [];
  } catch {
    return [];
  }
}

// ─── Combined detail fetchers using append_to_response ────────────────────────
// These collapse 5 separate TMDB API calls into a SINGLE request, dramatically
// reducing serverless function CPU time and external fetch overhead.

export interface MovieFullDetail extends TMDBMovieDetail {
  credits: TMDBCredits;
  videos: { results: TMDBVideo[] };
  similar: { results: TMDBMediaItem[] };
  keywords: { keywords: { id: number; name: string }[] };
}

export interface TVFullDetail extends TMDBTVDetail {
  credits: TMDBCredits;
  videos: { results: TMDBVideo[] };
  similar: { results: TMDBMediaItem[] };
  keywords: { results: { id: number; name: string }[] };
}

/**
 * Fetch movie detail + credits + videos + similar + keywords in ONE API call.
 * Replaces 5 separate fetches with 1 — reduces CPU time by ~80% on movie pages.
 */
export async function getMovieFullDetail(id: string | number): Promise<MovieFullDetail | null> {
  if (!hasCredentials()) return null;
  const numericId = parseInt(String(id), 10);
  const url = buildUrl(`/movie/${numericId}`, {
    language: "en-US",
    append_to_response: "credits,videos,similar,keywords",
  });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return null;
    return res.json() as Promise<MovieFullDetail>;
  } catch {
    return null;
  }
}

/**
 * Fetch TV detail + credits + videos + similar + keywords in ONE API call.
 * Replaces 5 separate fetches with 1 — reduces CPU time by ~80% on TV pages.
 */
export async function getTVFullDetail(id: string | number): Promise<TVFullDetail | null> {
  if (!hasCredentials()) return null;
  const numericId = parseInt(String(id), 10);
  const url = buildUrl(`/tv/${numericId}`, {
    language: "en-US",
    append_to_response: "credits,videos,similar,keywords",
  });
  try {
    const res = await fetch(url, { headers: buildHeaders(), next: { revalidate: 86400 } });
    if (!res.ok) return null;
    return res.json() as Promise<TVFullDetail>;
  } catch {
    return null;
  }
}

