/**
 * Edge-safe session helpers — no Node.js APIs, no `pg` / Prisma / jose imports.
 * Uses only globalThis.crypto (Web Crypto API), available in all Edge runtimes.
 * Import this file from middleware; use `@/lib/session` everywhere else.
 */
import { NextRequest } from "next/server";

export const SESSION_COOKIE = "sv_session";

export interface SessionPayload {
  userId: string;
  email: string;
  username: string;
  role: "USER" | "ADMIN";
}

function b64urlDecode(str: string): Uint8Array {
  const base64 = str.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(base64);
  return Uint8Array.from(bin, (c) => c.charCodeAt(0));
}

async function verifyHS256(
  token: string,
  secret: string
): Promise<SessionPayload | null> {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;

    const [header, payload, signature] = parts;

    const key = await globalThis.crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"]
    );

    const valid = await globalThis.crypto.subtle.verify(
      "HMAC",
      key,
      b64urlDecode(signature) as any,
      new TextEncoder().encode(`${header}.${payload}`) as any
    );
    if (!valid) return null;

    const data = JSON.parse(
      new TextDecoder().decode(b64urlDecode(payload))
    ) as SessionPayload & { exp?: number };

    if (data.exp && data.exp < Math.floor(Date.now() / 1000)) return null;

    return {
      userId: data.userId,
      email: data.email,
      username: data.username,
      role: data.role,
    };
  } catch {
    return null;
  }
}

export async function getSessionFromRequest(
  req: NextRequest
): Promise<SessionPayload | null> {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const secret =
    process.env.JWT_SECRET ?? "dev_fallback_secret_please_change_me_32chars";
  return verifyHS256(token, secret);
}
