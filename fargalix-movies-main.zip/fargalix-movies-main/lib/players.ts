import { db } from "@/lib/db";
import { unstable_cache } from "next/cache";

// Cache the players list to prevent massive database queries
// from Next.js <Link> prefetching on the homepage.
export const getCachedPlayers = unstable_cache(
    async () => {
        try {
            const result = await db.player.findMany({
                where: { active: true },
                orderBy: [{ isDefault: "desc" }, { order: "asc" }, { createdAt: "asc" }],
                select: { id: true, name: true, movieUrl: true, tvUrl: true, isDefault: true },
            });
            if (!result || result.length === 0) {
                // Return a default player if database fails to return
                return [{
                    id: "default",
                    name: "Auto (Vidsrc)",
                    movieUrl: "https://vidsrc.me/embed/movie?tmdb={id}",
                    tvUrl: "https://vidsrc.me/embed/tv?tmdb={id}&season={season}&episode={episode}",
                    isDefault: true
                }];
            }
            return result;
        } catch (error) {
            console.error("Failed to fetch players:", error);
            // Return default player instead of empty array so player doesn't crash on refresh
            return [{
                id: "default",
                name: "Auto (Vidsrc)",
                movieUrl: "https://vidsrc.me/embed/movie?tmdb={id}",
                tvUrl: "https://vidsrc.me/embed/tv?tmdb={id}&season={season}&episode={episode}",
                isDefault: true
            }];
        }
    },
    ["active_players_cache"],
    { revalidate: 86400, tags: ["players"] } // 24 hours (matches page ISR)
);
