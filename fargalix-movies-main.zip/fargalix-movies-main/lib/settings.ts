import { db } from "@/lib/db";
import { unstable_cache } from "next/cache";

export const getSiteName = unstable_cache(
    async () => {
        try {
            const setting = await db.siteSetting.findUnique({ where: { key: "site_name" } });
            return setting?.value || "StreamVault";
        } catch {
            return "StreamVault";
        }
    },
    ["site_name_cache"],
    { tags: ["settings"], revalidate: 86400 }
);
