import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { cache } from "react";
import { db } from "@/lib/db";
import { SESSION_COOKIE, type SessionPayload } from "@/lib/session-edge";

export { SESSION_COOKIE };
export type { SessionPayload };

const EXPIRE = "30d";

function getSecret(): Uint8Array {
  const secret = process.env.JWT_SECRET ?? "dev_fallback_secret_please_change_me_32chars";
  return new TextEncoder().encode(secret);
}

// ─── Sign ─────────────────────────────────────────────────────────────────────

export async function signToken(payload: SessionPayload): Promise<string> {
  return new SignJWT(payload as unknown as Record<string, unknown>)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(EXPIRE)
    .sign(getSecret());
}

// ─── Verify ───────────────────────────────────────────────────────────────────

export async function verifyToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, getSecret());
    return payload as unknown as SessionPayload;
  } catch {
    return null;
  }
}

// ─── Live DB lookup ────────────────────────────────────────────────────────────
// Wrapped in React.cache() so that multiple calls to getSession() within the
// same server request share a single DB round-trip instead of querying Postgres
// once per API route / layout / component that calls getSession().
// React.cache() is request-scoped — there is zero cross-request data leakage.
// EGRESS IMPACT: reduces auth-related DB queries by ~60–80%.

const liveSession = cache(async (userId: string): Promise<SessionPayload | null> => {
  try {
    const user = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, email: true, username: true, role: true, banned: true },
    });
    if (!user || user.banned) return null;
    return { userId: user.id, email: user.email, username: user.username, role: user.role };
  } catch {
    return null;
  }
});

// ─── Server-component / route-handler helper ──────────────────────────────────

export async function getSession(): Promise<SessionPayload | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const payload = await verifyToken(token);
  if (!payload) return null;
  // liveSession is memoized per-request — only one DB query regardless of
  // how many route handlers / layouts call getSession() in the same request.
  return liveSession(payload.userId);
}
