"use server";

import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

export async function submitVideoReport(
    mediaId: number,
    mediaType: "MOVIE" | "TV",
    reason: string,
    season?: number,
    episode?: number
) {
    try {
        const session = await getSession();
        if (!session?.userId) {
            return { error: "You must be logged in to submit a report." };
        }

        if (!reason || reason.trim() === "") {
            return { error: "Please provide a reason for the report." };
        }

        // @ts-ignore
        await db.videoReport.create({
            data: {
                mediaId,
                mediaType,
                season,
                episode,
                reason,
                reporterId: session.userId,
            },
        });

        return { success: true };
    } catch (error) {
        console.error("[submitVideoReport error]", error);
        return { error: "Something went wrong while submitting the report." };
    }
}

export async function submitCommentReport(commentId: string, reason: string) {
    try {
        const session = await getSession();
        if (!session?.userId) {
            return { error: "You must be logged in to submit a report." };
        }

        if (!reason || reason.trim() === "") {
            return { error: "Please provide a reason for the report." };
        }

        const comment = await db.mediaComment.findUnique({
            where: { id: commentId },
        });

        if (!comment) return { error: "Comment not found." };

        // @ts-ignore
        await db.commentReport.create({
            data: {
                commentId,
                reason,
                reporterId: session.userId,
            },
        });

        // @ts-ignore
        await db.mediaComment.update({
            where: { id: commentId },
            data: { approved: false } as any
        });

        return { success: true };
    } catch (error) {
        console.error("[submitCommentReport error]", error);
        return { error: "Something went wrong while submitting the report." };
    }
}
