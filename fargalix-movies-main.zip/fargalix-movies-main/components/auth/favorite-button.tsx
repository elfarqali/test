"use client";

import { useEffect, useState } from "react";
import { Heart } from "lucide-react";
import { useAuth } from "@/components/auth/auth-provider";

interface FavoriteButtonProps {
  tmdbId: number;
  mediaType: "MOVIE" | "TV";
  title: string;
  posterPath?: string | null;
  backdropPath?: string | null;
  voteAverage?: number | null;
  year?: string | null;
}

export function FavoriteButton({
  tmdbId,
  mediaType,
  title,
  posterPath,
  backdropPath,
  voteAverage,
  year,
}: FavoriteButtonProps) {
  const { user } = useAuth();
  const [isFav, setIsFav] = useState(false);
  const [loading, setLoading] = useState(false);

  // Check if already favorited
  useEffect(() => {
    if (!user) return;
    fetch("/api/user/favorites")
      .then((r) => r.json())
      .then((data) => {
        const match = (data.favorites ?? []).find(
          (f: { tmdbId: number; mediaType: string }) =>
            f.tmdbId === tmdbId && f.mediaType === mediaType
        );
        setIsFav(!!match);
      })
      .catch(() => {});
  }, [user, tmdbId, mediaType]);

  if (!user) return null;

  const toggle = async () => {
    setLoading(true);
    try {
      if (isFav) {
        await fetch(
          `/api/user/favorites?tmdbId=${tmdbId}&mediaType=${mediaType}`,
          { method: "DELETE" }
        );
        setIsFav(false);
      } else {
        await fetch("/api/user/favorites", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ tmdbId, mediaType, title, posterPath, backdropPath, voteAverage, year }),
        });
        setIsFav(true);
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      onClick={toggle}
      disabled={loading}
      aria-label={isFav ? "Remove from favorites" : "Add to favorites"}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "8px 18px",
        borderRadius: 10,
        border: isFav
          ? "1.5px solid rgba(239,68,68,0.55)"
          : "1.5px solid rgba(255,255,255,0.14)",
        background: isFav ? "rgba(239,68,68,0.12)" : "rgba(255,255,255,0.06)",
        color: isFav ? "#f87171" : "rgba(255,255,255,0.55)",
        fontSize: 13,
        fontWeight: 600,
        cursor: loading ? "wait" : "pointer",
        transition: "all 0.15s ease",
        backdropFilter: "blur(4px)",
        opacity: loading ? 0.7 : 1,
      }}
    >
      <Heart size={15} fill={isFav ? "#f87171" : "none"} />
      {isFav ? "Saved" : "Add to Favorites"}
    </button>
  );
}
