"use client";

import { useState, useRef, useEffect, useLayoutEffect, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import { User, LogOut, Settings, History, LayoutDashboard, ChevronDown } from "lucide-react";
import { useAuth } from "@/components/auth/auth-provider";

/** Measures the trigger button and positions the panel via fixed coordinates
 *  so it is never clipped by parent overflow:hidden or stacking contexts
 *  (including the mobile sidebar drawer).
 *
 *  Returns `null` until the first measurement has run so the caller can
 *  suppress rendering until we have a real position (prevents the
 *  top-left flicker caused by the default {top:0, right:0} state). */
function useDropdownPosition(
  ref: React.RefObject<HTMLDivElement | null>,
  open: boolean
): { top: number; right: number } | null {
  const [pos, setPos] = useState<{ top: number; right: number } | null>(null);

  const measure = useCallback(() => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    setPos({
      top: rect.bottom + 8,
      right: window.innerWidth - rect.right,
    });
  }, [ref]);

  // useLayoutEffect runs synchronously after DOM mutations but BEFORE the
  // browser paints, so the dropdown is positioned correctly on its very first
  // visible frame — eliminating the jump to the top-left corner.
  useLayoutEffect(() => {
    if (!open) {
      // Reset to null so next open always measures fresh
      setPos(null);
      return;
    }
    measure();
  }, [open, measure]);

  // Keep position updated on resize / scroll while open
  useEffect(() => {
    if (!open) return;
    window.addEventListener("resize", measure, { passive: true });
    window.addEventListener("scroll", measure, { passive: true, capture: true });
    return () => {
      window.removeEventListener("resize", measure);
      window.removeEventListener("scroll", measure, true);
    };
  }, [open, measure]);

  return pos;
}

export function UserMenu() {
  const { user, loading, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const pos = useDropdownPosition(ref, open);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    // Small timeout so the opening click doesn't immediately close
    const id = setTimeout(() => document.addEventListener("mousedown", handler), 0);
    return () => {
      clearTimeout(id);
      document.removeEventListener("mousedown", handler);
    };
  }, [open]);

  // Close on route change (pathname listened from URL)
  useEffect(() => {
    setOpen(false);
  }, []);

  if (loading) {
    return (
      <div
        style={{
          width: 34, height: 34, borderRadius: "50%",
          background: "rgba(124,58,237,0.1)",
          border: "1.5px solid rgba(124,58,237,0.2)",
          flexShrink: 0,
        }}
      />
    );
  }

  if (!user) {
    return (
      <div className="hidden sm:flex" style={{ gap: 6 }}>
        <Link
          href="/signin"
          style={{
            padding: "5px 14px", borderRadius: 7,
            fontSize: 12, fontWeight: 600,
            color: "rgba(255,255,255,0.6)",
            background: "transparent",
            border: "1px solid rgba(255,255,255,0.12)",
            textDecoration: "none", transition: "all 0.15s ease",
          }}
        >
          Sign In
        </Link>
        <Link
          href="/signup"
          style={{
            padding: "5px 14px", borderRadius: 7,
            fontSize: 12, fontWeight: 700,
            color: "#fff",
            background: "linear-gradient(135deg, #7c3aed 0%, #5b21b6 100%)",
            border: "none", textDecoration: "none",
            transition: "all 0.15s ease",
          }}
        >
          Sign Up
        </Link>
      </div>
    );
  }

  const initials = user.username.slice(0, 2).toUpperCase();

  const menuItems = [
    { href: "/profile", icon: <User size={15} />, label: "Profile" },
    { href: "/settings", icon: <Settings size={15} />, label: "Settings" },
    { href: "/history", icon: <History size={15} />, label: "History" },
    ...(user.role === "ADMIN"
      ? [{ href: "/admin", icon: <LayoutDashboard size={15} />, label: "Admin Panel" }]
      : []),
  ];

  return (
    <div ref={ref} style={{ position: "relative", flexShrink: 0 }}>
      {/* Avatar trigger */}
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="User menu"
        aria-expanded={open}
        style={{
          display: "flex", alignItems: "center", gap: 6,
          background: "transparent", border: "none",
          cursor: "pointer", padding: 0,
        }}
      >
        <div
          style={{
            width: 34, height: 34, borderRadius: "50%",
            background: user.avatarUrl
              ? "transparent"
              : "linear-gradient(135deg, #7c3aed 0%, #a78bfa 100%)",
            border: open
              ? "2px solid rgba(167,139,250,0.8)"
              : "2px solid rgba(124,58,237,0.45)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 11, fontWeight: 700, color: "#fff",
            transition: "border-color 0.15s ease",
            overflow: "hidden", flexShrink: 0, position: "relative",
          }}
        >
          {user.avatarUrl ? (
            <Image src={user.avatarUrl} alt={user.username} fill sizes="34px" style={{ objectFit: "cover" }} unoptimized />
          ) : initials}
        </div>
        <ChevronDown
          size={12}
          style={{
            color: "rgba(255,255,255,0.4)",
            transform: open ? "rotate(180deg)" : "rotate(0deg)",
            transition: "transform 0.2s ease",
          }}
        />
      </button>

      {/* Dropdown — position:fixed escapes all stacking contexts / overflow clips.
          We gate on `pos` (non-null) so the panel is never rendered before
          useLayoutEffect has measured the real coordinates, eliminating flicker. */}
      {open && pos && (
        <div
          style={{
            position: "fixed",
            top: pos.top,
            right: Math.max(pos.right, 8), /* at least 8px from edge on mobile */
            minWidth: 220,
            maxWidth: "calc(100vw - 16px)", /* never wider than the viewport */
            background: "#111827",
            border: "1px solid rgba(124,58,237,0.25)",
            borderRadius: 14,
            boxShadow: "0 20px 60px rgba(0,0,0,0.8), 0 0 0 1px rgba(124,58,237,0.1)",
            zIndex: 9999, /* above drawer (z:61) and everything else */
            overflow: "hidden",
            /* Smooth entrance */
            animation: "userMenuDrop 0.18s cubic-bezier(0.4,0,0.2,1) forwards",
          }}
        >
          {/* User header */}
          <div
            style={{
              padding: 16,
              background: "rgba(124,58,237,0.08)",
              borderBottom: "1px solid rgba(255,255,255,0.06)",
              display: "flex", alignItems: "center", gap: 12,
            }}
          >
            <div
              style={{
                width: 40, height: 40, borderRadius: "50%", flexShrink: 0,
                background: user.avatarUrl
                  ? "transparent"
                  : "linear-gradient(135deg, #7c3aed 0%, #a78bfa 100%)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 14, fontWeight: 800, color: "#fff",
                overflow: "hidden", position: "relative",
              }}
            >
              {user.avatarUrl ? (
                <Image src={user.avatarUrl} alt={user.username} fill sizes="40px" style={{ objectFit: "cover" }} unoptimized />
              ) : initials}
            </div>
            <div style={{ minWidth: 0 }}>
              <p style={{ fontSize: 13, fontWeight: 700, color: "#e2d9f3", marginBottom: 1 }}>
                @{user.username}
              </p>
              <p style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {user.email}
              </p>
              {user.role === "ADMIN" && (
                <span style={{
                  display: "inline-block", marginTop: 4,
                  fontSize: 9, fontWeight: 800, letterSpacing: "0.1em",
                  textTransform: "uppercase", color: "#a78bfa",
                  background: "rgba(124,58,237,0.18)",
                  border: "1px solid rgba(124,58,237,0.3)",
                  padding: "2px 7px", borderRadius: 4,
                }}>
                  Admin
                </span>
              )}
            </div>
          </div>

          {/* Menu items */}
          <div style={{ padding: "6px 0" }}>
            {menuItems.map((item, i) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                style={{
                  display: "flex", alignItems: "center", gap: 11,
                  padding: "10px 16px", fontSize: 13, fontWeight: 500,
                  color: "rgba(255,255,255,0.75)", textDecoration: "none",
                  transition: "background 0.12s ease, color 0.12s ease",
                  borderBottom: i < menuItems.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none",
                }}
                className="hover:bg-white/[0.06] hover:text-white"
              >
                <span style={{ color: "#a78bfa", flexShrink: 0 }}>{item.icon}</span>
                {item.label}
              </Link>
            ))}
          </div>

          {/* Divider + Logout */}
          <div style={{ borderTop: "1px solid rgba(255,255,255,0.07)", padding: "6px 0" }}>
            <button
              onClick={() => { setOpen(false); signOut(); }}
              style={{
                display: "flex", alignItems: "center", gap: 11,
                width: "100%", padding: "10px 16px",
                fontSize: 13, fontWeight: 500,
                color: "rgba(239,68,68,0.8)",
                background: "transparent", border: "none",
                cursor: "pointer", textAlign: "left",
                transition: "background 0.12s ease, color 0.12s ease",
              }}
              className="hover:bg-red-500/10 hover:text-red-400"
            >
              <LogOut size={15} style={{ flexShrink: 0 }} />
              Logout
            </button>
          </div>
        </div>
      )}

      {/* Keyframe for entrance animation — injected once */}
      <style>{`
        @keyframes userMenuDrop {
          from { opacity: 0; transform: translateY(-6px) scale(0.97); }
          to   { opacity: 1; transform: translateY(0)    scale(1);    }
        }
      `}</style>
    </div>
  );
}
