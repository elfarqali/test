"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
} from "react";

export interface AuthUser {
  id: string;
  email: string;
  username: string;
  role: "USER" | "ADMIN";
  avatarUrl: string | null;
}

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  refetch: () => void;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue>({
  user: null,
  loading: true,
  refetch: () => { },
  signOut: async () => { },
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  const AUTH_CACHE_KEY = "_sv_auth_user";
  const AUTH_CACHE_TTL = 5 * 60 * 1000; // 5 minutes

  const fetchUser = useCallback(async (bypass = false) => {
    // ── Skip API call if no session cookie exists ─────────────────────────
    // Non-authenticated visitors (vast majority of traffic) never need to
    // hit /api/auth/me — saves a serverless invocation + DB query per page.
    try {
      if (!document.cookie.includes("sv_session")) {
        setUser(null);
        setLoading(false);
        return;
      }
    } catch {
      // SSR guard — fall through to fetch
    }

    // Serve from sessionStorage if fresh enough (avoids DB hit on every page nav)
    if (!bypass) {
      try {
        const raw = sessionStorage.getItem(AUTH_CACHE_KEY);
        if (raw) {
          const { user: cachedUser, ts } = JSON.parse(raw);
          if (Date.now() - ts < AUTH_CACHE_TTL) {
            setUser(cachedUser);
            setLoading(false);
            return;
          }
        }
      } catch {
        // sessionStorage not available (SSR guard) — fall through to fresh fetch
      }
    }

    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        try {
          sessionStorage.setItem(AUTH_CACHE_KEY, JSON.stringify({ user: data.user, ts: Date.now() }));
        } catch { /* ignore */ }
      } else {
        setUser(null);
        try { sessionStorage.removeItem(AUTH_CACHE_KEY); } catch { /* ignore */ }
      }
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  const signOut = async () => {
    await fetch("/api/auth/signout", { method: "POST" });
    setUser(null);
    try { sessionStorage.removeItem("_sv_auth_user"); } catch { /* ignore */ }
    window.location.href = "/";
  };

  return (
    <AuthContext.Provider value={{ user, loading, refetch: fetchUser, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
