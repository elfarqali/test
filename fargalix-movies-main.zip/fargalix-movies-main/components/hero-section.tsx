"use client";

import Image from "next/image";
import Link from "next/link";
import { useState, useEffect, useCallback, useRef } from "react";
import { Play, Info } from "lucide-react";
import {
  IMAGE_BACKDROP_URL,
  IMAGE_BASE_URL,
  getMediaTitle,
  getMediaYear,
  getMediaType,
} from "@/lib/tmdb";
import type { TMDBMediaItem } from "@/lib/tmdb";

const DRAG_THRESHOLD = 50; // px to trigger a slide change

interface HeroSectionProps {
  items: TMDBMediaItem[];
}

function buildDetailHref(item: TMDBMediaItem): string {
  if (item.media_type === "tv") return `/tv/${item.id}`;
  if (item.media_type === "movie") return `/movie/${item.id}`;
  if (item.name && !item.title) return `/tv/${item.id}`;
  return `/movie/${item.id}`;
}

function HeroRatingCircle({ score }: { score: number }) {
  const pct = Math.round(score * 10);
  const color = score >= 7 ? "#22c55e" : score >= 5 ? "#f59e0b" : "#ef4444";
  return (
    <svg
      width="44"
      height="44"
      viewBox="0 0 36 36"
      style={{ transform: "rotate(-90deg)", flexShrink: 0 }}
    >
      <circle
        cx="18" cy="18" r="15.9155"
        fill="rgba(0,0,0,0.55)"
        stroke="rgba(255,255,255,0.12)"
        strokeWidth="3"
      />
      <circle
        cx="18" cy="18" r="15.9155"
        fill="none"
        stroke={color}
        strokeWidth="3"
        strokeDasharray={`${pct} 100`}
        strokeLinecap="round"
      />
      <text
        x="18" y="22"
        textAnchor="middle"
        fontSize="10"
        fontWeight="700"
        fill="#ffffff"
        style={{ transform: "rotate(90deg) translate(0px, -36px)" }}
      >
        {score.toFixed(1)}
      </text>
    </svg>
  );
}

export function HeroSection({ items }: HeroSectionProps) {
  const [index, setIndex] = useState(0);
  const [imgFade, setImgFade] = useState(true);
  // Direction the *incoming* content slides from
  const [slideDir, setSlideDir] = useState<"left" | "right">("left");
  // True only after the pointer has physically moved — used only for the
  // grabbing cursor. Never set on mousedown alone so a plain click never
  // triggers the grabbing state or the drag-capture overlay.
  const [isGrabbing, setIsGrabbing] = useState(false);

  // Refs to avoid stale closures in callbacks
  const indexRef = useRef(0);
  indexRef.current = index;

  // Mouse / touch drag tracking
  const dragStartX = useRef<number | null>(null);
  const dragStartY = useRef<number | null>(null);
  const dragMoved = useRef(false);

  /* ── Navigation ─────────────────────────────────── */

  const goTo = useCallback((newIdx: number, dir: "left" | "right") => {
    if (newIdx === indexRef.current) return;
    setSlideDir(dir);
    setImgFade(false);
    setTimeout(() => {
      setIndex(newIdx);
      setImgFade(true);
    }, 300);
  }, []);

  const prev = useCallback(() => {
    const newIdx =
      indexRef.current === 0 ? items.length - 1 : indexRef.current - 1;
    goTo(newIdx, "right");
  }, [goTo, items.length]);

  const next = useCallback(() => {
    const newIdx =
      indexRef.current === items.length - 1 ? 0 : indexRef.current + 1;
    goTo(newIdx, "left");
  }, [goTo, items.length]);

  /* ── Auto-advance ────────────────────────────────── */

  useEffect(() => {
    if (items.length <= 1) return;
    const id = setInterval(() => {
      const newIdx =
        indexRef.current === items.length - 1 ? 0 : indexRef.current + 1;
      goTo(newIdx, "left");
    }, 7000);
    return () => clearInterval(id);
  }, [items.length, goTo]);

  /* ── Mouse drag (desktop) ────────────────────────── */

  function onMouseDown(e: React.MouseEvent) {
    // Record the start position but do NOT set isGrabbing yet — that only
    // happens once actual pixel movement is detected in onMouseMove.
    // This ensures a plain click on a button never activates the drag state.
    dragStartX.current = e.clientX;
    dragMoved.current = false;
  }

  function onMouseMove(e: React.MouseEvent) {
    if (dragStartX.current === null) return;
    if (Math.abs(e.clientX - dragStartX.current) > 5) {
      dragMoved.current = true;
      setIsGrabbing(true);
    }
  }

  function onMouseUp(e: React.MouseEvent) {
    if (dragStartX.current === null) return;
    const delta = e.clientX - dragStartX.current;
    dragStartX.current = null;
    setIsGrabbing(false);
    // Only change slide when the user actually dragged far enough
    if (dragMoved.current && Math.abs(delta) >= DRAG_THRESHOLD) {
      delta < 0 ? next() : prev();
    }
  }

  function onMouseLeave() {
    dragStartX.current = null;
    setIsGrabbing(false);
  }

  /* ── Touch swipe (mobile) ────────────────────────── */

  function onTouchStart(e: React.TouchEvent) {
    dragStartX.current = e.touches[0].clientX;
    dragStartY.current = e.touches[0].clientY;
    dragMoved.current = false;
  }

  function onTouchMove(e: React.TouchEvent) {
    if (dragStartX.current === null) return;
    if (Math.abs(e.touches[0].clientX - dragStartX.current) > 5)
      dragMoved.current = true;
  }

  function onTouchEnd(e: React.TouchEvent) {
    if (dragStartX.current === null || dragStartY.current === null) return;
    const deltaX = e.changedTouches[0].clientX - dragStartX.current;
    const deltaY = e.changedTouches[0].clientY - dragStartY.current;
    dragStartX.current = null;
    dragStartY.current = null;

    // Only treat as horizontal swipe when X movement dominates
    if (
      Math.abs(deltaX) > Math.abs(deltaY) &&
      Math.abs(deltaX) >= DRAG_THRESHOLD
    ) {
      deltaX < 0 ? next() : prev();
    }
  }

  if (!items.length) return null;

  const hero = items[index];
  const title = getMediaTitle(hero);
  const year = getMediaYear(hero);
  const rating = hero.vote_average ?? 0;
  const type = getMediaType(hero);
  const backdrop = hero.backdrop_path
    ? `${IMAGE_BACKDROP_URL}${hero.backdrop_path}`
    : hero.poster_path
      ? `${IMAGE_BASE_URL}${hero.poster_path}`
      : null;
  const detailHref = buildDetailHref(hero);

  return (
    <section
      className="hero-banner relative w-full overflow-hidden select-none"
      style={{ cursor: isGrabbing ? "grabbing" : "default" }}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseLeave}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* ── Backdrop image ── */}
      {backdrop && (
        <Image
          key={hero.id}
          src={backdrop}
          alt={title}
          fill
          priority
          sizes="100vw"
          className="object-cover object-center"
          style={{ opacity: imgFade ? 1 : 0, transition: "opacity 0.35s ease" }}
          draggable={false}
          unoptimized
        />
      )}

      {/* ── Gradient overlays ── */}

      {/* Left-to-right: dark on the content side */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "linear-gradient(105deg, rgba(8,8,8,0.97) 0%, rgba(8,8,8,0.82) 28%, rgba(8,8,8,0.42) 58%, rgba(8,8,8,0.05) 100%)",
        }}
      />
      {/* Bottom: blends into the page */}
      <div
        className="absolute bottom-0 left-0 right-0 pointer-events-none"
        style={{
          height: "48%",
          background:
            "linear-gradient(to top, #0b0f1a 0%, rgba(11,15,26,0.78) 38%, transparent 100%)",
        }}
      />
      {/* Top vignette: keeps the navbar readable */}
      <div
        className="absolute top-0 left-0 right-0 pointer-events-none"
        style={{
          height: "20%",
          background: "linear-gradient(to bottom, rgba(0,0,0,0.5) 0%, transparent 100%)",
        }}
      />
      {/* Text-area shadow: soft radial glow anchored to the bottom-left
          where the title, buttons and metadata sit. Blends naturally
          with the left gradient without darkening the full image. */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 70% 60% at 10% 88%, rgba(0,0,0,0.72) 0%, rgba(0,0,0,0.28) 55%, transparent 100%)",
        }}
      />

      {/* ── Content — absolutely anchored to bottom-left ── */}
      {/*
        stopPropagation on mousedown prevents the section-level drag tracker
        from ever seeing clicks that originate inside the content block.
        This means clicking any button or link here is always a clean click,
        never accidentally treated as the start of a drag.
      */}
      <div className="hero-content" onMouseDown={(e) => e.stopPropagation()}>
        {/*
          key={index} causes React to unmount → remount this block on every
          slide change, re-triggering the CSS slide-in animation.
          Direction class is set before the index changes so the correct
          animation fires for forward vs backward navigation.
        */}
        <div
          key={index}
          className={`hero-inner ${slideDir === "left"
            ? "hero-slide-from-right"
            : "hero-slide-from-left"
            }`}
        >
          {/* Type pill + year */}
          <div className="flex items-center gap-2.5 mb-3">
            <span
              className="text-[10px] font-black uppercase tracking-widest rounded-sm"
              style={{
                backgroundColor: type === "Series" ? "#7c3aed" : "#6d28d9",
                color: "#fff",
                padding: "3px 9px",
              }}
            >
              {type}
            </span>
            <span style={{ fontSize: 12, color: "rgba(255,255,255,0.45)" }}>
              {year}
            </span>
          </div>

          {/* Title */}
          <h1
            className="hero-title font-black text-white uppercase leading-tight mb-4 line-clamp-2"
            style={{
              letterSpacing: "0.022em",
              textShadow: "0 4px 28px rgba(0,0,0,0.95)",
            }}
          >
            {title}
          </h1>

          {/* Rating circle + overview */}
          <div className="flex items-start gap-4 mb-5 hero-overview-row">
            {rating > 0 && <HeroRatingCircle score={rating} />}
            {hero.overview && (
              <p
                className="hero-overview leading-relaxed line-clamp-3"
                style={{ color: "rgba(255,255,255,0.65)", flex: 1 }}
              >
                {hero.overview}
              </p>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-3 mb-6">
            <Link
              href={`${detailHref}?play=1#player`}
              draggable={false}
              className="flex items-center gap-2 font-bold text-white rounded transition-opacity hover:opacity-90"
              style={{
                backgroundColor: "#7c3aed",
                boxShadow: "0 4px 20px rgba(124,58,237,0.45)",
                padding: "11px 24px",
                fontSize: 13,
              }}
            >
              <Play size={14} fill="#fff" />
              WATCH NOW
            </Link>
            <Link
              href={detailHref}
              draggable={false}
              className="flex items-center gap-2 font-semibold rounded transition-colors hover:bg-white/20"
              style={{
                color: "rgba(255,255,255,0.85)",
                backgroundColor: "rgba(255,255,255,0.12)",
                border: "1px solid rgba(255,255,255,0.18)",
                padding: "11px 24px",
                fontSize: 13,
                backdropFilter: "blur(4px)",
              }}
            >
              <Info size={14} />
              More Info
            </Link>
          </div>

          {/* Slide dot indicators — live below buttons, left-aligned */}
          <div className="flex gap-1.5 items-center">
            {items.slice(0, 10).map((_, i) => (
              <button
                key={i}
                onClick={(e) => {
                  e.stopPropagation();
                  goTo(i, i > index ? "left" : "right");
                }}
                style={{
                  width: i === index ? 22 : 6,
                  height: 6,
                  borderRadius: 4,
                  backgroundColor:
                    i === index ? "#7c3aed" : "rgba(255,255,255,0.28)",
                  border: "none",
                  cursor: "pointer",
                  padding: 0,
                  flexShrink: 0,
                  transition:
                    "width 0.3s ease, background-color 0.3s ease",
                }}
                aria-label={`Go to slide ${i + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
