"use client";

import { useEffect, useRef } from "react";

type AdPosition = "TOP" | "BOTTOM" | "BEFORE_PLAYER" | "AFTER_PLAYER";

interface AdData {
    id: string;
    name: string;
    code: string;
    placement: string;
    position: AdPosition;
    displayOrder: number;
}

interface AdSlotProps {
    /** The placement identifier, e.g. "HOME_PAGE", "MOVIE_PAGE" */
    placement: string;
    /** Filter by position — renders only ads with the matching position */
    position?: AdPosition;
    /** Optional wrapper className */
    className?: string;
    style?: React.CSSProperties;
}

/**
 * AdSlot — fetches and renders active ads for the given placement.
 * Ads with placement = "ALL_PAGES" are also included automatically.
 * Scripts inside the ad code are executed safely using node injection.
 */
export function AdSlot({ placement, position, className, style }: AdSlotProps) {
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        let cancelled = false;

        const load = async () => {
            try {
                const res = await fetch(`/api/ads?placement=${placement}`);
                if (!res.ok) return;
                const data = await res.json();
                const ads: AdData[] = data.ads ?? [];

                const filtered = position
                    ? ads.filter((a) => a.position === position)
                    : ads;

                if (!containerRef.current || cancelled) return;

                // Clear previous content
                containerRef.current.innerHTML = "";

                filtered.forEach((ad) => {
                    // Wrapper div per ad
                    const wrapper = document.createElement("div");
                    wrapper.setAttribute("data-ad-id", ad.id);
                    wrapper.setAttribute("data-ad-name", ad.name);
                    wrapper.style.display = "contents";

                    // Parse the ad code as HTML
                    const temp = document.createElement("div");
                    temp.innerHTML = ad.code;

                    // Move all nodes into wrapper — re-create <script> tags so they execute
                    Array.from(temp.childNodes).forEach((node) => {
                        if (
                            node instanceof HTMLElement &&
                            node.tagName === "SCRIPT"
                        ) {
                            const script = document.createElement("script");
                            Array.from(node.attributes).forEach((attr) =>
                                script.setAttribute(attr.name, attr.value)
                            );
                            script.textContent = node.textContent;
                            wrapper.appendChild(script);
                        } else {
                            wrapper.appendChild(node.cloneNode(true));
                        }
                    });

                    containerRef.current!.appendChild(wrapper);
                });
            } catch {
                // Silently fail — ads should never break the page
            }
        };

        load();
        return () => { cancelled = true; };
    }, [placement, position]);

    return <div ref={containerRef} className={className} style={style} />;
}
