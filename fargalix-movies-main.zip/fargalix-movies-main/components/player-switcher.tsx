"use client";

import { useState, useEffect } from "react";

export interface PlayerSource {
  name: string;
  src: string;
}

interface PlayerSwitcherProps {
  sources: PlayerSource[];
  iframeKey?: string;
  title?: string;
  onVideoEnded?: () => void;
}

export function PlayerSwitcher({ sources, iframeKey, title, onVideoEnded }: PlayerSwitcherProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    try {
      const preferred = localStorage.getItem("sv_preferred_player");
      if (preferred) {
        const foundIndex = sources.findIndex((s) => s.name === preferred);
        if (foundIndex !== -1) {
          setActiveIndex(foundIndex);
        }
      }
    } catch { }
    setMounted(true);
  }, [sources]);

  useEffect(() => {
    if (!onVideoEnded) return;

    const handleMessage = (e: MessageEvent) => {
      try {
        const data = e.data;
        // Parse possible message formats from common iframe providers
        if (typeof data === "string") {
          if (data.includes("video_ended") || data.includes("videoEnded") || data.includes("ended") || data.includes("source_ended")) {
            onVideoEnded();
          }
        } else if (data && typeof data === "object") {
          const eventType = data.event || data.action || data.type || data.name;
          if (
            eventType === "video_ended" ||
            eventType === "ended" ||
            eventType === "videoEnded" ||
            eventType === "source_ended" ||
            eventType === "media_ended"
          ) {
            onVideoEnded();
          }
        }
      } catch { }
    };

    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [onVideoEnded]);

  const handleSelect = (i: number) => {
    setActiveIndex(i);
    try {
      localStorage.setItem("sv_preferred_player", sources[i].name);
    } catch { }
  };

  if (sources.length === 0) {
    return (
      <div
        style={{
          width: "100%",
          paddingBottom: "56.25%",
          position: "relative",
          borderRadius: 14,
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.07)",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexDirection: "column",
            gap: 10,
          }}
        >
          <span style={{ fontSize: 28, opacity: 0.2 }}>▶</span>
          <p style={{ fontSize: 13, color: "rgba(255,255,255,0.25)" }}>
            No player configured. Add a player in the admin panel.
          </p>
        </div>
      </div>
    );
  }

  const currentSrc = sources[activeIndex]?.src ?? sources[0].src;

  return (
    <>
      {/* Player — two-layer wrapper to prevent cross-browser box-shadow clipping.
           The browser clips box-shadow inside overflow:hidden stacking contexts
           differently on Chrome/Brave vs Firefox/Safari. Fix: outer div owns
           the shadow (no overflow clip), inner div owns overflow:hidden for
           the iframe corner radius. */}
      <div
        style={{
          position: "relative",
          width: "100%",
          borderRadius: 14,
          /* Shadow lives here — never clipped by overflow:hidden */
          boxShadow: [
            "0 8px 24px rgba(0,0,0,0.55)",
            "0 32px 80px rgba(0,0,0,0.70)",
            "0 0 0 1px rgba(255,255,255,0.05)",
            "0 16px 60px rgba(124,58,237,0.12)",
          ].join(", "),
          /* Isolate the stacking context so the shadow isn't cropped by
             any ancestor with transform/will-change/filter */
          isolation: "isolate",
          /* Explicit GPU layer prevents Chromium from promoting the
             clipped inner div and losing the outer shadow */
          transform: "translateZ(0)",
        }}
      >
        {/* Inner clip — owns overflow:hidden to round the iframe corners */}
        <div
          style={{
            position: "relative",
            width: "100%",
            paddingBottom: "56.25%",
            height: 0,
            borderRadius: 14,
            overflow: "hidden",
            border: "1px solid rgba(255,255,255,0.07)",
            backgroundColor: "rgba(0,0,0,0.4)",
          }}
        >
          {mounted ? (
            <iframe
              key={`${activeIndex}-${iframeKey ?? ""}`}
              src={currentSrc}
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                border: "none",
                display: "block",
              }}
              allowFullScreen
              allow="encrypted-media; autoplay; picture-in-picture"
              title={title ?? "Watch"}
            />
          ) : (
            <div
              style={{
                position: "absolute",
                inset: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <div
                style={{
                  width: 32,
                  height: 32,
                  border: "3px solid rgba(255,255,255,0.1)",
                  borderTopColor: "rgba(255,255,255,0.5)",
                  borderRadius: "50%",
                  animation: "spin 1s linear infinite",
                }}
              />
              <style>{`
                @keyframes spin {
                  0% { transform: rotate(0deg); }
                  100% { transform: rotate(360deg); }
                }
              `}</style>
            </div>
          )}
        </div>
      </div>

      {/* Source switcher — below the player, only shown when multiple sources exist */}
      {sources.length > 1 && (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            marginTop: 14,
            gap: 8,
            flexWrap: "wrap",
          }}
        >
          <span
            style={{
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              color: "rgba(255,255,255,0.3)",
              marginRight: 2,
            }}
          >
            Source
          </span>

          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "center",
              gap: 4,
              padding: 4,
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 10,
            }}
          >
            {sources.map((s, i) => (
              <button
                key={i}
                onClick={() => handleSelect(i)}
                style={{
                  padding: "7px 18px",
                  fontSize: 12,
                  fontWeight: 600,
                  borderRadius: 7,
                  cursor: "pointer",
                  border: "none",
                  letterSpacing: "0.03em",
                  transition: "all 0.15s ease",
                  backgroundColor:
                    activeIndex === i ? "rgba(124,58,237,0.22)" : "transparent",
                  color:
                    activeIndex === i ? "#c4b5fd" : "rgba(255,255,255,0.45)",
                  boxShadow:
                    activeIndex === i
                      ? "inset 0 0 0 1px rgba(124,58,237,0.45)"
                      : "none",
                }}
              >
                {s.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
