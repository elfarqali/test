"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { useAuth } from "@/components/auth/auth-provider";
import { ReportCommentButton } from "@/components/report-comment-button";

interface CommentUser {
  id: string;
  username: string;
  avatarUrl: string | null;
}

interface Comment {
  id: string;
  body: string;
  createdAt: string;
  userId: string;
  user: CommentUser;
}

interface DiscussionSectionProps {
  mediaType: "TV" | "MOVIE";
  mediaId: number;
}

const URL_PATTERN = /https?:\/\/|www\.\S+\.\S+|\b\S+\.(com|net|org|io|co|tv|gg|me|app|xyz)\b/i;

function timeAgo(date: string | Date): string {
  const diff = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
  return new Date(date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function Avatar({ user, size = 36 }: { user: CommentUser; size?: number }) {
  const ACCENT_SOFT = "rgba(124,58,237,0.18)";
  const ACCENT_BORDER = "rgba(124,58,237,0.28)";
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        background: ACCENT_SOFT,
        border: `1px solid ${ACCENT_BORDER}`,
        flexShrink: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: size * 0.38,
        fontWeight: 700,
        color: "#a78bfa",
        overflow: "hidden",
      }}
    >
      {user.avatarUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={user.avatarUrl}
          alt={user.username}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      ) : (
        user.username.charAt(0).toUpperCase()
      )}
    </div>
  );
}

export function DiscussionSection({ mediaType, mediaId }: DiscussionSectionProps) {
  const { user } = useAuth();
  const isAdmin = user?.role === "ADMIN";
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState("");
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const ACCENT = "#7c3aed";

  // ── Load comments on mount / mediaId change ──────────────────────────────
  useEffect(() => {
    setLoading(true);
    fetch(`/api/media-comments?mediaType=${mediaType}&mediaId=${mediaId}`)
      .then((r) => r.json())
      .then((data) => setComments(data.comments ?? []))
      .catch(() => { })
      .finally(() => setLoading(false));
  }, [mediaType, mediaId]);

  // ── Auto-dismiss error toast after 4 s ───────────────────────────────────
  useEffect(() => {
    if (!error) return;
    const t = setTimeout(() => setError(null), 4000);
    return () => clearTimeout(t);
  }, [error]);

  // ── Post comment ─────────────────────────────────────────────────────────
  const postComment = useCallback(async () => {
    if (!user || !text.trim() || posting) return;
    if (!isAdmin && URL_PATTERN.test(text)) {
      setError("Links are not allowed.");
      return;
    }
    setPosting(true);
    try {
      const res = await fetch("/api/media-comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body: text.trim(), mediaType, mediaId }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error((data as { error?: string }).error ?? `HTTP ${res.status}`);
      }
      const data = (await res.json()) as { comment: Comment };
      // Prepend so newest-first order is preserved without a refetch.
      setComments((prev) => [data.comment, ...prev]);
      setText("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to post comment.");
    } finally {
      setPosting(false);
    }
  }, [user, text, posting, mediaType, mediaId]);

  // ── Delete comment (admin only) ───────────────────────────────────────────────
  const deleteComment = async (id: string) => {
    if (deletingId) return;
    setDeletingId(id);
    // Optimistically remove from the list immediately
    setComments((prev) => prev.filter((c) => c.id !== id));
    try {
      const res = await fetch(`/api/media-comments/${id}`, { method: "DELETE" });
      if (!res.ok) {
        // Restore on failure
        const data = await res.json().catch(() => ({}));
        setError((data as { error?: string }).error ?? "Failed to delete comment.");
        // re-fetch to restore state
        fetch(`/api/media-comments?mediaType=${mediaType}&mediaId=${mediaId}`)
          .then((r) => r.json())
          .then((d) => setComments(d.comments ?? []))
          .catch(() => { });
      }
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div style={{ maxWidth: 660 }}>
      {/* ── Error toast ── */}
      {error && (
        <div
          style={{
            marginBottom: 16,
            padding: "10px 16px",
            borderRadius: 10,
            background: "rgba(239,68,68,0.12)",
            border: "1px solid rgba(239,68,68,0.28)",
            color: "#f87171",
            fontSize: 13,
            lineHeight: 1.5,
          }}
        >
          {error}
        </div>
      )}

      {/* ── Comment input (logged in) ── */}
      {user ? (
        <div
          style={{
            display: "flex",
            gap: 12,
            padding: "14px 16px",
            borderRadius: 14,
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.07)",
            marginBottom: 24,
          }}
        >
          <Avatar user={{ id: user.id, username: user.username, avatarUrl: user.avatarUrl }} size={38} />

          <div style={{ flex: 1 }}>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Share your thoughts..."
              rows={3}
              style={{
                width: "100%",
                background: "none",
                border: "none",
                outline: "none",
                color: "rgba(255,255,255,0.82)",
                fontSize: 13,
                lineHeight: 1.6,
                resize: "none",
                fontFamily: "inherit",
                caretColor: ACCENT,
                padding: 0,
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) postComment();
              }}
            />
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                borderTop: "1px solid rgba(255,255,255,0.06)",
                paddingTop: 10,
                marginTop: 6,
              }}
            >
              <span style={{ fontSize: 11, color: "rgba(255,255,255,0.18)" }}>
                Ctrl+Enter to post
              </span>
              <button
                onClick={postComment}
                disabled={!text.trim() || posting}
                style={{
                  padding: "7px 18px",
                  borderRadius: 8,
                  fontSize: 12,
                  fontWeight: 700,
                  background:
                    text.trim() && !posting
                      ? `linear-gradient(135deg, ${ACCENT}, #5b21b6)`
                      : "rgba(255,255,255,0.06)",
                  color: text.trim() && !posting ? "#fff" : "rgba(255,255,255,0.25)",
                  border: "none",
                  cursor: text.trim() && !posting ? "pointer" : "default",
                  transition: "background 0.2s, color 0.2s",
                  letterSpacing: "0.02em",
                }}
              >
                {posting ? "Posting…" : "Post Comment"}
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* ── Login prompt (logged out) ── */
        <div
          style={{
            padding: "18px 20px",
            borderRadius: 14,
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.07)",
            marginBottom: 24,
            textAlign: "center",
          }}
        >
          <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 13, marginBottom: 12 }}>
            Sign in to join the discussion.
          </p>
          <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
            <Link
              href="/signin"
              style={{
                padding: "7px 20px",
                borderRadius: 8,
                fontSize: 12,
                fontWeight: 700,
                background: `linear-gradient(135deg, ${ACCENT}, #5b21b6)`,
                color: "#fff",
                textDecoration: "none",
              }}
            >
              Sign In
            </Link>
            <Link
              href="/signup"
              style={{
                padding: "7px 20px",
                borderRadius: 8,
                fontSize: 12,
                fontWeight: 700,
                background: "rgba(255,255,255,0.06)",
                color: "rgba(255,255,255,0.55)",
                textDecoration: "none",
                border: "1px solid rgba(255,255,255,0.09)",
              }}
            >
              Sign Up
            </Link>
          </div>
        </div>
      )}

      {/* ── Comments list ── */}
      {loading ? (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              style={{
                padding: "14px 16px",
                borderRadius: 14,
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.06)",
                display: "flex",
                gap: 12,
              }}
            >
              <div
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: "50%",
                  background: "rgba(255,255,255,0.06)",
                  flexShrink: 0,
                  animation: "ep-pulse 1.6s ease-in-out infinite",
                }}
              />
              <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 6, paddingTop: 4 }}>
                <div
                  style={{
                    height: 10,
                    width: "28%",
                    borderRadius: 4,
                    background: "rgba(255,255,255,0.06)",
                    animation: "ep-pulse 1.6s ease-in-out infinite",
                  }}
                />
                <div
                  style={{
                    height: 9,
                    width: "75%",
                    borderRadius: 4,
                    background: "rgba(255,255,255,0.04)",
                    animation: "ep-pulse 1.6s ease-in-out infinite",
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      ) : comments.length === 0 ? (
        <div
          style={{
            textAlign: "center",
            padding: "48px 20px",
            border: "1px dashed rgba(255,255,255,0.07)",
            borderRadius: 16,
          }}
        >
          <div style={{ fontSize: 36, marginBottom: 14, opacity: 0.25 }}>💬</div>
          <p style={{ color: "rgba(255,255,255,0.28)", fontSize: 13, lineHeight: 1.6 }}>
            No comments yet.
            <br />
            Be the first to share your thoughts!
          </p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {comments.map((comment) => (
            <div
              key={comment.id}
              style={{
                padding: "14px 16px",
                borderRadius: 14,
                background: "rgba(255,255,255,0.025)",
                border: "1px solid rgba(255,255,255,0.06)",
                display: "flex",
                gap: 12,
              }}
            >
              <Avatar user={comment.user} size={36} />

              <div style={{ flex: 1, minWidth: 0 }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    marginBottom: 5,
                    flexWrap: "wrap",
                  }}
                >
                  <span style={{ fontSize: 12, fontWeight: 700, color: "#a78bfa" }}>
                    {comment.user.username}
                  </span>
                  <span style={{ fontSize: 10, color: "rgba(255,255,255,0.28)" }}>
                    {timeAgo(comment.createdAt)}
                  </span>
                  {/* Admin delete button */}
                  {isAdmin && (
                    <button
                      onClick={() => deleteComment(comment.id)}
                      disabled={deletingId === comment.id}
                      title="Delete comment"
                      style={{
                        marginLeft: "auto",
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        width: 24,
                        height: 24,
                        borderRadius: 6,
                        border: "1px solid rgba(239,68,68,0.25)",
                        background: "rgba(239,68,68,0.08)",
                        color: "rgba(239,68,68,0.6)",
                        cursor: deletingId === comment.id ? "wait" : "pointer",
                        opacity: deletingId === comment.id ? 0.4 : 1,
                        padding: 0,
                        transition: "all 0.15s ease",
                        flexShrink: 0,
                      }}
                      className="hover:bg-red-500/20 hover:text-red-400"
                    >
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6l-1 14H6L5 6" />
                        <path d="M10 11v6M14 11v6" />
                        <path d="M9 6V4h6v2" />
                      </svg>
                    </button>
                  )}
                  {user && comment.userId !== user.id && (
                    <div style={{ marginLeft: isAdmin ? 4 : "auto" }}>
                      <ReportCommentButton commentId={comment.id} />
                    </div>
                  )}
                </div>
                <p
                  style={{
                    fontSize: 13,
                    color: "rgba(255,255,255,0.72)",
                    lineHeight: 1.65,
                    wordBreak: "break-word",
                    margin: 0,
                    whiteSpace: "pre-wrap",
                  }}
                >
                  {comment.body}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
