"use client";

import { useState, useEffect } from "react";
import { Play, X } from "lucide-react";

interface TrailerButtonProps {
  trailerKey: string;
  showName: string;
}

export function TrailerButton({ trailerKey, showName }: TrailerButtonProps) {
  const [open, setOpen] = useState(false);

  // Lock scroll while modal is open
  useEffect(() => {
    if (open) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  // Close on Escape
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <>
      {/* ── Trigger button ── */}
      <button
        onClick={() => setOpen(true)}
        className="tv-trailer-btn"
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 9,
          padding: "11px 26px",
          borderRadius: 10,
          background: "linear-gradient(135deg, #7c3aed 0%, #5b21b6 100%)",
          color: "#fff",
          border: "none",
          cursor: "pointer",
          fontSize: 14,
          fontWeight: 700,
          letterSpacing: "0.02em",
          boxShadow: "0 4px 22px rgba(124,58,237,0.45)",
          transition: "transform 0.15s ease, box-shadow 0.15s ease",
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = "translateY(-2px)";
          e.currentTarget.style.boxShadow = "0 10px 30px rgba(124,58,237,0.6)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = "translateY(0)";
          e.currentTarget.style.boxShadow = "0 4px 22px rgba(124,58,237,0.45)";
        }}
      >
        <Play size={15} fill="#fff" strokeWidth={0} />
        Watch Trailer
      </button>

      {/* ── Modal ── */}
      {open && (
        <div
          className="fixed inset-0 flex items-center justify-center p-4 sm:p-8"
          style={{ zIndex: 600, animation: "trailerOverlayIn 0.2s ease forwards" }}
        >
          {/* Blurred backdrop — click to close */}
          <div
            className="absolute inset-0"
            style={{
              backdropFilter: "blur(18px) brightness(0.35)",
              WebkitBackdropFilter: "blur(18px) brightness(0.35)",
              backgroundColor: "rgba(0,0,0,0.7)",
            }}
            onClick={() => setOpen(false)}
          />

          {/* Modal card */}
          <div
            className="relative z-10 w-full"
            style={{
              maxWidth: 900,
              animation: "trailerModalIn 0.32s cubic-bezier(0.16,1,0.3,1) forwards",
            }}
          >
            {/* Top row: title + close */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 12,
              }}
            >
              <p
                style={{
                  color: "rgba(255,255,255,0.55)",
                  fontSize: 13,
                  fontWeight: 600,
                  letterSpacing: "0.02em",
                }}
              >
                {showName} &mdash; Official Trailer
              </p>
              <button
                onClick={() => setOpen(false)}
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: "50%",
                  background: "rgba(255,255,255,0.08)",
                  border: "1px solid rgba(255,255,255,0.14)",
                  color: "rgba(255,255,255,0.65)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  transition: "background 0.15s, color 0.15s",
                  flexShrink: 0,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "rgba(255,255,255,0.16)";
                  e.currentTarget.style.color = "#fff";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "rgba(255,255,255,0.08)";
                  e.currentTarget.style.color = "rgba(255,255,255,0.65)";
                }}
                aria-label="Close trailer"
              >
                <X size={16} />
              </button>
            </div>

            {/* 16:9 iframe wrapper */}
            <div
              style={{
                position: "relative",
                paddingBottom: "56.25%",
                height: 0,
                borderRadius: 16,
                overflow: "hidden",
                border: "1px solid rgba(255,255,255,0.08)",
                boxShadow:
                  "0 0 0 1px rgba(124,58,237,0.18), 0 32px 80px rgba(0,0,0,0.85)",
              }}
            >
              <iframe
                src={`https://www.youtube.com/embed/${trailerKey}?autoplay=1&rel=0&modestbranding=1`}
                style={{
                  position: "absolute",
                  inset: 0,
                  width: "100%",
                  height: "100%",
                  border: "none",
                }}
                allowFullScreen
                allow="autoplay; encrypted-media; picture-in-picture"
                title={`${showName} Trailer`}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
}
