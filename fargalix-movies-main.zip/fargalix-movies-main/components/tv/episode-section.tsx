"use client";

import { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import type { TMDBTVSeason, TMDBTVEpisode } from "@/lib/tmdb";
import { useAuth } from "@/components/auth/auth-provider";
import { DiscussionSection } from "@/components/discussion-section";

const STILL_URL = "https://image.tmdb.org/t/p/w300";

type Tab = "episodes" | "liked" | "discussion";

interface EpisodeSectionProps {
  tvId: string;
  seasons: TMDBTVSeason[];
  initialSeason: number;
  initialEpisodes: TMDBTVEpisode[];
  /** When provided, a DB progress refresh is triggered each time this changes
   *  (i.e. the user navigates to a different episode). */
  currentEpisode?: number;
}

export function EpisodeSection({
  tvId,
  seasons,
  initialSeason,
  initialEpisodes,
  currentEpisode,
}: EpisodeSectionProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>("episodes");
  const [currentSeason, setCurrentSeason] = useState(initialSeason);
  const [episodes, setEpisodes] = useState<TMDBTVEpisode[]>(initialEpisodes);
  const [loading, setLoading] = useState(false);
  // key: `${season}-${episode}`, value: progress 0-100
  const [epProgress, setEpProgress] = useState<Map<string, number>>(new Map());

  // Fetch episodes when season changes
  useEffect(() => {
    if (currentSeason === initialSeason) {
      setEpisodes(initialEpisodes);
      return;
    }
    setLoading(true);
    fetch(`/api/tv-season?id=${tvId}&season=${currentSeason}`)
      .then((r) => r.json())
      .then((data) => setEpisodes(data.episodes ?? []))
      .catch(() => setEpisodes([]))
      .finally(() => setLoading(false));
  }, [currentSeason, tvId, initialSeason, initialEpisodes]);

  // ── Real-time progress updates from WatchHistoryRecorder ──────────────────
  // WatchHistoryRecorder dispatches "svep-progress" on every 30-s interval
  // tick and on its final unmount flush. We listen here so the progress bar
  // and watched badge update immediately — no polling needed.
  useEffect(() => {
    const handler = (e: Event) => {
      const { tvId: evTvId, season: s, episode: ep, progress: p } = (
        e as CustomEvent<{ tvId: number; season: number; episode: number; progress: number }>
      ).detail;
      if (String(evTvId) !== tvId) return; // ignore other shows
      const key = `${s}-${ep}`;
      setEpProgress((prev) => {
        const next = new Map(prev);
        // Never let an earlier (lower) event overwrite a later (higher) one.
        next.set(key, Math.max(next.get(key) ?? 0, p));
        return next;
      });
    };
    window.addEventListener("svep-progress", handler);
    return () => window.removeEventListener("svep-progress", handler);
  }, [tvId]);

  // ── DB progress fetch ──────────────────────────────────────────────────────
  // Runs on mount, season change, auth change, and episode navigation.
  // Merges with existing in-memory state (from CustomEvents) using max so a
  // slightly-stale DB response (DB lags up to 30 s behind the recorder) can
  // never erase live progress that was already shown in the UI.
  useEffect(() => {
    if (!user) { setEpProgress(new Map()); return; }
    fetch(`/api/user/episode-progress?tvId=${tvId}&season=${currentSeason}`)
      .then((r) => r.json())
      .then((data) => {
        setEpProgress((prev) => {
          const next = new Map(prev);
          (data.items ?? []).forEach((item: { season: number; episode: number; progress: number }) => {
            const key = `${item.season}-${item.episode}`;
            // Keep the higher of live (in-memory) and persisted (DB) values.
            next.set(key, Math.max(next.get(key) ?? 0, item.progress));
          });
          return next;
        });
      })
      .catch(() => { });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tvId, currentSeason, user, currentEpisode]);

  // Optimistically mark an episode as watched (progress = 100) and sync to DB.
  const markAsWatched = useCallback(
    async (ep: TMDBTVEpisode) => {
      if (!user) return;
      const key = `${ep.season_number}-${ep.episode_number}`;
      setEpProgress((prev) => new Map([...prev, [key, 100]]));
      try {
        const res = await fetch("/api/user/episode-progress", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            tvId: Number(tvId),
            season: ep.season_number,
            episode: ep.episode_number,
            progress: 100,
          }),
        });
        // fetch() does NOT throw on HTTP errors — check status explicitly.
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
      } catch {
        // Revert optimistic update on failure.
        setEpProgress((prev) => {
          const next = new Map(prev);
          next.delete(key);
          return next;
        });
      }
    },
    [tvId, user],
  );

  // Sort episodes — always ascending (E1 first) for "episodes" tab
  const displayEpisodes = (() => {
    const copy = [...episodes].sort((a, b) => a.episode_number - b.episode_number);
    if (activeTab === "liked") return [...copy].sort((a, b) => b.vote_average - a.vote_average);
    return copy;
  })();

  const ACCENT = "#7c3aed";
  const ACCENT_SOFT = "rgba(124,58,237,0.18)";
  const ACCENT_BORDER = "rgba(124,58,237,0.28)";

  const tabs: { id: Tab; label: string }[] = [
    { id: "episodes", label: "Episodes" },
    { id: "liked", label: "Most Liked" },
    { id: "discussion", label: "Discussion" },
  ];

  return (
    <div style={{ maxWidth: "1040px", margin: "0 auto" }}>
      <style>{`
        @keyframes ep-pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        .ep-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 12px;
        }
        @media (max-width: 860px) {
          .ep-grid { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 560px) {
          .ep-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
        }
        .ep-grid > * { min-width: 0; }
        .ep-card-img { transition: transform 0.35s ease; }
        .ep-card:hover .ep-card-img { transform: scale(1.05); }
        .ep-overlay { opacity: 0; transition: opacity 0.2s ease; }
        .ep-card:hover .ep-overlay { opacity: 1; }
        .ep-play { opacity: 0; transition: opacity 0.2s ease; }
        .ep-card:hover .ep-play { opacity: 1; }
        .ep-mark-btn { opacity: 0; transition: opacity 0.18s ease; }
        .ep-card:hover .ep-mark-btn { opacity: 1; }
      `}</style>

      {/* ── Tab bar ── */}
      <div
        style={{
          display: "flex",
          gap: 0,
          borderBottom: "1px solid rgba(255,255,255,0.07)",
          marginBottom: 28,
        }}
      >
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                padding: "11px 22px",
                fontSize: 13,
                fontWeight: 600,
                letterSpacing: "0.01em",
                color: isActive ? "#a78bfa" : "rgba(255,255,255,0.38)",
                background: "none",
                border: "none",
                borderBottom: isActive
                  ? `2px solid ${ACCENT}`
                  : "2px solid transparent",
                cursor: "pointer",
                transition: "color 0.18s, border-color 0.18s",
                marginBottom: -1,
              }}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* ── Discussion tab ── */}
      {activeTab === "discussion" && (
        <DiscussionSection mediaType="TV" mediaId={Number(tvId)} />
      )}

      {/* ── Episodes grid ── */}
      {activeTab !== "discussion" && (
        <div>
          {/* Season selector + episode count */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 14,
              marginBottom: 24,
              flexWrap: "wrap",
            }}
          >
            {seasons.length > 1 && (
              <select
                value={currentSeason}
                onChange={(e) => setCurrentSeason(parseInt(e.target.value, 10))}
                style={{
                  padding: "8px 14px",
                  borderRadius: 9,
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.12)",
                  color: "#fff",
                  fontSize: 13,
                  fontWeight: 600,
                  outline: "none",
                  cursor: "pointer",
                  colorScheme: "dark",
                  appearance: "auto",
                }}
              >
                {seasons.map((s) => (
                  <option
                    key={s.season_number}
                    value={s.season_number}
                    style={{ backgroundColor: "#141828", color: "#fff" }}
                  >
                    {s.name || `Season ${s.season_number}`}
                  </option>
                ))}
              </select>
            )}
            {!loading && episodes.length > 0 && (
              <span style={{ color: "rgba(255,255,255,0.28)", fontSize: 12 }}>
                {episodes.length} episode{episodes.length !== 1 ? "s" : ""}
              </span>
            )}
          </div>

          {/* Loading skeleton grid */}
          {loading && (
            <div className="ep-grid">
              {[...Array(8)].map((_, i) => (
                <div key={i}>
                  <div
                    style={{
                      width: "100%",
                      aspectRatio: "16/9",
                      borderRadius: 10,
                      background: "rgba(255,255,255,0.05)",
                      animation: "ep-pulse 1.6s ease-in-out infinite",
                    }}
                  />
                  <div style={{ marginTop: 7, display: "flex", flexDirection: "column", gap: 5 }}>
                    <div
                      style={{
                        height: 11,
                        width: "70%",
                        borderRadius: 4,
                        background: "rgba(255,255,255,0.05)",
                        animation: "ep-pulse 1.6s ease-in-out infinite",
                      }}
                    />
                    <div
                      style={{
                        height: 9,
                        width: "45%",
                        borderRadius: 4,
                        background: "rgba(255,255,255,0.04)",
                        animation: "ep-pulse 1.6s ease-in-out infinite",
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Episode grid */}
          {!loading && displayEpisodes.length > 0 && (
            <div className="ep-grid">
              {displayEpisodes.map((ep) => {
                const stillSrc = ep.still_path ? `${STILL_URL}${ep.still_path}` : null;
                const dateStr = ep.air_date
                  ? new Date(ep.air_date).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })
                  : null;

                const epKey = `${ep.season_number}-${ep.episode_number}`;
                const progress = epProgress.get(epKey) ?? 0;
                const isWatched = progress >= 90;
                const hasProgress = progress > 3;

                return (
                  <Link
                    key={ep.id}
                    href={`/tv/${tvId}?season=${ep.season_number}&episode=${ep.episode_number}&play=1`}
                    className="ep-card"
                    style={{ textDecoration: "none", display: "block" }}
                  >
                    {/* Thumbnail — enforced 16:9 via aspectRatio */}
                    <div
                      style={{
                        position: "relative",
                        width: "100%",
                        aspectRatio: "16/9",
                        borderRadius: 10,
                        overflow: "hidden",
                        background: stillSrc
                          ? "rgba(0,0,0,0.4)"
                          : "linear-gradient(135deg,rgba(124,58,237,0.12) 0%,rgba(30,27,75,0.6) 100%)",
                        boxShadow: "0 2px 10px rgba(0,0,0,0.45)",
                        border: isWatched
                          ? "1px solid rgba(239,68,68,0.28)"
                          : "1px solid rgba(255,255,255,0.06)",
                      }}
                    >
                      {stillSrc ? (
                        <Image
                          src={stillSrc}
                          alt={ep.name}
                          fill
                          sizes="(max-width: 560px) calc(50vw - 16px), (max-width: 860px) calc(33vw - 20px), 252px"
                          className="ep-card-img"
                          style={{ objectFit: "cover" }}
                          unoptimized
                        />
                      ) : (
                        <div
                          style={{
                            position: "absolute",
                            inset: 0,
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            justifyContent: "center",
                            gap: 5,
                          }}
                        >
                          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgba(167,139,250,0.3)" strokeWidth="1.5">
                            <rect x="2" y="3" width="20" height="14" rx="2" />
                            <path d="M8 21h8M12 17v4" />
                          </svg>
                          <span style={{ fontSize: 9, color: "rgba(255,255,255,0.18)", fontWeight: 500 }}>
                            No Preview
                          </span>
                        </div>
                      )}

                      {/* Hover overlay */}
                      <div
                        className="ep-overlay absolute inset-0"
                        style={{ background: "rgba(0,0,0,0.4)" }}
                      />

                      {/* Play button */}
                      <div
                        className="ep-play absolute inset-0"
                        style={{ display: "flex", alignItems: "center", justifyContent: "center" }}
                      >
                        <div
                          style={{
                            width: 36,
                            height: 36,
                            borderRadius: "50%",
                            background: "rgba(124,58,237,0.9)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            boxShadow: "0 0 20px rgba(124,58,237,0.65)",
                            border: "1.5px solid rgba(167,139,250,0.4)",
                          }}
                        >
                          <svg width="11" height="11" viewBox="0 0 24 24" fill="#fff" style={{ marginLeft: 2 }}>
                            <polygon points="5,3 19,12 5,21" />
                          </svg>
                        </div>
                      </div>

                      {/* S·E badge — bottom left */}
                      <div
                        style={{
                          position: "absolute",
                          bottom: hasProgress ? 9 : 6,
                          left: 6,
                          fontSize: 9,
                          fontWeight: 700,
                          color: "#fff",
                          background: "rgba(0,0,0,0.75)",
                          backdropFilter: "blur(6px)",
                          padding: "2px 6px",
                          borderRadius: 5,
                          letterSpacing: "0.04em",
                          transition: "bottom 0.2s ease",
                        }}
                      >
                        S{ep.season_number}·E{ep.episode_number}
                      </div>

                      {/* ── Watched checkmark badge — top right ── */}
                      {isWatched && (
                        <div
                          style={{
                            position: "absolute",
                            top: 6,
                            right: 6,
                            width: 20,
                            height: 20,
                            borderRadius: "50%",
                            background: "#ef4444",
                            boxShadow: "0 0 8px rgba(239,68,68,0.5)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            zIndex: 10,
                          }}
                        >
                          <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="1,6 4,9 11,3" />
                          </svg>
                        </div>
                      )}

                      {/* ── Mark as Watched button — top right (only for auth, not-yet-watched) ── */}
                      {user && !isWatched && (
                        <button
                          className="ep-mark-btn"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            markAsWatched(ep);
                          }}
                          title="Mark as watched"
                          style={{
                            position: "absolute",
                            top: 6,
                            right: 6,
                            width: 22,
                            height: 22,
                            borderRadius: "50%",
                            background: "rgba(0,0,0,0.72)",
                            backdropFilter: "blur(4px)",
                            border: "1.5px solid rgba(255,255,255,0.22)",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            zIndex: 10,
                            padding: 0,
                          }}
                        >
                          <svg width="9" height="9" viewBox="0 0 12 12" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="1,6 4,9 11,3" />
                          </svg>
                        </button>
                      )}

                      {/* ── Progress bar — bottom of thumbnail ── */}
                      {hasProgress && (
                        <div
                          style={{
                            position: "absolute",
                            bottom: 0,
                            left: 0,
                            right: 0,
                            height: 3,
                            background: "rgba(0,0,0,0.35)",
                          }}
                        >
                          <div
                            style={{
                              height: "100%",
                              width: `${Math.min(progress, 100)}%`,
                              background: "#ef4444",
                              borderRadius: "0 2px 2px 0",
                              transition: "width 0.6s ease",
                            }}
                          />
                        </div>
                      )}
                    </div>

                    {/* Card info — compact 2-line layout */}
                    <div style={{ marginTop: 7 }}>
                      {/* Line 1: episode name */}
                      <p
                        style={{
                          fontSize: 12,
                          fontWeight: 600,
                          color: isWatched ? "rgba(255,255,255,0.45)" : "#ddd",
                          lineHeight: 1.3,
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                          marginBottom: 4,
                          transition: "color 0.2s ease",
                        }}
                      >
                        {ep.name}
                      </p>

                      {/* Line 2: Ep N badge · S·E · date · watched label */}
                      <div style={{ display: "flex", alignItems: "center", gap: 4, overflow: "hidden" }}>
                        <span
                          style={{
                            fontSize: 9,
                            fontWeight: 800,
                            color: isWatched ? "#ef4444" : "#a78bfa",
                            background: isWatched ? "rgba(239,68,68,0.12)" : ACCENT_SOFT,
                            border: `1px solid ${isWatched ? "rgba(239,68,68,0.25)" : ACCENT_BORDER}`,
                            padding: "1px 5px",
                            borderRadius: 4,
                            letterSpacing: "0.04em",
                            flexShrink: 0,
                            transition: "color 0.2s, background 0.2s, border-color 0.2s",
                          }}
                        >
                          {isWatched ? "Watched" : `Ep ${ep.episode_number}`}
                        </span>
                        {!isWatched && (
                          <span style={{ fontSize: 9, color: "rgba(255,255,255,0.28)", fontWeight: 500, flexShrink: 0 }}>
                            S{ep.season_number}·E{ep.episode_number}
                          </span>
                        )}
                        {dateStr && (
                          <>
                            <span style={{ fontSize: 9, color: "rgba(255,255,255,0.15)", flexShrink: 0 }}>·</span>
                            <span style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                              {dateStr}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}

          {/* Empty state */}
          {!loading && displayEpisodes.length === 0 && (
            <p style={{ color: "rgba(255,255,255,0.25)", fontSize: 13, padding: "20px 0" }}>
              No episodes available.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
