import Link from "next/link";

export default function AuthHeader({ subtitle, siteName }: { subtitle: string, siteName: string }) {
    return (
        <div style={{ textAlign: "center", marginBottom: 36 }}>
            <Link href="/" style={{ textDecoration: "none" }}>
                <span
                    style={{
                        fontSize: 18,
                        fontWeight: 900,
                        letterSpacing: "0.2em",
                        textTransform: "uppercase",
                        background: "linear-gradient(135deg, #c4b5fd 0%, #7c3aed 100%)",
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                        backgroundClip: "text",
                    }}
                >
                    {siteName.toUpperCase()}
                </span>
            </Link>
            <p style={{ marginTop: 8, fontSize: 13, color: "rgba(255,255,255,0.35)" }}>
                {subtitle}
            </p>
        </div>
    );
}
