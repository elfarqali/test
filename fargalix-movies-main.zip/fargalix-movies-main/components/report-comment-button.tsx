"use client";

import { useState } from "react";
import { Flag, X } from "lucide-react";
import { submitCommentReport } from "@/lib/actions/report";

export function ReportCommentButton({ commentId }: { commentId: string }) {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [reason, setReason] = useState("");
    const [success, setSuccess] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!reason.trim()) return;

        setLoading(true);
        setError("");

        try {
            const result = await submitCommentReport(commentId, reason);
            if (result?.error) {
                setError(result.error);
            } else {
                setSuccess(true);
                setTimeout(() => setOpen(false), 2000);
            }
        } catch (err: any) {
            setError("Failed to submit report");
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <button
                onClick={() => { setOpen(true); setSuccess(false); setReason(""); setError(""); }}
                title="Report comment"
                style={{
                    display: "inline-flex", alignItems: "center", justifyContent: "center",
                    width: 24, height: 24, borderRadius: 6, padding: 0,
                    background: "transparent", border: "1px solid transparent",
                    color: "rgba(255,255,255,0.3)", cursor: "pointer",
                    transition: "all 0.15s ease",
                }}
                className="hover:bg-yellow-500/10 hover:text-yellow-400 hover:border-yellow-500/20"
            >
                <Flag size={12} />
            </button>

            {open && (
                <div style={{
                    position: "fixed", inset: 0, zIndex: 9999,
                    background: "rgba(0,0,0,0.8)", backdropFilter: "blur(4px)",
                    display: "flex", alignItems: "center", justifyContent: "center", padding: 20
                }}>
                    <div style={{
                        background: "#0b0f1a", width: "100%", maxWidth: 400,
                        borderRadius: 16, border: "1px solid rgba(124,58,237,0.2)",
                        boxShadow: "0 24px 64px rgba(0,0,0,0.5)", overflow: "hidden"
                    }}>
                        <div style={{
                            padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.05)",
                            display: "flex", alignItems: "center", justifyContent: "space-between"
                        }}>
                            <h3 style={{ fontSize: 15, fontWeight: 700, color: "#fff", margin: 0 }}>Report Comment</h3>
                            <button
                                onClick={() => setOpen(false)}
                                style={{ background: "transparent", border: "none", color: "rgba(255,255,255,0.5)", cursor: "pointer" }}
                            >
                                <X size={18} />
                            </button>
                        </div>

                        <div style={{ padding: 20 }}>
                            {success ? (
                                <div style={{ textAlign: "center", color: "#34d399", fontSize: 14, fontWeight: 600, padding: "20px 0" }}>
                                    Report submitted successfully. Thank you!
                                </div>
                            ) : (
                                <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                                    {error && (
                                        <div style={{ padding: "8px 12px", background: "rgba(239,68,68,0.1)", color: "#fca5a5", fontSize: 12, borderRadius: 6 }}>
                                            {error}
                                        </div>
                                    )}

                                    <div>
                                        <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.5)", marginBottom: 8 }}>
                                            Reason for reporting (Spam, Harassment, Spoilers, etc.)
                                        </label>
                                        <textarea
                                            value={reason} onChange={e => setReason(e.target.value)} required
                                            style={{
                                                width: "100%", height: 100, padding: 12, borderRadius: 8, resize: "none",
                                                background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.1)",
                                                color: "#fff", fontSize: 13, outline: "none"
                                            }}
                                            placeholder="Details about the comment..."
                                        />
                                    </div>

                                    <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
                                        <button
                                            type="button" onClick={() => setOpen(false)}
                                            style={{ padding: "8px 16px", borderRadius: 8, background: "transparent", border: "none", color: "rgba(255,255,255,0.5)", fontSize: 13, fontWeight: 600, cursor: "pointer" }}
                                        >
                                            Cancel
                                        </button>
                                        <button
                                            type="submit" disabled={loading}
                                            style={{ padding: "8px 20px", borderRadius: 8, background: "#eab308", border: "none", color: "#000", fontSize: 13, fontWeight: 800, cursor: loading ? "wait" : "pointer", opacity: loading ? 0.7 : 1 }}
                                        >
                                            {loading ? "Submitting..." : "Submit Report"}
                                        </button>
                                    </div>
                                </form>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}
