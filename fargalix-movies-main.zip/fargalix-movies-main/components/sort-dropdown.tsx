"use client";

import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { ChevronDown } from "lucide-react";
import { useState, useRef, useEffect } from "react";

export type SortOption = "newest" | "oldest" | "score_desc" | "score_asc";

const OPTIONS: { value: SortOption; label: string }[] = [
    { value: "newest", label: "Newest" },
    { value: "oldest", label: "Oldest" },
    { value: "score_desc", label: "Highest Score" },
    { value: "score_asc", label: "Lowest Score" },
];

interface SortDropdownProps {
    defaultSort?: SortOption;
}

export function SortDropdown({ defaultSort = "newest" }: SortDropdownProps) {
    const router = useRouter();
    const pathname = usePathname();
    const searchParams = useSearchParams();

    const current = (searchParams.get("sort") as SortOption) ?? defaultSort;
    const currentLabel = OPTIONS.find((o) => o.value === current)?.label ?? "Sort By";

    const [open, setOpen] = useState(false);
    const ref = useRef<HTMLDivElement>(null);

    // Close on outside click
    useEffect(() => {
        function handler(e: MouseEvent) {
            if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
        }
        document.addEventListener("mousedown", handler);
        return () => document.removeEventListener("mousedown", handler);
    }, []);

    function select(value: SortOption) {
        const params = new URLSearchParams(searchParams.toString());
        params.set("sort", value);
        params.set("page", "1"); // reset to first page on sort change
        router.push(`${pathname}?${params.toString()}`);
        setOpen(false);
    }

    return (
        <div ref={ref} style={{ position: "relative", flexShrink: 0 }}>
            {/* Trigger button */}
            <button
                onClick={() => setOpen((v) => !v)}
                style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "6px 12px",
                    borderRadius: 8,
                    background: open ? "rgba(124,58,237,0.18)" : "rgba(255,255,255,0.05)",
                    border: open
                        ? "1px solid rgba(124,58,237,0.5)"
                        : "1px solid rgba(255,255,255,0.1)",
                    color: open ? "#c4b5fd" : "rgba(255,255,255,0.55)",
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: "pointer",
                    transition: "all 0.15s ease",
                    whiteSpace: "nowrap",
                }}
            >
                <span style={{ color: open ? "#a78bfa" : "rgba(255,255,255,0.3)", fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>
                    Sort
                </span>
                {currentLabel}
                <ChevronDown
                    size={13}
                    style={{
                        transform: open ? "rotate(180deg)" : "rotate(0deg)",
                        transition: "transform 0.2s ease",
                        flexShrink: 0,
                    }}
                />
            </button>

            {/* Dropdown panel */}
            {open && (
                <div
                    style={{
                        position: "absolute",
                        top: "calc(100% + 6px)",
                        right: 0,
                        minWidth: 160,
                        background: "#111827",
                        border: "1px solid rgba(124,58,237,0.28)",
                        borderRadius: 12,
                        boxShadow: "0 16px 48px rgba(0,0,0,0.75), 0 0 0 1px rgba(124,58,237,0.08)",
                        zIndex: 50,
                        overflow: "hidden",
                        padding: "4px 0",
                    }}
                >
                    {OPTIONS.map((opt) => {
                        const isActive = opt.value === current;
                        return (
                            <button
                                key={opt.value}
                                onClick={() => select(opt.value)}
                                style={{
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "space-between",
                                    width: "100%",
                                    padding: "9px 14px",
                                    background: isActive ? "rgba(124,58,237,0.15)" : "transparent",
                                    border: "none",
                                    color: isActive ? "#c4b5fd" : "rgba(255,255,255,0.65)",
                                    fontSize: 13,
                                    fontWeight: isActive ? 700 : 400,
                                    cursor: "pointer",
                                    transition: "background 0.12s ease, color 0.12s ease",
                                    textAlign: "left",
                                    gap: 10,
                                }}
                                className="hover:bg-white/[0.06] hover:text-white"
                            >
                                {opt.label}
                                {isActive && (
                                    <span style={{ color: "#a78bfa", fontSize: 14, lineHeight: 1, flexShrink: 0 }}>✓</span>
                                )}
                            </button>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
