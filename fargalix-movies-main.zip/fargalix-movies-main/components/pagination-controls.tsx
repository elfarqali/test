"use client";

import { usePathname, useSearchParams } from "next/navigation";
import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface PaginationControlsProps {
  currentPage: number;
  totalPages: number;
}

export function PaginationControls({ currentPage, totalPages }: PaginationControlsProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const cappedTotal = Math.min(totalPages, 500);

  function pageHref(page: number) {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(page));
    return `${pathname}?${params.toString()}`;
  }

  function getPageNumbers(): number[] {
    const windowSize = 3;
    // Start the window so that currentPage sits in the middle where possible.
    let start = currentPage - 1;
    // Clamp: don't go below 1, don't let the window exceed cappedTotal.
    start = Math.max(1, Math.min(start, cappedTotal - windowSize + 1));
    const end = Math.min(start + windowSize - 1, cappedTotal);
    const pages: number[] = [];
    for (let i = start; i <= end; i++) pages.push(i);
    return pages;
  }

  const pageNumbers = getPageNumbers();
  const prevDisabled = currentPage <= 1;
  const nextDisabled = currentPage >= cappedTotal;

  const btnBase: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    width: 30,
    height: 30,
    borderRadius: 4,
    fontSize: 11,
    fontWeight: 600,
    border: "1px solid rgba(255,255,255,0.1)",
    backgroundColor: "#131929",
    color: "rgba(255,255,255,0.6)",
    textDecoration: "none",
    transition: "all 0.15s",
  };

  const btnActive: React.CSSProperties = {
    ...btnBase,
    backgroundColor: "#7c3aed",
    border: "1px solid #7c3aed",
    color: "#fff",
  };

  const btnDisabled: React.CSSProperties = {
    ...btnBase,
    opacity: 0.3,
    cursor: "not-allowed",
  };

  return (
    <nav
      aria-label="Pagination"
      style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 4, padding: "24px 0", flexWrap: "wrap" }}
    >
      {prevDisabled ? (
        <span style={btnDisabled}><ChevronLeft style={{ width: 14, height: 14 }} /></span>
      ) : (
        <Link href={pageHref(currentPage - 1)} style={btnBase} aria-label="Previous page">
          <ChevronLeft style={{ width: 14, height: 14 }} />
        </Link>
      )}

      {pageNumbers.map((page) => (
        <Link
          key={page}
          href={pageHref(page)}
          aria-current={page === currentPage ? "page" : undefined}
          style={page === currentPage ? btnActive : btnBase}
        >
          {page}
        </Link>
      ))}

      {nextDisabled ? (
        <span style={btnDisabled}><ChevronRight style={{ width: 14, height: 14 }} /></span>
      ) : (
        <Link href={pageHref(currentPage + 1)} style={btnBase} aria-label="Next page">
          <ChevronRight style={{ width: 14, height: 14 }} />
        </Link>
      )}
    </nav>
  );
}
