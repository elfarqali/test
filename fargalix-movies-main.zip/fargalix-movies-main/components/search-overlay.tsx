"use client";

import { useState, useEffect, useRef } from "react";
import { Search, X } from "lucide-react";
import { useRouter } from "next/navigation";

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  // Focus & reset on open/close
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 60);
    } else {
      setQuery("");
    }
  }, [isOpen]);

  // Escape to close
  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isOpen, onClose]);

  // Lock body scroll
  useEffect(() => {
    if (isOpen) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    router.push(`/search?q=${encodeURIComponent(query.trim())}`);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[300]"
      style={{ animation: "searchOverlayIn 0.18s ease forwards" }}
    >
      {/* Blurred dark backdrop — click to close */}
      <div
        className="absolute inset-0"
        style={{
          backdropFilter: "blur(18px) brightness(0.45)",
          WebkitBackdropFilter: "blur(18px) brightness(0.45)",
          backgroundColor: "rgba(0,0,0,0.55)",
        }}
        onClick={onClose}
      />

      {/* Search panel */}
      <div
        className="relative mx-auto px-4"
        style={{ maxWidth: 660, paddingTop: 68 }}
      >
        {/* ── Search input ── */}
        <form onSubmit={handleSubmit}>
          <div
            className="flex items-center gap-3 rounded-2xl px-4"
            style={{
              height: 54,
              background: "rgba(22,22,26,0.97)",
              border: "1px solid rgba(255,255,255,0.13)",
              boxShadow:
                "0 2px 0 rgba(255,255,255,0.04) inset, 0 8px 32px rgba(0,0,0,0.7)",
            }}
          >
            <Search size={18} className="shrink-0 text-white/40" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search movies & series..."
              className="flex-1 bg-transparent text-white text-[15px] outline-none placeholder:text-white/25 font-light"
              style={{ caretColor: "#818cf8" }}
              autoComplete="off"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="shrink-0 text-white/30 hover:text-white/70 transition-colors"
              >
                <X size={16} />
              </button>
            )}
            <button
              type="submit"
              className="shrink-0 flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-[13px] font-semibold transition-all hover:opacity-90"
              style={{
                backgroundColor: "#7c3aed",
                color: "#fff",
                boxShadow: "0 2px 8px rgba(124,58,237,0.35)",
              }}
            >
              Search
            </button>
          </div>
        </form>

        {/* Keyboard hint */}
        <p
          className="mt-4 text-center text-[11px] tracking-wider select-none"
          style={{ color: "rgba(255,255,255,0.18)" }}
        >
          <kbd
            className="rounded px-1.5 py-0.5 font-mono"
            style={{ background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.3)" }}
          >
            ↵
          </kbd>{" "}
          search &nbsp;·&nbsp;{" "}
          <kbd
            className="rounded px-1.5 py-0.5 font-mono"
            style={{ background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.3)" }}
          >
            Esc
          </kbd>{" "}
          close
        </p>
      </div>
    </div>
  );
}
