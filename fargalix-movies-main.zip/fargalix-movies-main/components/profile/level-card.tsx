"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { LevelData } from "@/lib/level";

interface Props {
  levelData: LevelData;
  username: string;
  avatarUrl: string | null;
}

// Confetti particle
interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
}

const CONFETTI_COLORS = [
  "#7c3aed","#a78bfa","#c4b5fd","#f59e0b","#34d399","#f472b6","#60a5fa",
];

export function ProfileLevelCard({ levelData, username, avatarUrl }: Props) {
  const { level, hoursAtCurrentLevel, hoursNeeded, progressPercent, isMaxLevel } = levelData;

  const [barWidth, setBarWidth] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);
  const [particles, setParticles] = useState<Particle[]>([]);
  const animFrameRef = useRef<number | null>(null);
  const initials = username.slice(0, 2).toUpperCase();

  // Animate XP bar on mount
  useEffect(() => {
    const timer = setTimeout(() => setBarWidth(progressPercent), 150);
    return () => clearTimeout(timer);
  }, [progressPercent]);

  // Level-up celebration — check localStorage for previous level
  useEffect(() => {
    const key = "sv_user_level";
    const prev = Number(localStorage.getItem(key) ?? 0);
    if (prev > 0 && level > prev) {
      triggerCelebration();
    }
    localStorage.setItem(key, String(level));
  }, [level]);

  function triggerCelebration() {
    setShowCelebration(true);
    const newParticles: Particle[] = Array.from({ length: 60 }, (_, i) => ({
      id: i,
      x: 50 + (Math.random() - 0.5) * 20,
      y: 40,
      vx: (Math.random() - 0.5) * 4,
      vy: -(Math.random() * 4 + 2),
      color: CONFETTI_COLORS[Math.floor(Math.random() * CONFETTI_COLORS.length)],
      size: Math.random() * 8 + 4,
      life: 1,
    }));
    setParticles(newParticles);

    let frame = 0;
    function tick() {
      frame++;
      setParticles((prev) =>
        prev
          .map((p) => ({
            ...p,
            x: p.x + p.vx,
            y: p.y + p.vy + frame * 0.05,
            vy: p.vy + 0.12,
            life: p.life - 0.015,
          }))
          .filter((p) => p.life > 0)
      );
      if (frame < 160) {
        animFrameRef.current = requestAnimationFrame(tick);
      } else {
        setShowCelebration(false);
        setParticles([]);
      }
    }
    animFrameRef.current = requestAnimationFrame(tick);
  }

  useEffect(() => {
    return () => { if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current); };
  }, []);

  return (
    <>
      {/* Celebration overlay */}
      {showCelebration && (
        <div
          style={{
            position: "fixed", inset: 0, pointerEvents: "none",
            zIndex: 9999, overflow: "hidden",
          }}
        >
          {particles.map((p) => (
            <div
              key={p.id}
              style={{
                position: "absolute",
                left: `${p.x}%`,
                top: `${p.y}%`,
                width: p.size,
                height: p.size,
                borderRadius: Math.random() > 0.5 ? "50%" : "2px",
                background: p.color,
                opacity: p.life,
                transform: `rotate(${p.x * 3}deg)`,
              }}
            />
          ))}
          <div
            style={{
              position: "absolute",
              top: "20%",
              left: "50%",
              transform: "translateX(-50%)",
              background: "linear-gradient(135deg,#7c3aed,#5b21b6)",
              color: "#fff",
              padding: "14px 28px",
              borderRadius: 16,
              fontSize: 18,
              fontWeight: 900,
              boxShadow: "0 8px 32px rgba(124,58,237,0.6)",
              border: "1px solid rgba(167,139,250,0.5)",
              textAlign: "center",
              whiteSpace: "nowrap",
            }}
          >
            🎉 Level Up! You&apos;re now Level {level}!
          </div>
        </div>
      )}

      {/* Level card */}
      <div
        style={{
          background: "linear-gradient(135deg, rgba(124,58,237,0.12) 0%, rgba(91,33,182,0.06) 100%)",
          border: "1px solid rgba(124,58,237,0.3)",
          borderRadius: 20,
          padding: "28px 32px",
          boxShadow: "0 8px 40px rgba(124,58,237,0.12), 0 2px 8px rgba(0,0,0,0.3)",
          marginBottom: 32,
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Subtle radial glow */}
        <div
          style={{
            position: "absolute", top: -60, right: -60,
            width: 200, height: 200,
            background: "radial-gradient(circle, rgba(124,58,237,0.18) 0%, transparent 70%)",
            pointerEvents: "none",
          }}
        />

        <div style={{ display: "flex", alignItems: "center", gap: 20, flexWrap: "wrap" }}>
          {/* Avatar */}
          <div style={{ position: "relative", flexShrink: 0 }}>
            <div
              style={{
                width: 80,
                height: 80,
                borderRadius: "50%",
                overflow: "hidden",
                background: avatarUrl
                  ? "transparent"
                  : "linear-gradient(135deg,#7c3aed 0%,#a78bfa 100%)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 28,
                fontWeight: 900,
                color: "#fff",
                border: "3px solid rgba(124,58,237,0.5)",
                boxShadow: "0 0 20px rgba(124,58,237,0.35)",
                position: "relative",
              }}
            >
              {avatarUrl ? (
                <Image src={avatarUrl} alt={username} fill sizes="80px" style={{ objectFit: "cover" }} unoptimized />
              ) : (
                initials
              )}
            </div>
            {/* Level badge on avatar */}
            <div
              style={{
                position: "absolute",
                bottom: -4, right: -4,
                width: 28, height: 28,
                borderRadius: "50%",
                background: "linear-gradient(135deg,#7c3aed 0%,#5b21b6 100%)",
                border: "2.5px solid #0b0f1a",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 10,
                fontWeight: 900,
                color: "#fff",
                boxShadow: "0 2px 8px rgba(124,58,237,0.5)",
              }}
            >
              {level}
            </div>
          </div>

          {/* Info */}
          <div style={{ flex: 1, minWidth: 200 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 4, flexWrap: "wrap" }}>
              <h2 style={{ fontSize: 20, fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}>
                @{username}
              </h2>
              {/* Large level badge */}
              <div
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  background: "rgba(124,58,237,0.2)",
                  border: "1px solid rgba(124,58,237,0.45)",
                  borderRadius: 20,
                  padding: "4px 12px",
                }}
              >
                <div
                  style={{
                    width: 20, height: 20, borderRadius: "50%",
                    background: "linear-gradient(135deg,#a78bfa,#7c3aed)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 9, fontWeight: 900, color: "#fff",
                  }}
                >
                  {level}
                </div>
                <span style={{ fontSize: 12, fontWeight: 800, color: "#c4b5fd", letterSpacing: "0.03em" }}>
                  {isMaxLevel ? "MAX LEVEL" : `LEVEL ${level}`}
                </span>
              </div>
            </div>

            {/* XP bar label */}
            {!isMaxLevel && (
              <div style={{ marginBottom: 6 }}>
                <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>
                  XP to Level {level + 1}
                </span>
              </div>
            )}

            {/* XP bar */}
            <div
              style={{
                width: "100%",
                height: 10,
                borderRadius: 20,
                background: "rgba(255,255,255,0.08)",
                overflow: "hidden",
                position: "relative",
                boxShadow: "inset 0 1px 3px rgba(0,0,0,0.3)",
              }}
            >
              {/* Filled bar */}
              <div
                style={{
                  height: "100%",
                  width: `${barWidth}%`,
                  borderRadius: 20,
                  background: isMaxLevel
                    ? "linear-gradient(90deg,#f59e0b,#ef4444)"
                    : "linear-gradient(90deg,#7c3aed,#a78bfa,#c4b5fd)",
                  transition: "width 1.2s cubic-bezier(0.22,1,0.36,1)",
                  boxShadow: isMaxLevel
                    ? "0 0 12px rgba(245,158,11,0.6)"
                    : "0 0 12px rgba(124,58,237,0.7)",
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                {/* Shimmer sweep */}
                <div
                  style={{
                    position: "absolute", top: 0, left: "-100%",
                    width: "60%", height: "100%",
                    background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent)",
                    animation: "xp-shimmer 2.5s ease-in-out infinite",
                  }}
                />
              </div>
            </div>

            {!isMaxLevel && (
              <p style={{ fontSize: 11, color: "rgba(255,255,255,0.28)", marginTop: 6 }}>
                {(hoursNeeded - hoursAtCurrentLevel).toFixed(1)} more hours to reach Level {level + 1}
              </p>
            )}

            {isMaxLevel && (
              <p style={{ fontSize: 11, fontWeight: 700, color: "#f59e0b", marginTop: 6 }}>
                🏆 Maximum level achieved! Legendary watcher.
              </p>
            )}
          </div>
        </div>

        {/* Shimmer keyframe */}
        <style>{`
          @keyframes xp-shimmer {
            0%   { left: -100%; }
            60%  { left: 110%; }
            100% { left: 110%; }
          }
        `}</style>
      </div>
    </>
  );
}
