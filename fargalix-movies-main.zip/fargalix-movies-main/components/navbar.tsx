"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { Search, Menu, X, User, Settings, LogOut } from "lucide-react";
import { useState, useEffect } from "react";
import SearchOverlay from "@/components/search-overlay";
import { UserMenu } from "@/components/auth/user-menu";
import { NotificationBell } from "@/components/notifications/notification-bell";
import { useAuth } from "@/components/auth/auth-provider";

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/popular", label: "Popular" },
  { href: "/trending", label: "Trending" },
  { href: "/movies", label: "Movies" },
  { href: "/series", label: "Series" },
  { href: "/live", label: "Sport" },
  { href: "/discussions", label: "Discuss" },
  { href: "/adblock-guide", label: "AdBlock Guide" },
] as const;

export function Navbar({ siteName = "STREAMVAULT" }: { siteName?: string }) {
  const pathname = usePathname();
  const { user, signOut } = useAuth();
  const [searchOpen, setSearchOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Close overlay / drawer on route change
  useEffect(() => {
    setSearchOpen(false);
    setDrawerOpen(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  // Lock body scroll when drawer is open
  useEffect(() => {
    document.body.style.overflow = drawerOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [drawerOpen]);

  return (
    <>
      <header
        className="fixed top-0 left-0 right-0 z-50"
        style={{
          height: 58,
          backgroundColor: "rgba(11,15,26,0.88)",
          borderBottom: "1px solid rgba(124,58,237,0.18)",
          backdropFilter: "blur(20px) saturate(180%)",
          WebkitBackdropFilter: "blur(20px) saturate(180%)",
        }}
      >
        <div className="mx-auto flex h-full max-w-[1400px] items-center gap-4 px-4">

          {/* Hamburger — mobile only */}
          <button
            className="flex md:hidden items-center justify-center flex-shrink-0"
            onClick={() => setDrawerOpen(true)}
            aria-label="Open menu"
            style={{
              width: 34, height: 34, borderRadius: 8,
              background: "transparent", border: "none",
              color: "rgba(255,255,255,0.55)", cursor: "pointer",
            }}
          >
            <Menu size={20} />
          </button>

          {/* Logo */}
          <Link
            href="/"
            className="flex-shrink-0 select-none"
            style={{ textDecoration: "none" }}
          >
            <span
              className="font-black uppercase tracking-widest"
              style={{
                fontSize: 15,
                letterSpacing: "0.2em",
                background: "linear-gradient(135deg, #c4b5fd 0%, #7c3aed 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              {siteName.toUpperCase()}
            </span>
          </Link>

          {/* Vertical divider — desktop only */}
          <div className="hidden md:block" style={{ width: 1, height: 16, backgroundColor: "rgba(255,255,255,0.1)", flexShrink: 0 }} />

          {/* Nav links — desktop only */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map(({ href, label }) => {
              const isActive =
                href === "/" ? pathname === "/" : pathname.startsWith(href);
              return (
                <Link
                  key={href}
                  href={href}
                  style={{
                    padding: "4px 11px",
                    fontSize: 14,
                    fontWeight: isActive ? 600 : 400,
                    color: isActive ? "#e2d9f3" : "rgba(255,255,255,0.45)",
                    backgroundColor: isActive ? "rgba(124,58,237,0.18)" : "transparent",
                    borderRadius: 6,
                    border: isActive ? "1px solid rgba(124,58,237,0.35)" : "1px solid transparent",
                    transition: "all 0.15s ease",
                    textDecoration: "none",
                    whiteSpace: "nowrap" as const,
                  }}
                  className="hover:text-white/80"
                >
                  {label}
                </Link>
              );
            })}
          </nav>

          {/* Spacer */}
          <div className="flex-1" />

          {/* Search icon */}
          <button
            onClick={() => setSearchOpen(true)}
            aria-label="Open search"
            className="flex items-center justify-center transition-colors"
            style={{
              width: 34, height: 34, borderRadius: 8,
              background: "transparent", border: "none",
              color: "rgba(255,255,255,0.45)", cursor: "pointer",
            }}
          >
            <Search size={17} />
          </button>

          {/* Notification bell */}
          <NotificationBell />

          {/* User menu */}
          <UserMenu />
        </div>
      </header>

      {/* ── Mobile Drawer ─────────────────────────────────────────────────── */}

      {/* Backdrop */}
      <div
        onClick={() => setDrawerOpen(false)}
        style={{
          position: "fixed", inset: 0, zIndex: 60,
          background: "rgba(0,0,0,0.65)",
          backdropFilter: "blur(4px)",
          WebkitBackdropFilter: "blur(4px)",
          opacity: drawerOpen ? 1 : 0,
          pointerEvents: drawerOpen ? "auto" : "none",
          transition: "opacity 0.28s ease",
        }}
      />

      {/* Drawer panel */}
      <aside
        style={{
          position: "fixed", top: 0, left: 0, bottom: 0, zIndex: 61,
          width: 260,
          background: "linear-gradient(160deg, rgba(17,12,36,0.98) 0%, rgba(11,15,26,0.99) 100%)",
          borderRight: "1px solid rgba(124,58,237,0.22)",
          backdropFilter: "blur(24px) saturate(180%)",
          WebkitBackdropFilter: "blur(24px) saturate(180%)",
          transform: drawerOpen ? "translateX(0)" : "translateX(-100%)",
          transition: "transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
          display: "flex", flexDirection: "column",
          boxShadow: drawerOpen ? "8px 0 40px rgba(0,0,0,0.6), 2px 0 0 rgba(124,58,237,0.12)" : "none",
          willChange: "transform",
        }}
      >
        {/* Drawer header */}
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "0 18px", height: 58,
          borderBottom: "1px solid rgba(124,58,237,0.15)",
          flexShrink: 0,
        }}>
          <span
            className="font-black uppercase tracking-widest"
            style={{
              fontSize: 13, letterSpacing: "0.2em",
              background: "linear-gradient(135deg, #c4b5fd 0%, #7c3aed 100%)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            {siteName.toUpperCase()}
          </span>

          <button
            onClick={() => setDrawerOpen(false)}
            aria-label="Close menu"
            style={{
              width: 30, height: 30, borderRadius: 8,
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.1)",
              color: "rgba(255,255,255,0.5)",
              cursor: "pointer", display: "flex",
              alignItems: "center", justifyContent: "center",
            }}
          >
            <X size={15} />
          </button>
        </div>

        {/* Nav links */}
        <nav style={{ padding: "12px 10px", flex: 1, overflowY: "auto" }}>
          {navLinks.map(({ href, label }, i) => {
            const isActive =
              href === "/" ? pathname === "/" : pathname.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                onClick={() => setDrawerOpen(false)}
                style={{
                  display: "flex", alignItems: "center", gap: 12,
                  padding: "11px 14px",
                  marginBottom: 2,
                  borderRadius: 10,
                  textDecoration: "none",
                  fontSize: 15, fontWeight: isActive ? 700 : 500,
                  color: isActive ? "#e2d9f3" : "rgba(255,255,255,0.48)",
                  backgroundColor: isActive ? "rgba(124,58,237,0.18)" : "transparent",
                  border: isActive ? "1px solid rgba(124,58,237,0.3)" : "1px solid transparent",
                  transition: "all 0.15s ease",
                  // Staggered entrance
                  transitionDelay: drawerOpen ? `${i * 30}ms` : "0ms",
                }}
                className="hover:bg-white/5 hover:text-white/80"
              >
                {/* Active indicator bar */}
                <span style={{
                  width: 3, height: 16, borderRadius: 2, flexShrink: 0,
                  background: isActive
                    ? "linear-gradient(to bottom, #a78bfa, #7c3aed)"
                    : "rgba(255,255,255,0.1)",
                  transition: "background 0.15s ease",
                }} />
                {label}
              </Link>
            );
          })}
        </nav>

        {/* ── Drawer profile section ── */}
        <div style={{
          padding: "14px 12px",
          borderTop: "1px solid rgba(124,58,237,0.15)",
          flexShrink: 0,
        }}>
          {user ? (
            <>
              {/* User identity row */}
              <div style={{
                display: "flex", alignItems: "center", gap: 10,
                padding: "10px 12px",
                borderRadius: 10,
                background: "rgba(124,58,237,0.08)",
                border: "1px solid rgba(124,58,237,0.15)",
                marginBottom: 8,
              }}>
                <div style={{
                  width: 36, height: 36, borderRadius: "50%", flexShrink: 0,
                  background: user.avatarUrl
                    ? "transparent"
                    : "linear-gradient(135deg, #7c3aed 0%, #a78bfa 100%)",
                  border: "2px solid rgba(124,58,237,0.4)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 12, fontWeight: 700, color: "#fff",
                  overflow: "hidden", position: "relative",
                }}>
                  {user.avatarUrl ? (
                    <Image src={user.avatarUrl} alt={user.username} fill sizes="36px" style={{ objectFit: "cover" }} unoptimized />
                  ) : user.username.slice(0, 2).toUpperCase()}
                </div>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <p style={{ fontSize: 12, fontWeight: 700, color: "#e2d9f3" }}>@{user.username}</p>
                  <p style={{ fontSize: 10, color: "rgba(255,255,255,0.32)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user.email}</p>
                </div>
                {user.role === "ADMIN" && (
                  <span style={{
                    fontSize: 8, fontWeight: 800, letterSpacing: "0.1em",
                    textTransform: "uppercase", color: "#a78bfa",
                    background: "rgba(124,58,237,0.18)",
                    border: "1px solid rgba(124,58,237,0.3)",
                    padding: "2px 6px", borderRadius: 4, flexShrink: 0,
                  }}>Admin</span>
                )}
              </div>

              {/* Quick action links */}
              <div style={{ display: "flex", gap: 6 }}>
                <Link href="/profile" onClick={() => setDrawerOpen(false)} style={{
                  flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 5,
                  padding: "8px 0", borderRadius: 8, textDecoration: "none",
                  fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.55)",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  transition: "all 0.15s ease",
                }} className="hover:bg-white/10 hover:text-white">
                  <User size={12} /> Profile
                </Link>
                <Link href="/settings" onClick={() => setDrawerOpen(false)} style={{
                  flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 5,
                  padding: "8px 0", borderRadius: 8, textDecoration: "none",
                  fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.55)",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  transition: "all 0.15s ease",
                }} className="hover:bg-white/10 hover:text-white">
                  <Settings size={12} /> Settings
                </Link>
                <button onClick={() => { setDrawerOpen(false); signOut(); }} style={{
                  flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 5,
                  padding: "8px 0", borderRadius: 8,
                  fontSize: 11, fontWeight: 600, color: "rgba(239,68,68,0.7)",
                  background: "rgba(239,68,68,0.06)",
                  border: "1px solid rgba(239,68,68,0.15)",
                  cursor: "pointer", transition: "all 0.15s ease",
                }} className="hover:bg-red-500/15 hover:text-red-400">
                  <LogOut size={12} /> Out
                </button>
              </div>
            </>
          ) : (
            <div style={{ display: "flex", gap: 8 }}>
              <Link href="/signin" onClick={() => setDrawerOpen(false)} style={{
                flex: 1, textAlign: "center", padding: "9px 0",
                borderRadius: 9, textDecoration: "none",
                fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.6)",
                background: "transparent",
                border: "1px solid rgba(255,255,255,0.12)",
              }}>Sign In</Link>
              <Link href="/signup" onClick={() => setDrawerOpen(false)} style={{
                flex: 1, textAlign: "center", padding: "9px 0",
                borderRadius: 9, textDecoration: "none",
                fontSize: 12, fontWeight: 700, color: "#fff",
                background: "linear-gradient(135deg, #7c3aed 0%, #5b21b6 100%)",
                border: "none",
              }}>Sign Up</Link>
            </div>
          )}
        </div>

        {/* Bottom purple accent strip */}
        <div style={{
          height: 3, flexShrink: 0,
          background: "linear-gradient(90deg, #7c3aed 0%, #a78bfa 50%, transparent 100%)",
          opacity: 0.6,
        }} />
      </aside>

      <SearchOverlay isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
    </>
  );
}
