"use client";

import { useRef, useState, useCallback } from "react";
import { MediaCard } from "@/components/media-card";
import type { TMDBMediaItem } from "@/lib/tmdb";

interface HorizontalRowProps {
  title: string;
  items: TMDBMediaItem[];
  showType?: boolean;
}

export function HorizontalRow({ title, items, showType = false }: HorizontalRowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [hovering, setHovering] = useState(false);

  const scroll = useCallback((dir: "left" | "right") => {
    const el = scrollRef.current;
    if (!el) return;
    const amount = el.clientWidth * 0.75;
    el.scrollBy({ left: dir === "right" ? amount : -amount, behavior: "smooth" });
  }, []);

  if (!items.length) return null;

  const btnStyle: React.CSSProperties = {
    position: "absolute",
    top: "50%",
    transform: "translateY(-50%)",
    zIndex: 10,
    width: 38,
    height: 38,
    borderRadius: "50%",
    border: "1px solid rgba(255,255,255,0.15)",
    backgroundColor: "rgba(10,10,10,0.9)",
    color: "#fff",
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "opacity 0.25s, background-color 0.2s, transform 0.2s",
    opacity: hovering ? 1 : 0,
    pointerEvents: hovering ? "auto" : "none",
    padding: 0,
    boxShadow: "0 2px 12px rgba(0,0,0,0.5)",
  };

  return (
    <section
      style={{ marginBottom: 40, position: "relative" }}
      onMouseEnter={() => setHovering(true)}
      onMouseLeave={() => setHovering(false)}
    >
      {/* Section title */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          marginBottom: 16,
          paddingLeft: 24,
          paddingRight: 24,
        }}
      >
        <span
          style={{
            display: "inline-block",
            width: 4,
            height: 18,
            borderRadius: 2,
            background: "linear-gradient(180deg, #a78bfa 0%, #7c3aed 100%)",
            flexShrink: 0,
            boxShadow: "0 0 8px rgba(124,58,237,0.45)",
          }}
        />
        <h2
          style={{
            color: "#ffffff",
            fontSize: 16,
            fontWeight: 700,
            margin: 0,
            padding: 0,
            letterSpacing: "-0.02em",
          }}
        >
          {title}
        </h2>
      </div>

      {/* Left scroll button */}
      <button
        onClick={() => scroll("left")}
        aria-label="Scroll left"
        style={{ ...btnStyle, left: 6 }}
      >
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="15 18 9 12 15 6" />
        </svg>
      </button>

      {/* Right scroll button */}
      <button
        onClick={() => scroll("right")}
        aria-label="Scroll right"
        style={{ ...btnStyle, right: 6 }}
      >
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="9 18 15 12 9 6" />
        </svg>
      </button>

      {/* Scrollable row */}
      <div
        ref={scrollRef}
        style={{
          display: "flex",
          flexDirection: "row",
          flexWrap: "nowrap",
          gap: 14,
          overflowX: "auto",
          overflowY: "visible",
          paddingLeft: 24,
          paddingRight: 24,
          paddingBottom: 10,
          scrollbarWidth: "none",
          msOverflowStyle: "none",
          WebkitOverflowScrolling: "touch",
        } as React.CSSProperties}
      >
        {items.slice(0, 30).map((item) => (
          <div key={`${item.id}-${item.media_type ?? "m"}`} style={{ flexShrink: 0 }}>
            <MediaCard item={item} showType={showType} width={180} />
          </div>
        ))}
      </div>
    </section>
  );
}
