"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Bell, Trash2, ChevronDown, ChevronUp } from "lucide-react";
import { useAuth } from "@/components/auth/auth-provider";

interface Notification {
  id: string;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

function NotificationItem({
  n,
  onMarkRead,
  onDelete,
}: {
  n: Notification;
  onMarkRead: (id: string) => void;
  onDelete: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const isLong = n.message.length > 80;

  return (
    <div
      style={{
        padding: "12px 16px",
        borderBottom: "1px solid rgba(255,255,255,0.04)",
        background: n.read ? "transparent" : "rgba(124,58,237,0.06)",
        transition: "background 0.15s ease",
        position: "relative",
      }}
    >
      <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
        {!n.read && (
          <div
            style={{
              marginTop: 5,
              flexShrink: 0,
              width: 7,
              height: 7,
              borderRadius: "50%",
              background: "#7c3aed",
            }}
          />
        )}
        <div style={{ flex: 1, minWidth: 0, paddingRight: 20 }}>
          <p
            onClick={() => !n.read && onMarkRead(n.id)}
            style={{
              fontSize: 13,
              fontWeight: n.read ? 500 : 700,
              color: n.read ? "rgba(255,255,255,0.6)" : "#e2d9f3",
              cursor: n.read ? "default" : "pointer",
              marginBottom: 3,
            }}
          >
            {n.title}
          </p>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.38)", lineHeight: 1.45 }}>
            <p style={{ whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
              {expanded ? n.message : isLong ? `${n.message.substring(0, 80)}...` : n.message}
            </p>
            {isLong && (
              <button
                onClick={() => setExpanded(!expanded)}
                style={{
                  background: "none", border: "none", padding: 0,
                  fontSize: 11, color: "#a78bfa", cursor: "pointer",
                  marginTop: 4, display: "flex", alignItems: "center", gap: 3, fontWeight: 600
                }}
              >
                {expanded ? (
                  <>Show Less <ChevronUp size={12} /></>
                ) : (
                  <>Show More <ChevronDown size={12} /></>
                )}
              </button>
            )}
          </div>
          <p style={{ fontSize: 10, color: "rgba(255,255,255,0.25)", marginTop: 5 }}>
            {new Date(n.createdAt).toLocaleString("en-US", {
              month: "short",
              day: "numeric",
              hour: "numeric",
              minute: "2-digit",
            })}
          </p>
        </div>

        {/* Delete button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete(n.id);
          }}
          title="Delete Notification"
          style={{
            position: "absolute",
            top: 12,
            right: 12,
            background: "transparent",
            border: "none",
            color: "rgba(239,68,68,0.4)",
            cursor: "pointer",
            padding: 4,
            borderRadius: 4,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
          className="hover:bg-red-500/10 hover:text-red-400 transition-colors"
        >
          <Trash2 size={13} />
        </button>
      </div>
    </div>
  );
}

export function NotificationBell() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const fetchNotifications = useCallback(async () => {
    try {
      const res = await fetch("/api/user/notifications");
      if (!res.ok) return;
      const data = await res.json();
      setNotifications(data.notifications ?? []);
      setUnreadCount(data.unreadCount ?? 0);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    fetchNotifications();
  }, [user, fetchNotifications]);

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const markRead = async (id: string) => {
    await fetch(`/api/user/notifications/${id}`, { method: "PATCH" });
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
    setUnreadCount((c) => Math.max(0, c - 1));
  };

  const markAllRead = async () => {
    await fetch("/api/user/notifications/read-all", { method: "POST" });
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    setUnreadCount(0);
  };

  const deleteNotification = async (id: string) => {
    await fetch(`/api/user/notifications/${id}`, { method: "DELETE" });
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    // Recalculate unread
    setUnreadCount((prev) => {
      const isUnread = notifications.find((n) => n.id === id)?.read === false;
      return isUnread ? Math.max(0, prev - 1) : prev;
    });
  };

  const clearAllNotifications = async () => {
    if (!confirm("Are you sure you want to clear all your notifications? This cannot be undone.")) return;
    await fetch("/api/user/notifications", { method: "DELETE" });
    setNotifications([]);
    setUnreadCount(0);
  };

  if (!user) return null;

  return (
    <div ref={ref} style={{ position: "relative" }}>
      {/* Bell button */}
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="Notifications"
        style={{
          position: "relative",
          width: 34,
          height: 34,
          borderRadius: 8,
          background: "transparent",
          border: "none",
          color: open ? "#c4b5fd" : "rgba(255,255,255,0.45)",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          transition: "color 0.15s ease",
        }}
      >
        <Bell size={17} />
        {unreadCount > 0 && (
          <span
            style={{
              position: "absolute",
              top: 5,
              right: 5,
              width: 16,
              height: 16,
              borderRadius: "50%",
              background: "#7c3aed",
              border: "2px solid rgba(11,15,26,0.9)",
              fontSize: 9,
              fontWeight: 800,
              color: "#fff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              lineHeight: 1,
            }}
          >
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown */}
      {open && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 10px)",
            right: 0,
            width: 340,
            borderRadius: 14,
            background: "#0e1322",
            border: "1px solid rgba(124,58,237,0.22)",
            boxShadow: "0 16px 48px rgba(0,0,0,0.6)",
            zIndex: 9999,
            overflow: "hidden",
          }}
        >
          {/* Header */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "14px 16px 12px",
              borderBottom: "1px solid rgba(255,255,255,0.06)",
            }}
          >
            <span style={{ fontSize: 13, fontWeight: 700, color: "#fff" }}>
              Notifications
              {unreadCount > 0 && (
                <span style={{
                  marginLeft: 8,
                  fontSize: 10, fontWeight: 800,
                  color: "#a78bfa",
                  background: "rgba(124,58,237,0.18)",
                  border: "1px solid rgba(124,58,237,0.3)",
                  padding: "1px 6px", borderRadius: 10,
                }}>
                  {unreadCount} new
                </span>
              )}
            </span>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              {unreadCount > 0 && (
                <button
                  onClick={markAllRead}
                  style={{
                    fontSize: 11, color: "#a78bfa", background: "none",
                    border: "none", cursor: "pointer", fontWeight: 600,
                  }}
                  className="hover:text-purple-300 transition-colors"
                >
                  Mark all read
                </button>
              )}
              {notifications.length > 0 && (
                <button
                  onClick={clearAllNotifications}
                  style={{
                    fontSize: 11, color: "rgba(239,68,68,0.7)", background: "none",
                    border: "none", cursor: "pointer", fontWeight: 600,
                  }}
                  className="hover:text-red-400 transition-colors"
                >
                  Clear All
                </button>
              )}
            </div>
          </div>

          {/* List */}
          <div style={{ maxHeight: 360, overflowY: "auto" }}>
            {notifications.length === 0 ? (
              <div style={{ padding: "32px 16px", textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: 13 }}>
                No notifications yet
              </div>
            ) : (
              notifications.map((n) => (
                <NotificationItem
                  key={n.id}
                  n={n}
                  onMarkRead={markRead}
                  onDelete={deleteNotification}
                />
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
