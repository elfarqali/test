"use client";

import { useState } from "react";
import { Flag, X } from "lucide-react";
import { submitVideoReport } from "@/lib/actions/report";

interface ReportButtonProps {
    mediaId: number;
    mediaType: "MOVIE" | "TV";
    initialSeason?: number;
    initialEpisode?: number;
}

export function ReportButton({ mediaId, mediaType, initialSeason, initialEpisode }: ReportButtonProps) {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [reason, setReason] = useState("");
    const [season, setSeason] = useState(initialSeason ? String(initialSeason) : "");
    const [episode, setEpisode] = useState(initialEpisode ? String(initialEpisode) : "");
    const [success, setSuccess] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!reason.trim()) return;
        if (mediaType === "TV" && (!season || !episode)) {
            setError("Season and episode are required for TV reports.");
            return;
        }

        setLoading(true);
        setError("");

        try {
            const result = await submitVideoReport(
                mediaId,
                mediaType,
                reason,
                mediaType === "TV" ? Number(season) : undefined,
                mediaType === "TV" ? Number(episode) : undefined
            );
            if (result?.error) {
                setError(result.error);
            } else {
                setSuccess(true);
                setTimeout(() => setOpen(false), 2000);
            }
        } catch (err: any) {
            setError("Failed to submit report");
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <button
                onClick={() => { setOpen(true); setSuccess(false); setReason(""); setError(""); }}
                style={{
                    display: "inline-flex", alignItems: "center", gap: 6,
                    padding: "6px 14px", borderRadius: 8, marginTop: 16,
                    background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
                    color: "rgba(255,255,255,0.6)", fontSize: 12, fontWeight: 600, cursor: "pointer",
                    transition: "all 0.2s ease"
                }}
                className="hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/30"
            >
                <Flag size={14} /> Report Video Issue
            </button>

            {open && (
                <div style={{
                    position: "fixed", inset: 0, zIndex: 9999,
                    background: "rgba(0,0,0,0.8)", backdropFilter: "blur(4px)",
                    display: "flex", alignItems: "center", justifyContent: "center", padding: 20
                }}>
                    <div style={{
                        background: "#0b0f1a", width: "100%", maxWidth: 400,
                        borderRadius: 16, border: "1px solid rgba(124,58,237,0.2)",
                        boxShadow: "0 24px 64px rgba(0,0,0,0.5)", overflow: "hidden"
                    }}>
                        <div style={{
                            padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.05)",
                            display: "flex", alignItems: "center", justifyContent: "space-between"
                        }}>
                            <h3 style={{ fontSize: 15, fontWeight: 700, color: "#fff", margin: 0 }}>Report Video Issue</h3>
                            <button
                                onClick={() => setOpen(false)}
                                style={{ background: "transparent", border: "none", color: "rgba(255,255,255,0.5)", cursor: "pointer" }}
                            >
                                <X size={18} />
                            </button>
                        </div>

                        <div style={{ padding: 20 }}>
                            {success ? (
                                <div style={{ textAlign: "center", color: "#34d399", fontSize: 14, fontWeight: 600, padding: "20px 0" }}>
                                    Report submitted successfully. Thank you!
                                </div>
                            ) : (
                                <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                                    {error && (
                                        <div style={{ padding: "8px 12px", background: "rgba(239,68,68,0.1)", color: "#fca5a5", fontSize: 12, borderRadius: 6 }}>
                                            {error}
                                        </div>
                                    )}

                                    {mediaType === "TV" && (
                                        <div style={{ display: "flex", gap: 12 }}>
                                            <div style={{ flex: 1 }}>
                                                <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.5)", marginBottom: 8 }}>
                                                    Season
                                                </label>
                                                <input
                                                    type="number" value={season} onChange={e => setSeason(e.target.value)} required min={1}
                                                    style={{
                                                        width: "100%", padding: "10px 12px", borderRadius: 8,
                                                        background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.1)",
                                                        color: "#fff", fontSize: 13, outline: "none", boxSizing: "border-box"
                                                    }}
                                                    placeholder="e.g. 1"
                                                />
                                            </div>
                                            <div style={{ flex: 1 }}>
                                                <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.5)", marginBottom: 8 }}>
                                                    Episode
                                                </label>
                                                <input
                                                    type="number" value={episode} onChange={e => setEpisode(e.target.value)} required min={1}
                                                    style={{
                                                        width: "100%", padding: "10px 12px", borderRadius: 8,
                                                        background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.1)",
                                                        color: "#fff", fontSize: 13, outline: "none", boxSizing: "border-box"
                                                    }}
                                                    placeholder="e.g. 5"
                                                />
                                            </div>
                                        </div>
                                    )}

                                    <div>
                                        <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.5)", marginBottom: 8 }}>
                                            Explain the issue (e.g., Wrong episode, broken stream, out of sync)
                                        </label>
                                        <textarea
                                            value={reason} onChange={e => setReason(e.target.value)} required
                                            style={{
                                                width: "100%", height: 100, padding: 12, borderRadius: 8, resize: "none",
                                                background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.1)",
                                                color: "#fff", fontSize: 13, outline: "none", boxSizing: "border-box"
                                            }}
                                            placeholder="Please provide details..."
                                        />
                                    </div>

                                    <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
                                        <button
                                            type="button" onClick={() => setOpen(false)}
                                            style={{ padding: "8px 16px", borderRadius: 8, background: "transparent", border: "none", color: "rgba(255,255,255,0.5)", fontSize: 13, fontWeight: 600, cursor: "pointer" }}
                                        >
                                            Cancel
                                        </button>
                                        <button
                                            type="submit" disabled={loading}
                                            style={{ padding: "8px 20px", borderRadius: 8, background: "#ef4444", border: "none", color: "#fff", fontSize: 13, fontWeight: 700, cursor: loading ? "wait" : "pointer", opacity: loading ? 0.7 : 1 }}
                                        >
                                            {loading ? "Submitting..." : "Submit Report"}
                                        </button>
                                    </div>
                                </form>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}
