"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, type ReactNode } from "react";
import Image from "next/image";
import type { TMDBTVEpisode, TMDBTVSeason } from "@/lib/tmdb";
import { WatchHistoryRecorder } from "@/components/watch-history-recorder";
import { TVPlayer } from "@/components/tv-player";
import { EpisodeSection } from "@/components/tv/episode-section";
import { ReportButton } from "@/components/report-button";
import { AdSlot } from "@/components/ad-slot";

/* ─── Types ─────────────────────────────────────────────────── */

interface PlayerConfig {
    id: string;
    name: string;
    movieUrl: string;
    tvUrl: string;
    isDefault: boolean;
}

interface TVClientShellProps {
    show: {
        id: number;
        name: string;
        poster_path: string | null;
        backdrop_path: string | null;
        seasons: TMDBTVSeason[];
        episode_run_time?: number[];
    };
    players: PlayerConfig[];
    /** Pre-fetched episodes for the *default* season (season 1) */
    defaultEpisodes: TMDBTVEpisode[];
    defaultSeason: number;
}

/* ─── Design tokens (keep in sync with the server page) ───── */
const BG = "#0b0f1a";
const ACCENT = "#7c3aed";
const IMAGE_BACKDROP_URL = "https://image.tmdb.org/t/p/w1280";

/* ─────────────────────────────────────────────────────────────
   Inner component that actually reads useSearchParams.
   Wrapped in <Suspense> at export time so the outer page can
   still be statically rendered.
   ──────────────────────────────────────────────────────────── */

function TVClientShellInner({
    show,
    players,
    defaultEpisodes,
    defaultSeason,
}: TVClientShellProps) {
    const searchParams = useSearchParams();

    const validSeasons = show.seasons.filter((s) => s.season_number > 0);
    const computedDefaultSeason = defaultSeason;

    const currentSeason = parseInt(
        searchParams.get("season") ?? String(computedDefaultSeason),
        10
    );
    const currentEpisode = parseInt(
        searchParams.get("episode") ?? "1",
        10
    );
    const isPlaying = searchParams.get("play") === "1";

    // Use pre-fetched episodes for default season
    const episodes = defaultEpisodes;

    const currentEpRuntime = (() => {
        const ep = episodes.find((e) => e.episode_number === currentEpisode);
        return ep?.runtime || show.episode_run_time?.[0] || 40;
    })();

    const backdrop = show.backdrop_path
        ? `${IMAGE_BACKDROP_URL}${show.backdrop_path}`
        : null;

    // Build next-episode URL
    let nextEpisodeUrl: string | undefined;
    const sortedEpisodes = [...episodes].sort(
        (a, b) => a.episode_number - b.episode_number
    );
    const currentEpIndex = sortedEpisodes.findIndex(
        (e) => e.episode_number === currentEpisode
    );
    if (currentEpIndex !== -1) {
        if (currentEpIndex < sortedEpisodes.length - 1) {
            const nextEp = sortedEpisodes[currentEpIndex + 1];
            nextEpisodeUrl = `/tv/${show.id}?season=${currentSeason}&episode=${nextEp.episode_number}&play=1`;
        } else {
            const sortedSeasons = [...validSeasons].sort(
                (a, b) => a.season_number - b.season_number
            );
            const currentSeasonIndex = sortedSeasons.findIndex(
                (s) => s.season_number === currentSeason
            );
            if (
                currentSeasonIndex !== -1 &&
                currentSeasonIndex < sortedSeasons.length - 1
            ) {
                const nextSeason = sortedSeasons[currentSeasonIndex + 1];
                nextEpisodeUrl = `/tv/${show.id}?season=${nextSeason.season_number}&episode=1&play=1`;
            }
        }
    }

    if (!isPlaying) return null;

    return (
        <>
            {/* Record watch history */}
            <WatchHistoryRecorder
                id={show.id}
                media_type="tv"
                title={show.name}
                poster_path={show.poster_path ?? null}
                backdrop_path={show.backdrop_path ?? null}
                season={currentSeason}
                episode={currentEpisode}
                runtimeMinutes={currentEpRuntime}
            />

            {/* HERO — backdrop bg + player */}
            <div style={{ position: "relative", overflow: "hidden" }}>
                {backdrop && (
                    <>
                        <Image
                            src={backdrop}
                            alt={show.name}
                            fill
                            priority
                            sizes="100vw"
                            className="object-cover object-top"
                            unoptimized
                        />
                        <div
                            className="absolute inset-0"
                            style={{ backgroundColor: "rgba(11,15,26,0.72)" }}
                        />
                        <div
                            className="absolute bottom-0 left-0 right-0"
                            style={{
                                height: 120,
                                background: `linear-gradient(to top, ${BG}, transparent)`,
                            }}
                        />
                    </>
                )}

                <div
                    className="max-w-[1400px] mx-auto"
                    style={{
                        position: "relative",
                        zIndex: 1,
                        padding: backdrop ? "64px 28px 48px" : "32px 28px",
                    }}
                >
                    <div
                        style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 10,
                            marginBottom: 16,
                        }}
                    >
                        <span
                            style={{
                                display: "inline-block",
                                width: 3,
                                height: 20,
                                borderRadius: 2,
                                background: `linear-gradient(180deg, #a78bfa 0%, ${ACCENT} 100%)`,
                            }}
                        />
                        <h2
                            style={{
                                fontSize: 15,
                                fontWeight: 700,
                                color: "#fff",
                                letterSpacing: "-0.02em",
                            }}
                        >
                            {show.name} &mdash; S{currentSeason} · E{currentEpisode}
                        </h2>
                    </div>

                    {/* Ad — Before Player */}
                    <AdSlot
                        placement="SERIES_PAGE"
                        position="BEFORE_PLAYER"
                        style={{ marginBottom: 12 }}
                    />
                    <AdSlot
                        placement="VIDEO_PLAYER"
                        position="BEFORE_PLAYER"
                        style={{ marginBottom: 12 }}
                    />

                    <TVPlayer
                        key={`${currentSeason}-${currentEpisode}`}
                        tvId={show.id.toString()}
                        episodes={episodes}
                        initialSeason={currentSeason}
                        initialEpisode={currentEpisode}
                        players={players}
                        nextEpisodeUrl={nextEpisodeUrl}
                    />

                    {/* Ad — After Player */}
                    <AdSlot
                        placement="SERIES_PAGE"
                        position="AFTER_PLAYER"
                        style={{ marginTop: 12 }}
                    />
                    <AdSlot
                        placement="VIDEO_PLAYER"
                        position="AFTER_PLAYER"
                        style={{ marginTop: 12 }}
                    />

                    <div
                        style={{
                            marginTop: 8,
                            display: "flex",
                            justifyContent: "flex-end",
                        }}
                    >
                        <ReportButton
                            mediaId={show.id}
                            mediaType="TV"
                            initialSeason={currentSeason}
                            initialEpisode={currentEpisode}
                        />
                    </div>
                </div>
            </div>

            {/* EPISODES — shown right after player when playing */}
            <div
                className="max-w-[1100px] mx-auto"
                style={{
                    padding: "40px 28px 0",
                    borderTop: "1px solid rgba(255,255,255,0.05)",
                    marginTop: 36,
                }}
            >
                <div
                    style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        marginBottom: 24,
                    }}
                >
                    <span
                        style={{
                            display: "inline-block",
                            width: 3,
                            height: 20,
                            borderRadius: 2,
                            background: `linear-gradient(180deg, #a78bfa 0%, ${ACCENT} 100%)`,
                        }}
                    />
                    <h2
                        style={{
                            fontSize: 16,
                            fontWeight: 700,
                            color: "#fff",
                            letterSpacing: "-0.02em",
                        }}
                    >
                        Episodes
                    </h2>
                </div>
                <EpisodeSection
                    tvId={show.id.toString()}
                    seasons={validSeasons}
                    initialSeason={currentSeason}
                    initialEpisodes={episodes}
                    currentEpisode={currentEpisode}
                />
            </div>
        </>
    );
}

/* ─── Exported wrapper with Suspense boundary ─────────────── */

export function TVClientShell(props: TVClientShellProps) {
    return (
        <Suspense fallback={null}>
            <TVClientShellInner {...props} />
        </Suspense>
    );
}

/* ─── Episode section wrapper (non-playing state) ─────────── */

function TVEpisodeBrowseInner({
    show,
    defaultEpisodes,
    defaultSeason,
}: Pick<TVClientShellProps, "show" | "defaultEpisodes" | "defaultSeason">) {
    const searchParams = useSearchParams();
    const isPlaying = searchParams.get("play") === "1";

    const validSeasons = show.seasons.filter((s) => s.season_number > 0);
    const currentSeason = parseInt(
        searchParams.get("season") ?? String(defaultSeason),
        10
    );
    const currentEpisode = parseInt(
        searchParams.get("episode") ?? "1",
        10
    );

    if (isPlaying) return null;

    return (
        <div
            className="max-w-[1100px] mx-auto"
            style={{
                padding: "40px 28px 0",
                borderTop: "1px solid rgba(255,255,255,0.05)",
            }}
        >
            <div
                style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    marginBottom: 24,
                }}
            >
                <span
                    style={{
                        display: "inline-block",
                        width: 3,
                        height: 20,
                        borderRadius: 2,
                        background: `linear-gradient(180deg, #a78bfa 0%, ${ACCENT} 100%)`,
                    }}
                />
                <h2
                    style={{
                        fontSize: 16,
                        fontWeight: 700,
                        color: "#fff",
                        letterSpacing: "-0.02em",
                    }}
                >
                    Episodes
                </h2>
            </div>
            <EpisodeSection
                tvId={show.id.toString()}
                seasons={validSeasons}
                initialSeason={currentSeason}
                initialEpisodes={defaultEpisodes}
                currentEpisode={currentEpisode}
            />
        </div>
    );
}

export function TVEpisodeBrowse(
    props: Pick<TVClientShellProps, "show" | "defaultEpisodes" | "defaultSeason">
) {
    return (
        <Suspense fallback={null}>
            <TVEpisodeBrowseInner {...props} />
        </Suspense>
    );
}

/* ─── Backdrop (shown only when NOT playing) ──────────────── */

function TVBackdropInner({
    backdropUrl,
    showName,
}: {
    backdropUrl: string | null;
    showName: string;
}) {
    const searchParams = useSearchParams();
    const isPlaying = searchParams.get("play") === "1";

    if (isPlaying) return null;

    if (backdropUrl) {
        return (
            <div
                style={{
                    position: "relative",
                    width: "100%",
                    height: 520,
                    overflow: "hidden",
                }}
            >
                <Image
                    src={backdropUrl}
                    alt={showName}
                    fill
                    priority
                    sizes="100vw"
                    className="object-cover object-top"
                    unoptimized
                />
                <div
                    className="absolute inset-0"
                    style={{
                        background:
                            "linear-gradient(to right, #0b0f1a 18%, rgba(11,15,26,0.72) 55%, rgba(11,15,26,0.15) 100%)",
                    }}
                />
                <div
                    className="absolute inset-0"
                    style={{
                        background:
                            "linear-gradient(to top, #0b0f1a 0%, rgba(11,15,26,0.5) 35%, transparent 62%)",
                    }}
                />
                <div
                    className="absolute inset-0"
                    style={{ backgroundColor: "rgba(11,15,26,0.3)" }}
                />
            </div>
        );
    }

    return <div style={{ height: 160 }} />;
}

export function TVBackdrop(props: {
    backdropUrl: string | null;
    showName: string;
}) {
    return (
        <Suspense
            fallback={
                props.backdropUrl ? (
                    <div style={{ position: "relative", width: "100%", height: 520, overflow: "hidden" }}>
                        <Image
                            src={props.backdropUrl}
                            alt={props.showName}
                            fill
                            priority
                            sizes="100vw"
                            className="object-cover object-top"
                            unoptimized
                        />
                        <div className="absolute inset-0" style={{ background: "linear-gradient(to right, #0b0f1a 18%, rgba(11,15,26,0.72) 55%, rgba(11,15,26,0.15) 100%)" }} />
                        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, #0b0f1a 0%, rgba(11,15,26,0.5) 35%, transparent 62%)" }} />
                        <div className="absolute inset-0" style={{ backgroundColor: "rgba(11,15,26,0.3)" }} />
                    </div>
                ) : (
                    <div style={{ height: 160 }} />
                )
            }
        >
            <TVBackdropInner {...props} />
        </Suspense>
    );
}

/* ── Hero metadata wrapper (adjusts layout based on play state) ── */

function TVHeroMetadataInner({
    hasBackdrop,
    children,
}: {
    hasBackdrop: boolean;
    children: ReactNode;
}) {
    const searchParams = useSearchParams();
    const isPlaying = searchParams.get("play") === "1";

    return (
        <div
            className="max-w-[1400px] mx-auto relative z-10"
            style={{
                marginTop: isPlaying ? 36 : hasBackdrop ? -220 : 0,
                padding: isPlaying ? "40px 28px 0" : "0 28px",
                borderTop: isPlaying ? "1px solid rgba(255,255,255,0.05)" : "none",
            }}
        >
            {children}
        </div>
    );
}

export function TVHeroMetadata({
    hasBackdrop,
    children,
}: {
    hasBackdrop: boolean;
    children: ReactNode;
}) {
    return (
        <Suspense
            fallback={
                <div
                    className="max-w-[1400px] mx-auto relative z-10"
                    style={{
                        marginTop: hasBackdrop ? -220 : 0,
                        padding: "0 28px",
                    }}
                >
                    {children}
                </div>
            }
        >
            <TVHeroMetadataInner hasBackdrop={hasBackdrop}>
                {children}
            </TVHeroMetadataInner>
        </Suspense>
    );
}

/* ── Metadata padding wrapper (paddingTop changes based on play state) ── */

function TVMetadataColumnInner({
    hasBackdrop,
    children,
}: {
    hasBackdrop: boolean;
    children: ReactNode;
}) {
    const searchParams = useSearchParams();
    const isPlaying = searchParams.get("play") === "1";

    return (
        <div
            style={{
                flex: 1,
                paddingTop: isPlaying ? 16 : hasBackdrop ? 118 : 16,
                paddingBottom: 32,
                minWidth: 0,
            }}
        >
            {children}
        </div>
    );
}

export function TVMetadataColumn({
    hasBackdrop,
    children,
}: {
    hasBackdrop: boolean;
    children: ReactNode;
}) {
    return (
        <Suspense
            fallback={
                <div
                    style={{
                        flex: 1,
                        paddingTop: hasBackdrop ? 118 : 16,
                        paddingBottom: 32,
                        minWidth: 0,
                    }}
                >
                    {children}
                </div>
            }
        >
            <TVMetadataColumnInner hasBackdrop={hasBackdrop}>
                {children}
            </TVMetadataColumnInner>
        </Suspense>
    );
}
