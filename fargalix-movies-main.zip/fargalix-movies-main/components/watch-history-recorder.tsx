"use client";

import { useEffect, useRef } from "react";
import { addToWatchHistory } from "@/lib/watch-history";
import { useAuth } from "@/components/auth/auth-provider";

interface Props {
  id: number;
  media_type: "movie" | "tv";
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  season?: number;
  episode?: number;
  episodeName?: string;
  /**
   * Known duration in minutes. When provided, enables timer-based progress
   * tracking: the component sends updates every 30 s and a final update on
   * unmount so the DB reflects how much of the content the user actually saw.
   */
  runtimeMinutes?: number;
}

const UPDATE_INTERVAL_MS = 60_000; // push progress to DB every 60 s (was 30 s — halves DB writes)

/**
 * Invisible component — records watch history in localStorage (always) and
 * syncs progress to the database when the user is signed in.
 *
 * Because the player is a cross-origin iframe we cannot read currentTime
 * directly. Instead we track wall-clock time elapsed since the component
 * mounted and use it to estimate progress relative to the known runtime.
 */
export function WatchHistoryRecorder({
  id,
  media_type,
  title,
  poster_path,
  backdrop_path,
  season,
  episode,
  episodeName,
  runtimeMinutes,
}: Props) {
  const { user } = useAuth();
  const startTimeRef = useRef<number>(Date.now());
  const lastProgressRef = useRef<number>(0);

  // Reset timer whenever the specific piece of content changes.
  useEffect(() => {
    startTimeRef.current = Date.now();
    lastProgressRef.current = 0;
  }, [id, season, episode]);

  // ── One-shot initial record ────────────────────────────────────────────────
  // Saves to localStorage immediately and creates/updates the DB row at the
  // current (possibly already non-zero) progress value.
  useEffect(() => {
    addToWatchHistory({ id, media_type, title, poster_path, backdrop_path, season, episode });

    if (user) {
      fetch("/api/user/continue-watching", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tmdbId: id,
          mediaType: media_type === "movie" ? "MOVIE" : "TV",
          title,
          posterPath: poster_path,
          backdropPath: backdrop_path,
          season: season ?? null,
          episode: episode ?? null,
          episodeName: episodeName ?? null,
          progress: lastProgressRef.current,
        }),
      }).catch(() => { });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, media_type, season, episode]);

  // ── Interval progress tracker ──────────────────────────────────────────────
  // Only active when runtimeMinutes is known and the user is signed in.
  useEffect(() => {
    if (!runtimeMinutes || !user) return;

    const runtimeMs = runtimeMinutes * 60_000;

    /** Compute current progress and push to all relevant API endpoints. */
    const sendProgress = (isFinal: boolean) => {
      const elapsed = Date.now() - startTimeRef.current;
      // Cap at 95% via timer — the final 5% requires the user to explicitly
      // mark the item as watched (or it reaches 90 %+ and is auto-flagged).
      const progress = Math.min(isFinal ? 95 : 95, Math.max(0, (elapsed / runtimeMs) * 100));

      // Skip if progress hasn't moved by at least 1 % since last send.
      if (!isFinal && Math.abs(progress - lastProgressRef.current) < 1) return;
      lastProgressRef.current = progress;

      // Update the "Continue Watching" row (shared for movie/TV-show level).
      fetch("/api/user/continue-watching", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tmdbId: id,
          mediaType: media_type === "movie" ? "MOVIE" : "TV",
          title,
          posterPath: poster_path,
          backdropPath: backdrop_path,
          season: season ?? null,
          episode: episode ?? null,
          episodeName: episodeName ?? null,
          progress,
        }),
      }).catch(() => { });

      // Also update per-episode granular progress for TV.
      if (media_type === "tv" && season != null && episode != null) {
        fetch("/api/user/episode-progress", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ tvId: id, season, episode, progress }),
        }).catch(() => { });

        // Notify EpisodeSection (and any other listeners) in real-time so the
        // progress bar and watched badge update immediately — no polling needed.
        window.dispatchEvent(
          new CustomEvent("svep-progress", {
            detail: { tvId: id, season, episode, progress },
          }),
        );
      }
    };

    const interval = setInterval(() => sendProgress(false), UPDATE_INTERVAL_MS);

    return () => {
      clearInterval(interval);
      sendProgress(true); // flush remaining progress on unmount
    };
  }, [id, media_type, season, episode, runtimeMinutes, user]); // eslint-disable-line react-hooks/exhaustive-deps

  return null;
}
