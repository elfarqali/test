"use client";

import type { TMDBTVEpisode } from "@/lib/tmdb";
import { PlayerSwitcher, type PlayerSource } from "@/components/player-switcher";
import { useRouter } from "next/navigation";

interface PlayerConfig {
  name: string;
  tvUrl: string; // template with {id}, {season}, {episode} placeholders
}

interface TVPlayerProps {
  tvId: string;
  episodes: TMDBTVEpisode[]; // episodes of the current season
  initialSeason: number;
  initialEpisode: number;
  players: PlayerConfig[];
  nextEpisodeUrl?: string;
}

function buildTvUrl(template: string, id: string, season: number, episode: number): string {
  return template
    .replace(/\{id\}/g, id)
    .replace(/\{season\}/g, String(season))
    .replace(/\{episode\}/g, String(episode));
}

export function TVPlayer({
  tvId,
  episodes: _episodes,
  initialSeason,
  initialEpisode,
  players,
  nextEpisodeUrl,
}: TVPlayerProps) {
  // Do NOT use frozen useState here — use props directly so that when Next.js
  // soft-navigates to the same route with new search params the player
  // correctly reflects the new episode without a full page reload.
  const season = initialSeason;
  const episode = initialEpisode;
  const router = useRouter();

  const handleVideoEnded = () => {
    if (nextEpisodeUrl) {
      router.push(nextEpisodeUrl);
    }
  };

  const sources: PlayerSource[] = players.map((p) => ({
    name: p.name,
    src: buildTvUrl(p.tvUrl, tvId, season, episode),
  }));

  return (
    <PlayerSwitcher
      sources={sources}
      iframeKey={`${season}-${episode}`}
      title={`Watch S${season}E${episode}`}
      onVideoEnded={nextEpisodeUrl ? handleVideoEnded : undefined}
    />
  );
}
