import Image from "next/image";
import Link from "next/link";
import { cn } from "@/lib/utils";
import {
  IMAGE_BASE_URL,
  getMediaTitle,
  getMediaYear,
  getMediaType,
  type TMDBMediaItem,
} from "@/lib/tmdb";

interface MediaCardProps {
  item: TMDBMediaItem;
  showType?: boolean;
  /** legacy prop — ignored, use showType */
  showMediaType?: boolean;
  className?: string;
  width?: number | "100%";
  /** If provided, wraps the card in a Link. Auto-detected from item if omitted. */
  href?: string;
}

export function slugify(text: string): string {
  if (!text) return "";
  return text
    .toString()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '');
}

function buildHref(item: TMDBMediaItem): string {
  if (item.media_type === "tv") return `/tv/${item.id}`;
  if (item.media_type === "movie") return `/movie/${item.id}`;
  if (item.name && !item.title) return `/tv/${item.id}`;
  return `/movie/${item.id}`;
}

function StarRating({ score }: { score: number }) {
  const color =
    score >= 7 ? "#22c55e" : score >= 5 ? "#f59e0b" : "#ef4444";
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 3,
        fontSize: 10,
        fontWeight: 700,
        color,
        letterSpacing: "0.02em",
      }}
    >
      <svg
        width="9"
        height="9"
        viewBox="0 0 24 24"
        fill={color}
        style={{ flexShrink: 0 }}
      >
        <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" />
      </svg>
      {score.toFixed(1)}
    </span>
  );
}

export function MediaCard({
  item,
  showType = false,
  showMediaType,
  className,
  width = 180,
  href,
}: MediaCardProps) {
  const showBadge = showType || showMediaType;
  const title = getMediaTitle(item);
  const year = getMediaYear(item);
  const rating = item.vote_average ?? 0;
  const mediaType = getMediaType(item);
  const posterSrc = item.poster_path
    ? `${IMAGE_BASE_URL}${item.poster_path}`
    : null;
  const h = typeof width === "number" ? Math.round(width * 1.5) : undefined;
  const linkHref = href ?? buildHref(item);
  const isSeries = mediaType === "Series";

  return (
    <Link
      href={linkHref}
      prefetch={false}
      className={cn("group relative flex-shrink-0 cursor-pointer block", className)}
      style={{ width }}
    >
      {/* Poster */}
      <div
        className="relative overflow-hidden"
        style={{
          width,
          height: h,
          aspectRatio: h === undefined ? "2/3" : undefined,
          backgroundColor: "#111827",
          borderRadius: 10,
          boxShadow: "0 4px 20px rgba(0,0,0,0.55)",
        }}
      >
        {posterSrc ? (
          <Image
            src={posterSrc}
            alt={title}
            fill
            sizes={typeof width === "number" ? `${width}px` : "200px"}
            loading="lazy"
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            style={{ borderRadius: 10 }}
            unoptimized
          />
        ) : (
          <div
            className="flex h-full w-full items-center justify-center"
            style={{ borderRadius: 10 }}
          >
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.2)" }}>
              No Image
            </span>
          </div>
        )}

        {/* Bottom gradient for metadata legibility */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: 10,
            background:
              "linear-gradient(to top, rgba(0,0,0,0.0) 55%, rgba(0,0,0,0.35) 100%)",
            pointerEvents: "none",
          }}
        />

        {/* Hover overlay */}
        <div
          className="absolute inset-0 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
          style={{
            borderRadius: 10,
            background: "rgba(0,0,0,0.42)",
          }}
        />

        {/* Centered play button */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div
            style={{
              width: 48,
              height: 48,
              borderRadius: "50%",
              backgroundColor: "rgba(255,255,255,0.15)",
              border: "2px solid rgba(255,255,255,0.85)",
              backdropFilter: "blur(6px)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 0 24px rgba(255,255,255,0.2)",
            }}
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="#fff"
              style={{ marginLeft: 3 }}
            >
              <polygon points="5,3 19,12 5,21" />
            </svg>
          </div>
        </div>

        {/* Top-right: type badge */}
        {showBadge && (
          <div
            style={{
              position: "absolute",
              top: 8,
              right: 8,
              pointerEvents: "none",
            }}
          >
            <span
              style={{
                display: "inline-block",
                fontSize: 9,
                fontWeight: 800,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                color: "#fff",
                backgroundColor: isSeries
                  ? "rgba(124,58,237,0.85)"
                  : "rgba(109,40,217,0.85)",
                padding: "3px 7px",
                borderRadius: 4,
                backdropFilter: "blur(4px)",
                border: isSeries
                  ? "1px solid rgba(124,58,237,0.4)"
                  : "1px solid rgba(109,40,217,0.4)",
              }}
            >
              {mediaType}
            </span>
          </div>
        )}
      </div>

      {/* Text below poster */}
      <div style={{ marginTop: 10, paddingLeft: 2, paddingRight: 2 }}>
        <p
          className="line-clamp-1"
          title={title}
          style={{
            fontSize: 13,
            fontWeight: 600,
            color: "#f0f0f0",
            margin: 0,
            lineHeight: 1.35,
            letterSpacing: "-0.01em",
          }}
        >
          {title}
        </p>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            marginTop: 4,
          }}
        >
          {year && (
            <span
              style={{
                fontSize: 11,
                color: "rgba(255,255,255,0.42)",
                fontWeight: 400,
              }}
            >
              {year}
            </span>
          )}
          {year && rating > 0 && (
            <span
              style={{
                width: 2,
                height: 2,
                borderRadius: "50%",
                backgroundColor: "rgba(255,255,255,0.25)",
                display: "inline-block",
                flexShrink: 0,
              }}
            />
          )}
          {rating > 0 && <StarRating score={rating} />}
        </div>
      </div>
    </Link>
  );
}
