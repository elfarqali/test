"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Play } from "lucide-react";
import {
  getWatchHistory,
  removeFromWatchHistory,
  type WatchItem,
} from "@/lib/watch-history";
import { useAuth } from "@/components/auth/auth-provider";
import { IMAGE_BASE_URL, IMAGE_BACKDROP_URL } from "@/lib/tmdb";

const CARD_W = 240;
const CARD_H = 135; // 16:9

type DisplayItem = WatchItem & {
  progress: number; // 0–100
  season?: number;
  episode?: number;
};

function buildHref(item: DisplayItem): string {
  if (item.media_type === "movie") return `/movie/${item.id}?play=1`;
  if (item.season != null && item.episode != null) {
    return `/tv/${item.id}?season=${item.season}&episode=${item.episode}&play=1`;
  }
  return `/tv/${item.id}?play=1`;
}

export function KeepWatchingSection() {
  const { user } = useAuth();
  const [items, setItems] = useState<DisplayItem[]>([]);
  const [hoveredKey, setHoveredKey] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      // Authenticated: pull real data + real progress from the database.
      fetch("/api/user/continue-watching")
        .then((r) => r.json())
        .then((data) => {
          const dbItems: DisplayItem[] = (data.items ?? []).map(
            (item: {
              tmdbId: number;
              mediaType: string;
              title: string;
              posterPath: string | null;
              backdropPath: string | null;
              updatedAt: string;
              progress: number;
              season: number | null;
              episode: number | null;
            }) => ({
              id: item.tmdbId,
              media_type: item.mediaType === "MOVIE" ? "movie" : "tv",
              title: item.title,
              poster_path: item.posterPath,
              backdrop_path: item.backdropPath,
              timestamp: new Date(item.updatedAt).getTime(),
              progress: item.progress ?? 0,
              season: item.season ?? undefined,
              episode: item.episode ?? undefined,
            }),
          );
          setItems(dbItems.slice(0, 10));
        })
        .catch(() => {
          const local = getWatchHistory().slice(0, 10);
          setItems(local.map((i) => ({ ...i, progress: 0 })));
        });
    } else {
      // Unauthenticated: fall back to localStorage (no progress data available).
      const local = getWatchHistory().slice(0, 10);
      setItems(local.map((i) => ({ ...i, progress: 0 })));
    }
  }, [user]);

  function handleRemove(e: React.MouseEvent, item: DisplayItem) {
    e.preventDefault();
    e.stopPropagation();
    const key = `${item.media_type}-${item.id}`;
    removeFromWatchHistory(item.id, item.media_type);
    setItems((prev) => prev.filter((i) => `${i.media_type}-${i.id}` !== key));
    if (user) {
      fetch(
        `/api/user/continue-watching?tmdbId=${item.id}&mediaType=${item.media_type === "movie" ? "MOVIE" : "TV"}`,
        { method: "DELETE" },
      ).catch(() => { });
    }
  }

  if (!items.length) return null;

  return (
    <section className="px-4 mt-3 mb-5">
      <p
        className="uppercase tracking-widest mb-3"
        style={{ fontSize: 10, color: "rgba(255,255,255,0.35)" }}
      >
        Continue Watching
      </p>

      <div
        style={{
          display: "flex",
          gap: 12,
          overflowX: "auto",
          scrollbarWidth: "none",
          paddingBottom: 6,
        }}
      >
        {items.map((item) => {
          const key = `${item.media_type}-${item.id}`;
          const href = buildHref(item);
          const isHovered = hoveredKey === key;
          const isWatched = item.progress >= 90;
          const hasProgress = item.progress > 3;

          const imgSrc = item.backdrop_path
            ? `${IMAGE_BACKDROP_URL}${item.backdrop_path}`
            : item.poster_path
              ? `${IMAGE_BASE_URL}${item.poster_path}`
              : null;

          return (
            <div
              key={key}
              style={{ flexShrink: 0, width: CARD_W, position: "relative" }}
              onMouseEnter={() => setHoveredKey(key)}
              onMouseLeave={() => setHoveredKey(null)}
            >
              {/* ── Remove (X) button ── */}
              <button
                aria-label={`Remove ${item.title} from Continue Watching`}
                onClick={(e) => handleRemove(e, item)}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.backgroundColor = "rgba(220,38,38,0.92)";
                  (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.12)";
                  (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(220,38,38,0.5)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.backgroundColor = "rgba(10,10,18,0.82)";
                  (e.currentTarget as HTMLButtonElement).style.transform = "scale(1)";
                  (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.2)";
                }}
                style={{
                  position: "absolute",
                  top: 6,
                  right: 6,
                  zIndex: 20,
                  width: 22,
                  height: 22,
                  borderRadius: "50%",
                  backgroundColor: "rgba(10,10,18,0.82)",
                  border: "1px solid rgba(255,255,255,0.2)",
                  color: "#fff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  padding: 0,
                  opacity: isHovered ? 1 : 0,
                  transform: "scale(1)",
                  transition: "opacity 0.18s ease, background-color 0.15s ease, transform 0.15s ease, border-color 0.15s ease",
                  lineHeight: 1,
                }}
              >
                <svg width="9" height="9" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                  <line x1="1" y1="1" x2="11" y2="11" />
                  <line x1="11" y1="1" x2="1" y2="11" />
                </svg>
              </button>

              {/* ── Card link ── */}
              <Link href={href} style={{ display: "block", textDecoration: "none" }}>
                {/* Thumbnail */}
                <div
                  style={{
                    width: CARD_W,
                    height: CARD_H,
                    position: "relative",
                    overflow: "hidden",
                    borderRadius: 8,
                    backgroundColor: "#111827",
                    border: isWatched ? "1px solid rgba(239,68,68,0.25)" : "1px solid transparent",
                    boxShadow: isHovered ? "0 8px 28px rgba(0,0,0,0.7)" : "0 3px 12px rgba(0,0,0,0.45)",
                    transition: "box-shadow 0.25s ease, border-color 0.2s ease",
                  }}
                >
                  {imgSrc && (
                    <Image
                      src={imgSrc}
                      alt={item.title}
                      fill
                      sizes={`${CARD_W}px`}
                      style={{
                        objectFit: "cover",
                        transform: isHovered ? "scale(1.06)" : "scale(1)",
                        transition: "transform 0.35s ease",
                      }}
                      unoptimized
                    />
                  )}

                  {/* Bottom gradient */}
                  <div
                    style={{
                      position: "absolute",
                      inset: 0,
                      background: "linear-gradient(to top, rgba(0,0,0,0.75) 0%, transparent 55%)",
                      pointerEvents: "none",
                    }}
                  />

                  {/* Play button */}
                  <div
                    style={{
                      position: "absolute",
                      inset: 0,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      opacity: isHovered ? 1 : 0,
                      transition: "opacity 0.18s ease",
                    }}
                  >
                    <div
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: "50%",
                        backgroundColor: "rgba(124,58,237,0.92)",
                        boxShadow: "0 0 18px rgba(124,58,237,0.6)",
                        border: "1.5px solid rgba(167,139,250,0.4)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Play size={14} fill="#fff" color="#fff" style={{ marginLeft: 2 }} />
                    </div>
                  </div>

                  {/* Watched checkmark or media-type badge — top left */}
                  {isWatched ? (
                    <div
                      style={{
                        position: "absolute",
                        top: 6,
                        left: 6,
                        width: 20,
                        height: 20,
                        borderRadius: "50%",
                        background: "#ef4444",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="1,6 4,9 11,3" />
                      </svg>
                    </div>
                  ) : (
                    <span
                      style={{
                        position: "absolute",
                        top: 6,
                        left: 6,
                        fontSize: 8,
                        fontWeight: 700,
                        letterSpacing: "0.07em",
                        textTransform: "uppercase",
                        color: "#fff",
                        backgroundColor: item.media_type === "tv" ? "rgba(124,58,237,0.88)" : "rgba(124,58,237,0.7)",
                        padding: "2px 6px",
                        borderRadius: 4,
                        backdropFilter: "blur(4px)",
                      }}
                    >
                      {item.media_type === "tv" ? "Series" : "Movie"}
                    </span>
                  )}

                  {/* Progress bar — only shown when there is real progress */}
                  {hasProgress && (
                    <div
                      style={{
                        position: "absolute",
                        bottom: 0,
                        left: 0,
                        right: 0,
                        height: 3,
                        backgroundColor: "rgba(0,0,0,0.3)",
                      }}
                    >
                      <div
                        style={{
                          height: "100%",
                          width: `${Math.min(item.progress, 100)}%`,
                          backgroundColor: "#ef4444",
                          borderRadius: "0 2px 2px 0",
                          transition: "width 0.5s ease",
                        }}
                      />
                    </div>
                  )}
                </div>

                {/* Title */}
                <p
                  title={item.title}
                  style={{
                    marginTop: 7,
                    fontSize: 12,
                    fontWeight: 500,
                    color: isHovered ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.65)",
                    overflow: "hidden",
                    whiteSpace: "nowrap",
                    textOverflow: "ellipsis",
                    transition: "color 0.18s ease",
                  }}
                >
                  {item.title}
                </p>
              </Link>
            </div>
          );
        })}
      </div>
    </section>
  );
}
