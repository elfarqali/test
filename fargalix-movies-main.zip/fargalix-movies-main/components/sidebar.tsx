"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Flame, TrendingUp, Film, Tv } from "lucide-react";

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/popular", label: "Popular", icon: Flame },
  { href: "/trending", label: "Trending", icon: TrendingUp },
  { href: "/movies", label: "Movies", icon: Film },
  { href: "/series", label: "Series", icon: Tv },
] as const;

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside
      className="hidden md:flex fixed left-0 z-40 flex-col"
      style={{
        top: 58,
        width: 62,
        bottom: 0,
        backgroundColor: "#0d1120",
        borderRight: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Navigation items */}
      <nav className="flex flex-col items-center py-3 gap-0.5 flex-1">
        {navItems.map(({ href, label, icon: Icon }) => {
          const isActive = href === "/" ? pathname === "/" : pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className="flex flex-col items-center gap-1 py-2.5 w-full"
              style={{
                color: isActive ? "#a78bfa" : "rgba(255,255,255,0.40)",
                backgroundColor: isActive ? "rgba(124,58,237,0.12)" : "transparent",
                borderLeft: isActive ? "2px solid #7c3aed" : "2px solid transparent",
                transition: "color 0.15s, background-color 0.15s",
                textDecoration: "none",
              }}
            >
              <Icon size={17} strokeWidth={isActive ? 2.2 : 1.8} />
              <span style={{ fontSize: 9, fontWeight: 600, letterSpacing: "0.03em" }}>{label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Social links at bottom */}
      <div className="flex flex-col items-center gap-2 pb-5">
        <a
          href="https://t.me/"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center rounded"
          style={{ width: 32, height: 32, backgroundColor: "#0088cc" }}
          title="Telegram"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="#fff">
            <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L7.14 13.912l-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.836.947z" />
          </svg>
        </a>
        <a
          href="https://discord.com/"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center rounded"
          style={{ width: 32, height: 32, backgroundColor: "#5865F2" }}
          title="Discord"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="#fff">
            <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057c.003.022.015.043.032.054a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
          </svg>
        </a>
      </div>
    </aside>
  );
}
