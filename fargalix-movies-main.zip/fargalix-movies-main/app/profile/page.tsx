import { redirect } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { getSession } from "@/lib/session";
import { db } from "@/lib/db";
import { IMAGE_BASE_URL, IMAGE_BACKDROP_URL } from "@/lib/tmdb";
import { Calendar, Star, Play, History } from "lucide-react";
import { getLevelData, estimateWatchMinutes } from "@/lib/level";
import { ProfileLevelCard } from "@/components/profile/level-card";

const BG = "#0b0f1a";
const ACCENT = "#7c3aed";
const ACCENT_SOFT = "rgba(124,58,237,0.14)";
const ACCENT_BORDER = "rgba(124,58,237,0.26)";

export default async function ProfilePage() {
  const session = await getSession();
  if (!session) redirect("/signin?redirect=/profile");

  const [user, favorites, continueWatching] = await Promise.all([
    db.user.findUnique({
      where: { id: session.userId },
      select: { id: true, email: true, username: true, role: true, createdAt: true, avatarUrl: true, bonusMinutes: true },
    }),
    db.favorite.findMany({
      where: { userId: session.userId },
      orderBy: { createdAt: "desc" },
    }),
    db.continueWatching.findMany({
      where: { userId: session.userId },
      orderBy: { updatedAt: "desc" },
      take: 12,
    }),
  ]);

  if (!user) redirect("/signin");

  // ── Level system ──────────────────────────────────────────────────────────
  const totalWatchMinutes = estimateWatchMinutes(continueWatching) + (user.bonusMinutes ?? 0);
  const levelData = getLevelData(totalWatchMinutes);

  const memberSince = user.createdAt.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const CARD_W = 140;
  const CW = 220;
  const initials = user.username.slice(0, 2).toUpperCase();

  return (
    <div style={{ backgroundColor: BG, minHeight: "100vh", color: "#fff" }}>
      <div className="max-w-[1200px] mx-auto" style={{ padding: "40px 24px 80px" }}>

        {/* ── Profile card ──────────────────────────────────────────────── */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 28,
            padding: "32px",
            borderRadius: 20,
            background: "linear-gradient(135deg, rgba(124,58,237,0.1) 0%, rgba(255,255,255,0.03) 100%)",
            border: "1px solid rgba(124,58,237,0.22)",
            boxShadow: "0 12px 40px rgba(0,0,0,0.5)",
            marginBottom: 52,
            flexWrap: "wrap",
          }}
        >
          {/* Avatar */}
          <div
            style={{
              width: 80,
              height: 80,
              borderRadius: "50%",
              background: user.avatarUrl
                ? "transparent"
                : "linear-gradient(135deg, #7c3aed 0%, #a78bfa 100%)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 30,
              fontWeight: 900,
              color: "#fff",
              flexShrink: 0,
              boxShadow: "0 0 0 4px rgba(124,58,237,0.25), 0 4px 16px rgba(124,58,237,0.3)",
              overflow: "hidden",
              position: "relative",
            }}
          >
            {user.avatarUrl ? (
              <Image
                src={user.avatarUrl}
                alt={user.username}
                fill
                sizes="80px"
                style={{ objectFit: "cover" }}
                unoptimized
              />
            ) : (
              initials
            )}
          </div>

          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", marginBottom: 6 }}>
              <h1 style={{ fontSize: 22, fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}>
                @{user.username}
              </h1>
              {user.role === "ADMIN" && (
                <span
                  style={{
                    fontSize: 9, fontWeight: 800, letterSpacing: "0.1em",
                    textTransform: "uppercase", color: "#a78bfa",
                    background: ACCENT_SOFT, border: `1px solid ${ACCENT_BORDER}`,
                    padding: "2px 8px", borderRadius: 4,
                  }}
                >
                  Admin
                </span>
              )}
            </div>
            <p style={{ fontSize: 13, color: "rgba(255,255,255,0.38)", marginBottom: 8 }}>
              {user.email}
            </p>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <Calendar size={12} style={{ color: "rgba(255,255,255,0.3)" }} />
              <p style={{ fontSize: 12, color: "rgba(255,255,255,0.3)" }}>
                Member since {memberSince}
              </p>
            </div>
          </div>

          {/* Stats + Settings link */}
          <div style={{ display: "flex", flexDirection: "column", gap: 12, alignItems: "flex-end", flexShrink: 0 }}>
            <div style={{ display: "flex", gap: 20 }}>
              {[
                { label: "Favorites", count: favorites.length, icon: <Star size={14} /> },
                { label: "Watching", count: continueWatching.length, icon: <Play size={14} /> },
              ].map(({ label, count, icon }) => (
                <div key={label} style={{ textAlign: "center" }}>
                  <p style={{ fontSize: 26, fontWeight: 800, color: "#c4b5fd", lineHeight: 1 }}>
                    {count}
                  </p>
                  <div style={{ display: "flex", alignItems: "center", gap: 4, justifyContent: "center", marginTop: 4 }}>
                    <span style={{ color: "rgba(255,255,255,0.3)" }}>{icon}</span>
                    <p style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>{label}</p>
                  </div>
                </div>
              ))}
            </div>
            <Link
              href="/settings"
              style={{
                fontSize: 12, fontWeight: 600, color: "#a78bfa",
                background: ACCENT_SOFT, border: `1px solid ${ACCENT_BORDER}`,
                padding: "5px 12px", borderRadius: 7, textDecoration: "none",
                transition: "all 0.15s ease",
              }}
              className="hover:bg-purple-500/20"
            >
              Edit Profile
            </Link>
          </div>
        </div>

        {/* ── Level / XP card ──────────────────────────────────────────── */}
        <ProfileLevelCard
          levelData={levelData}
          username={user.username}
          avatarUrl={user.avatarUrl ?? null}
        />

        {/* ── Favorites ─────────────────────────────────────────────────── */}
        <Section title="My Favorites" count={favorites.length}>
          {favorites.length === 0 ? (
            <EmptyState text="No favorites yet. Browse movies and series to add some!" />
          ) : (
            <div style={{ display: "flex", gap: 12, overflowX: "auto", scrollbarWidth: "none", paddingBottom: 8 }}>
              {favorites.map((fav: any) => {
                const href = `/${fav.mediaType === "MOVIE" ? "movie" : "tv"}/${fav.tmdbId}`;
                const img = fav.posterPath ? `${IMAGE_BASE_URL}${fav.posterPath}` : null;
                return (
                  <Link key={fav.id} href={href} style={{ textDecoration: "none", flexShrink: 0 }}>
                    <div
                      style={{
                        width: CARD_W, borderRadius: 10, overflow: "hidden",
                        background: "#13182b", border: "1px solid rgba(255,255,255,0.06)",
                        transition: "transform 0.2s ease, box-shadow 0.2s ease",
                      }}
                      className="hover:scale-[1.03] hover:shadow-xl"
                    >
                      <div style={{ width: CARD_W, height: CARD_W * 1.5, position: "relative", background: "#1a2035" }}>
                        {img && <Image src={img} alt={fav.title} fill sizes={`${CARD_W}px`} className="object-cover" unoptimized />}
                        <span style={{
                          position: "absolute", top: 6, left: 6,
                          fontSize: 8, fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase",
                          color: "#fff", background: "rgba(124,58,237,0.88)", padding: "2px 6px", borderRadius: 4,
                        }}>
                          {fav.mediaType === "MOVIE" ? "Movie" : "Series"}
                        </span>
                      </div>
                      <div style={{ padding: "8px 10px 10px" }}>
                        <p style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.8)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {fav.title}
                        </p>
                        {fav.year && (
                          <p style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>{fav.year}</p>
                        )}
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </Section>

        {/* ── Watch History ──────────────────────────────────────────────── */}
        <Section
          title="Watch History"
          count={continueWatching.length}
          action={continueWatching.length > 0 ? (
            <Link
              href="/history"
              style={{
                fontSize: 12, fontWeight: 600, color: "#a78bfa",
                textDecoration: "none", display: "flex", alignItems: "center", gap: 5,
              }}
            >
              <History size={13} />
              View All
            </Link>
          ) : undefined}
        >
          {continueWatching.length === 0 ? (
            <EmptyState text="Nothing here yet. Start watching a movie or series!" />
          ) : (
            <div style={{ display: "flex", gap: 12, overflowX: "auto", scrollbarWidth: "none", paddingBottom: 8 }}>
              {continueWatching.map((item: any) => {
                const href =
                  item.mediaType === "TV" && item.season && item.episode
                    ? `/tv/${item.tmdbId}?play=1&season=${item.season}&episode=${item.episode}`
                    : item.mediaType === "MOVIE"
                      ? `/movie/${item.tmdbId}`
                      : `/tv/${item.tmdbId}`;
                const img = item.backdropPath
                  ? `${IMAGE_BACKDROP_URL}${item.backdropPath}`
                  : item.posterPath
                    ? `${IMAGE_BASE_URL}${item.posterPath}`
                    : null;
                return (
                  <Link key={item.id} href={href} style={{ textDecoration: "none", flexShrink: 0 }}>
                    <div
                      style={{
                        width: CW, borderRadius: 10, overflow: "hidden",
                        background: "#13182b", border: "1px solid rgba(255,255,255,0.06)",
                      }}
                      className="hover:scale-[1.02] transition-transform"
                    >
                      <div style={{ width: CW, height: CW * 0.5625, position: "relative", background: "#1a2035" }}>
                        {img && <Image src={img} alt={item.title} fill sizes={`${CW}px`} className="object-cover" unoptimized />}
                        <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 3, background: "rgba(255,255,255,0.1)" }}>
                          <div style={{ height: "100%", width: `${Math.min(item.progress, 100)}%`, background: ACCENT, borderRadius: "0 2px 2px 0" }} />
                        </div>
                        {item.mediaType === "TV" && item.season && item.episode && (
                          <span style={{
                            position: "absolute", bottom: 6, right: 8,
                            fontSize: 9, fontWeight: 700, color: "#fff",
                            background: "rgba(0,0,0,0.7)", padding: "2px 6px", borderRadius: 4,
                          }}>
                            S{item.season}·E{item.episode}
                          </span>
                        )}
                      </div>
                      <div style={{ padding: "8px 10px 10px" }}>
                        <p style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.8)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {item.title}
                        </p>
                        {item.episodeName && (
                          <p style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                            {item.episodeName}
                          </p>
                        )}
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </Section>

      </div>
    </div>
  );
}

function Section({ title, count, children, action }: {
  title: string;
  count: number;
  children: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <section style={{ marginBottom: 52 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
        <span style={{
          display: "inline-block", width: 3, height: 20, borderRadius: 2,
          background: "linear-gradient(180deg, #a78bfa 0%, #7c3aed 100%)",
        }} />
        <h2 style={{ fontSize: 16, fontWeight: 700, color: "#fff", letterSpacing: "-0.02em" }}>
          {title}
        </h2>
        <span style={{
          fontSize: 11, fontWeight: 700, color: "#a78bfa",
          background: "rgba(124,58,237,0.14)", border: "1px solid rgba(124,58,237,0.26)",
          padding: "2px 8px", borderRadius: 20,
        }}>
          {count}
        </span>
        {action && <div style={{ marginLeft: "auto" }}>{action}</div>}
      </div>
      {children}
    </section>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div style={{
      padding: "32px 24px", borderRadius: 12,
      border: "1px dashed rgba(255,255,255,0.1)",
      textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: 13,
    }}>
      {text}
    </div>
  );
}
