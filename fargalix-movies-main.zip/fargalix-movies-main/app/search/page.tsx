import { Suspense } from "react";
import { searchMulti } from "@/lib/tmdb";
import { MediaCard } from "@/components/media-card";
import { PaginationControls } from "@/components/pagination-controls";
import { Search } from "lucide-react";

interface SearchPageProps {
  searchParams: Promise<{ q?: string; page?: string }>;
}

// Cache each search result page for 1 hour — same query serves from CDN
export const revalidate = 3600;

export async function generateMetadata({
  searchParams,
}: SearchPageProps) {
  const params = await searchParams;
  const q = params.q?.trim() ?? "";
  return {
    title: q ? `Search: ${q} - StreamVault` : "Search - StreamVault",
    description: q ? `Search results for "${q}"` : "Search for movies and series.",
  };
}

export default async function SearchPage({ searchParams }: SearchPageProps) {
  const params = await searchParams;
  const query = params.q?.trim() ?? "";
  const page = Math.max(1, parseInt(params.page ?? "1", 10) || 1);

  const data = query ? await searchMulti(query, page) : null;
  const results = data
    ? data.results.filter((item) => item.media_type !== "person")
    : [];
  const totalPages = data?.total_pages ?? 1;
  const totalResults = data?.total_results ?? 0;

  return (
    <div style={{ backgroundColor: "#0b0f1a", minHeight: "100vh" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "24px 16px" }}>

        {/* Header */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
            <span
              style={{
                display: "inline-block",
                width: 3,
                height: 14,
                borderRadius: 2,
                backgroundColor: "#7c3aed",
                flexShrink: 0,
              }}
            />
            <h1 style={{ color: "#ffffff", fontSize: 13, fontWeight: 600, margin: 0 }}>
              {query ? `Results for "${query}"` : "Search"}
            </h1>
            {query && data && (
              <span style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>
                — {totalResults.toLocaleString()} result{totalResults !== 1 ? "s" : ""}
              </span>
            )}
          </div>
        </div>

        {/* No query state */}
        {!query && (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              paddingTop: 80,
              paddingBottom: 80,
              textAlign: "center",
            }}
          >
            <Search style={{ width: 40, height: 40, color: "rgba(255,255,255,0.1)", marginBottom: 12 }} />
            <p style={{ fontSize: 14, color: "rgba(255,255,255,0.3)" }}>
              Search for movies and series
            </p>
            <p style={{ marginTop: 4, fontSize: 12, color: "rgba(255,255,255,0.15)" }}>
              Use the search bar in the navbar to get started
            </p>
          </div>
        )}

        {/* Results grid */}
        {query && results.length > 0 && (
          <>
            <div
              style={{
                display: "grid",
                gap: "20px 12px",
                gridTemplateColumns: "repeat(auto-fill, minmax(105px, 1fr))",
              }}
            >
              {results.map((item) => (
                <MediaCard
                  key={`${item.id}-${item.media_type}`}
                  item={item}
                  showType={true}
                  width={"100%"}
                />
              ))}
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={`ph-${i}`} aria-hidden="true" style={{ visibility: "hidden", minWidth: 105 }} />
              ))}
            </div>

            <Suspense fallback={<div style={{ height: 64 }} />}>
              <PaginationControls currentPage={page} totalPages={totalPages} />
            </Suspense>
          </>
        )}

        {/* No results */}
        {query && results.length === 0 && (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              paddingTop: 80,
              paddingBottom: 80,
              textAlign: "center",
            }}
          >
            <Search style={{ width: 40, height: 40, color: "rgba(255,255,255,0.1)", marginBottom: 12 }} />
            <p style={{ fontSize: 14, color: "rgba(255,255,255,0.3)" }}>
              No results for &ldquo;{query}&rdquo;
            </p>
            <p style={{ marginTop: 4, fontSize: 12, color: "rgba(255,255,255,0.15)" }}>
              Try a different search term
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
