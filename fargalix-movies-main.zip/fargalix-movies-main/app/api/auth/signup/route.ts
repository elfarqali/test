import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { signToken, SESSION_COOKIE } from "@/lib/session";

export async function POST(req: NextRequest) {
  try {
    const { email, username, password } = await req.json();

    // ── Validate ───────────────────────────────────────────────────────────
    if (!email || !username || !password) {
      return NextResponse.json({ error: "All fields are required." }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: "Invalid email address." }, { status: 400 });
    }
    if (username.length < 3 || username.length > 24) {
      return NextResponse.json(
        { error: "Username must be 3–24 characters." },
        { status: 400 }
      );
    }
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      return NextResponse.json(
        { error: "Username may only contain letters, numbers, and underscores." },
        { status: 400 }
      );
    }
    if (password.length < 8) {
      return NextResponse.json(
        { error: "Password must be at least 8 characters." },
        { status: 400 }
      );
    }

    // ── Check registration setting ─────────────────────────────────────────
    const regSetting = await db.siteSetting.findUnique({ where: { key: "allow_registration" } });
    if (regSetting?.value === "false") {
      return NextResponse.json({ error: "Registration is currently disabled." }, { status: 403 });
    }

    // ── Check duplicates ───────────────────────────────────────────────────
    const existingEmail = await db.user.findUnique({ where: { email: email.toLowerCase() } });
    if (existingEmail) {
      return NextResponse.json({ error: "This email is already in use." }, { status: 409 });
    }
    const existingUsername = await db.user.findUnique({ where: { username: username.toLowerCase() } });
    if (existingUsername) {
      return NextResponse.json({ error: "This username is already taken." }, { status: 409 });
    }

    // ── Create user ────────────────────────────────────────────────────────
    const hashed = await bcrypt.hash(password, 12);
    const user = await db.user.create({
      data: {
        email: email.toLowerCase(),
        username: username.toLowerCase(),
        password: hashed,
      },
    });

    // ── Issue session ──────────────────────────────────────────────────────
    const token = await signToken({
      userId: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
    });

    const res = NextResponse.json({
      user: { id: user.id, email: user.email, username: user.username, role: user.role },
      message: "Account created successfully.",
    }, { status: 201 });

    res.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 30, // 30 days
      path: "/",
    });

    return res;
  } catch (err) {
    console.error("[signup]", err);
    return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
  }
}
