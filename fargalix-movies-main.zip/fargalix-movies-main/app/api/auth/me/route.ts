import { NextResponse } from "next/server";
import { getSession, signToken, SESSION_COOKIE } from "@/lib/session";
import { db } from "@/lib/db";

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }

  const user = await db.user.findUnique({
    where: { id: session.userId },
    select: { id: true, email: true, username: true, role: true, avatarUrl: true, banned: true },
  });

  if (!user || user.banned) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }

  // Re-issue the JWT cookie with the current DB role so that role changes
  // (grant or revoke admin) take effect on the next page navigation
  // without requiring the user to log out and log back in.
  const freshToken = await signToken({
    userId: user.id,
    email: user.email,
    username: user.username,
    role: user.role,
  });

  const res = NextResponse.json({
    user: { id: user.id, email: user.email, username: user.username, role: user.role, avatarUrl: user.avatarUrl },
  });

  res.cookies.set(SESSION_COOKIE, freshToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 30,
    path: "/",
  });

  return res;
}
