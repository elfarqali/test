import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// GET /api/media-comments?mediaType=TV&mediaId=123
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const mediaType = searchParams.get("mediaType");
  const mediaId = Number(searchParams.get("mediaId"));

  if (!mediaType || !["TV", "MOVIE"].includes(mediaType) || !mediaId || isNaN(mediaId)) {
    return NextResponse.json({ error: "mediaType and mediaId are required." }, { status: 400 });
  }

  try {
    const comments = await db.mediaComment.findMany({
      where: { mediaType: mediaType as "TV" | "MOVIE", mediaId },
      orderBy: { createdAt: "desc" },
      take: 100,
      select: {
        id: true,
        body: true,
        createdAt: true,
        userId: true,
        user: { select: { id: true, username: true, avatarUrl: true } },
      },
    });
    return NextResponse.json(
      { comments },
      {
        headers: {
          // Cache comments for 60s at CDN edge — new comments appear within ~1 min
          "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300",
        },
      }
    );
  } catch (err) {
    console.error("[GET /api/media-comments]", err);
    return NextResponse.json({ error: "Failed to load comments." }, { status: 500 });
  }
}

// POST /api/media-comments
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { body, mediaType, mediaId } = await req.json();

    if (!body?.trim()) {
      return NextResponse.json({ error: "Comment body is required." }, { status: 400 });
    }
    if (body.trim().length > 2000) {
      return NextResponse.json({ error: "Comment must be 2000 characters or less." }, { status: 400 });
    }
    // Block external links for non-admins
    if (session.role !== "ADMIN") {
      const URL_PATTERN = /https?:\/\/|www\.\S+\.\S+|\b\S+\.(com|net|org|io|co|tv|gg|me|app|xyz)\b/i;
      if (URL_PATTERN.test(body)) {
        return NextResponse.json({ error: "Links are not allowed." }, { status: 400 });
      }
    }
    if (!mediaType || !["TV", "MOVIE"].includes(mediaType)) {
      return NextResponse.json({ error: "Invalid mediaType." }, { status: 400 });
    }
    if (!mediaId || isNaN(Number(mediaId))) {
      return NextResponse.json({ error: "Invalid mediaId." }, { status: 400 });
    }

    const comment = await db.mediaComment.create({
      data: {
        userId: session.userId,
        body: body.trim(),
        mediaType: mediaType as "TV" | "MOVIE",
        mediaId: Number(mediaId),
      },
      select: {
        id: true,
        body: true,
        createdAt: true,
        userId: true,
        user: { select: { id: true, username: true, avatarUrl: true } },
      },
    });

    return NextResponse.json({ comment }, { status: 201 });
  } catch (err) {
    console.error("[POST /api/media-comments]", err);
    return NextResponse.json({ error: "Failed to post comment." }, { status: 500 });
  }
}
