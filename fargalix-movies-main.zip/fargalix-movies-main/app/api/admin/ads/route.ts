import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// GET /api/admin/ads — list all ads
export async function GET() {
    const session = await getSession();
    if (!session || session.role !== "ADMIN") {
        return NextResponse.json({ error: "Forbidden." }, { status: 403 });
    }

    const ads = await db.ad.findMany({
        orderBy: [{ displayOrder: "asc" }, { createdAt: "asc" }],
    });

    return NextResponse.json({ ads });
}

// POST /api/admin/ads — create a new ad
export async function POST(req: NextRequest) {
    const session = await getSession();
    if (!session || session.role !== "ADMIN") {
        return NextResponse.json({ error: "Forbidden." }, { status: 403 });
    }

    const body = await req.json();
    const { name, code, placement, position, displayOrder, active } = body;

    if (!name?.trim() || !code?.trim() || !placement) {
        return NextResponse.json(
            { error: "Name, code, and placement are required." },
            { status: 400 }
        );
    }

    const ad = await db.ad.create({
        data: {
            name: name.trim(),
            code: code.trim(),
            placement,
            position: position ?? "TOP",
            displayOrder: typeof displayOrder === "number" ? displayOrder : 0,
            active: active ?? true,
        },
    });

    return NextResponse.json({ ad }, { status: 201 });
}
