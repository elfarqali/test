import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// PATCH /api/admin/ads/:id — update an ad
export async function PATCH(
    req: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    const session = await getSession();
    if (!session || session.role !== "ADMIN") {
        return NextResponse.json({ error: "Forbidden." }, { status: 403 });
    }

    const { id } = await params;
    const body = await req.json();
    const { name, code, placement, position, displayOrder, active } = body;

    const data: Record<string, unknown> = {};
    if (name !== undefined) data.name = name.trim?.() ?? name;
    if (code !== undefined) data.code = code.trim?.() ?? code;
    if (placement !== undefined) data.placement = placement;
    if (position !== undefined) data.position = position;
    if (displayOrder !== undefined) data.displayOrder = typeof displayOrder === "number" ? displayOrder : parseInt(displayOrder) || 0;
    if (active !== undefined) data.active = active;

    try {
        const ad = await db.ad.update({ where: { id }, data });
        return NextResponse.json({ ad });
    } catch {
        return NextResponse.json({ error: "Ad not found." }, { status: 404 });
    }
}

// DELETE /api/admin/ads/:id — delete an ad
export async function DELETE(
    _req: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    const session = await getSession();
    if (!session || session.role !== "ADMIN") {
        return NextResponse.json({ error: "Forbidden." }, { status: 403 });
    }

    const { id } = await params;
    try {
        await db.ad.delete({ where: { id } });
        return NextResponse.json({ ok: true });
    } catch {
        return NextResponse.json({ error: "Ad not found." }, { status: 404 });
    }
}
