import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// GET /api/admin/players — list all players
export async function GET() {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const players = await db.player.findMany({
    orderBy: [{ order: "asc" }, { createdAt: "asc" }],
  });

  return NextResponse.json({ players });
}

// POST /api/admin/players — create a new player
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const body = await req.json();
  const { name, movieUrl, tvUrl, isDefault, active, order } = body;

  if (!name?.trim() || !movieUrl?.trim() || !tvUrl?.trim()) {
    return NextResponse.json({ error: "name, movieUrl, and tvUrl are required." }, { status: 400 });
  }

  // If this is being set as default, unset all others first
  if (isDefault) {
    await db.player.updateMany({ data: { isDefault: false } });
  }

  const player = await db.player.create({
    data: {
      name: name.trim(),
      movieUrl: movieUrl.trim(),
      tvUrl: tvUrl.trim(),
      isDefault: isDefault ?? false,
      active: active ?? true,
      order: typeof order === "number" ? order : 0,
    },
  });

  return NextResponse.json({ player }, { status: 201 });
}
