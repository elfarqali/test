import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// PATCH /api/admin/players/[id] — update a player
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const { id } = await params;
  const body = await req.json();
  const { name, movieUrl, tvUrl, isDefault, active, order } = body;

  // If setting as default, unset all others first
  if (isDefault === true) {
    await db.player.updateMany({ where: { id: { not: id } }, data: { isDefault: false } });
  }

  const player = await db.player.update({
    where: { id },
    data: {
      ...(name !== undefined && { name: name.trim() }),
      ...(movieUrl !== undefined && { movieUrl: movieUrl.trim() }),
      ...(tvUrl !== undefined && { tvUrl: tvUrl.trim() }),
      ...(isDefault !== undefined && { isDefault }),
      ...(active !== undefined && { active }),
      ...(order !== undefined && { order }),
    },
  });

  return NextResponse.json({ player });
}

// DELETE /api/admin/players/[id] — delete a player
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const { id } = await params;
  await db.player.delete({ where: { id } });

  return NextResponse.json({ ok: true });
}
