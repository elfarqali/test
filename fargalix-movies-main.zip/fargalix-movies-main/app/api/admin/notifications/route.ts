import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// GET /api/admin/notifications?page=1 — list sent notifications
export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const page = Math.max(1, parseInt(searchParams.get("page") ?? "1", 10));
  const limit = 20;

  const [notifications, total] = await Promise.all([
    db.notification.findMany({
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * limit,
      take: limit,
      select: {
        id: true,
        title: true,
        message: true,
        createdAt: true,
        user: { select: { username: true } },
      },
    }),
    db.notification.count(),
  ]);

  return NextResponse.json({ notifications, total, page, totalPages: Math.ceil(total / limit) });
}

// POST /api/admin/notifications — send notification to a user or all users
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const body = await req.json();
  const { title, message, userId } = body as {
    title: string;
    message: string;
    userId?: string; // undefined → send to all
  };

  if (!title?.trim() || !message?.trim()) {
    return NextResponse.json({ error: "Title and message are required." }, { status: 400 });
  }

  if (userId) {
    // Send to a specific user
    const user = await db.user.findUnique({ where: { id: userId }, select: { id: true } });
    if (!user) return NextResponse.json({ error: "User not found." }, { status: 404 });

    await db.notification.create({ data: { userId, title: title.trim(), message: message.trim() } });
    return NextResponse.json({ sent: 1 });
  }

  // Broadcast to all users
  const users = await db.user.findMany({ select: { id: true } });
  await db.notification.createMany({
    data: users.map((u: any) => ({ userId: u.id, title: title.trim(), message: message.trim() })),
  });

  return NextResponse.json({ sent: users.length });
}

// DELETE /api/admin/notifications?id=123 or ?clearAll=true
export async function DELETE(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  const clearAll = searchParams.get("clearAll") === "true";

  if (clearAll) {
    await db.notification.deleteMany({});
    return NextResponse.json({ deleted: true });
  }

  if (id) {
    await db.notification.delete({ where: { id } }).catch(() => { });
    return NextResponse.json({ deleted: true });
  }

  return NextResponse.json({ error: "Missing id or clearAll param." }, { status: 400 });
}
