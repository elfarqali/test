import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { getLevelData, estimateWatchMinutes } from "@/lib/level";

// GET /api/admin/users?page=1&search=
export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const page = Math.max(1, parseInt(searchParams.get("page") ?? "1", 10));
  const limit = 20;
  const search = searchParams.get("search") ?? "";

  const where = search
    ? {
      OR: [
        { email: { contains: search, mode: "insensitive" as const } },
        { username: { contains: search, mode: "insensitive" as const } },
      ],
    }
    : {};

  const [rawUsers, total] = await Promise.all([
    db.user.findMany({
      where,
      select: {
        id: true,
        email: true,
        username: true,
        role: true,
        banned: true,
        bonusMinutes: true,
        createdAt: true,
        _count: { select: { favorites: true, continueWatching: true } },
        continueWatching: { select: { mediaType: true, progress: true } },
      },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * limit,
      take: limit,
    }),
    db.user.count({ where }),
  ]);

  const users = rawUsers.map(({ continueWatching, bonusMinutes, ...u }: any) => {
    const totalMinutes = estimateWatchMinutes(continueWatching) + bonusMinutes;
    const { level } = getLevelData(totalMinutes);
    return { ...u, bonusMinutes, level };
  });

  return NextResponse.json({ users, total, page, totalPages: Math.ceil(total / limit) });
}
