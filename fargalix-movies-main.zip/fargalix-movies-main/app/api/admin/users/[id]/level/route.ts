import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { getLevelData, estimateWatchMinutes } from "@/lib/level";

// POST /api/admin/users/[id]/level — increase user level by 1
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const { id } = await params;

  const user = await db.user.findUnique({
    where: { id },
    select: {
      bonusMinutes: true,
      continueWatching: { select: { mediaType: true, progress: true } },
    },
  });

  if (!user) {
    return NextResponse.json({ error: "User not found." }, { status: 404 });
  }

  const currentTotalMinutes = estimateWatchMinutes(user.continueWatching) + user.bonusMinutes;
  const { level, isMaxLevel } = getLevelData(currentTotalMinutes);

  if (isMaxLevel) {
    return NextResponse.json({ error: "User is already at max level." }, { status: 400 });
  }

  // Minutes needed to advance 1 level = level * 60 (level N requires N hours)
  const minutesToAdd = level * 60;

  const updated = await db.user.update({
    where: { id },
    data: { bonusMinutes: { increment: minutesToAdd } },
    select: { id: true, bonusMinutes: true },
  });

  const newTotalMinutes = estimateWatchMinutes(user.continueWatching) + updated.bonusMinutes;
  const newLevelData = getLevelData(newTotalMinutes);

  return NextResponse.json({ level: newLevelData.level });
}
