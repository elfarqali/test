import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// PATCH /api/admin/users/[id]  — update role or banned status
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const { id } = await params;
  const body = await req.json();

  // Prevent self-demotion / self-ban
  if (id === session.userId) {
    return NextResponse.json({ error: "You cannot modify your own account here." }, { status: 400 });
  }

  const data: Record<string, unknown> = {};
  if (typeof body.banned === "boolean") data.banned = body.banned;
  if (body.role === "USER" || body.role === "ADMIN") data.role = body.role;

  const user = await db.user.update({
    where: { id },
    data,
    select: { id: true, email: true, username: true, role: true, banned: true },
  });

  return NextResponse.json({ user });
}

// DELETE /api/admin/users/[id]
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const { id } = await params;

  if (id === session.userId) {
    return NextResponse.json({ error: "You cannot delete your own account here." }, { status: 400 });
  }

  await db.user.delete({ where: { id } });
  return NextResponse.json({ message: "User deleted." });
}
