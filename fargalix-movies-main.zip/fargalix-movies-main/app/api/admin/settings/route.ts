import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { revalidatePath } from "next/cache";

const DEFAULT_SETTINGS = [
  {
    key: "site_name",
    value: "StreamVault",
    label: "Site Name",
    description: "Displayed in the browser tab and branding.",
  },
  {
    key: "maintenance_mode",
    value: "false",
    label: "Maintenance Mode",
    description: 'When "true", only admins can access the site.',
  },
  {
    key: "allow_registration",
    value: "true",
    label: "Allow Registration",
    description: 'When "false", new users cannot sign up.',
  },
];

// GET /api/admin/settings
export async function GET() {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const dbSettings = await db.siteSetting.findMany({
    where: { key: { not: "default_player" } },
  });

  const settings = DEFAULT_SETTINGS.map((def) => {
    const found = dbSettings.find((s) => s.key === def.key);
    return found || def;
  });

  return NextResponse.json({ settings });
}

// PATCH /api/admin/settings  body: { key: value, ... }
export async function PATCH(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const raw = await req.json() as Record<string, string>;
  // Never allow updating the hidden default_player key via this endpoint.
  const { default_player: _ignored, ...body } = raw;

  const updates = await Promise.all(
    Object.entries(body).map(([key, value]) =>
      db.siteSetting.upsert({
        where: { key },
        update: { value: String(value).trim() },
        create: { key, value: String(value).trim() },
      })
    )
  );

  revalidatePath("/", "layout");
  return NextResponse.json({ settings: updates });
}
