import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// GET /api/user/continue-watching
export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const items = await db.continueWatching.findMany({
    where: { userId: session.userId },
    orderBy: { updatedAt: "desc" },
    take: 20,
  });

  return NextResponse.json({ items });
}

// PUT /api/user/continue-watching — upsert a record
export async function PUT(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const {
    tmdbId,
    mediaType,
    title,
    posterPath,
    backdropPath,
    season,
    episode,
    episodeName,
    progress,
  } = await req.json();

  if (!tmdbId || !mediaType || !title) {
    return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
  }

  const item = await db.continueWatching.upsert({
    where: {
      userId_tmdbId_mediaType: {
        userId: session.userId,
        tmdbId: Number(tmdbId),
        mediaType,
      },
    },
    update: {
      title,
      posterPath: posterPath ?? null,
      backdropPath: backdropPath ?? null,
      season: season ?? null,
      episode: episode ?? null,
      episodeName: episodeName ?? null,
      progress: progress ?? 0,
    },
    create: {
      userId: session.userId,
      tmdbId: Number(tmdbId),
      mediaType,
      title,
      posterPath: posterPath ?? null,
      backdropPath: backdropPath ?? null,
      season: season ?? null,
      episode: episode ?? null,
      episodeName: episodeName ?? null,
      progress: progress ?? 0,
    },
  });

  return NextResponse.json({ item });
}

// DELETE /api/user/continue-watching
//   ?clearAll=true            → delete all history for the user
//   ?tmdbId=&mediaType=       → delete a single item
export async function DELETE(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const clearAll = searchParams.get("clearAll");

  if (clearAll === "true") {
    await db.continueWatching.deleteMany({ where: { userId: session.userId } });
    return NextResponse.json({ message: "All history cleared." });
  }

  const tmdbId = searchParams.get("tmdbId");
  const mediaType = searchParams.get("mediaType");

  if (!tmdbId || !mediaType) {
    return NextResponse.json({ error: "Missing tmdbId or mediaType." }, { status: 400 });
  }

  await db.continueWatching.deleteMany({
    where: {
      userId: session.userId,
      tmdbId: Number(tmdbId),
      mediaType: mediaType as "MOVIE" | "TV",
    },
  });

  return NextResponse.json({ message: "Removed from continue watching." });
}
