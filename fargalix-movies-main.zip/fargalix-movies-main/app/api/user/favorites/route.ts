import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// GET /api/user/favorites
export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const favorites = await db.favorite.findMany({
    where: { userId: session.userId },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ favorites });
}

// POST /api/user/favorites  — add a favorite
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { tmdbId, mediaType, title, posterPath, backdropPath, voteAverage, year } =
    await req.json();

  if (!tmdbId || !mediaType || !title) {
    return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
  }

  const favorite = await db.favorite.upsert({
    where: {
      userId_tmdbId_mediaType: {
        userId: session.userId,
        tmdbId: Number(tmdbId),
        mediaType,
      },
    },
    update: {},
    create: {
      userId: session.userId,
      tmdbId: Number(tmdbId),
      mediaType,
      title,
      posterPath: posterPath ?? null,
      backdropPath: backdropPath ?? null,
      voteAverage: voteAverage ? Number(voteAverage) : null,
      year: year ?? null,
    },
  });

  return NextResponse.json({ favorite }, { status: 201 });
}

// DELETE /api/user/favorites?tmdbId=&mediaType=
export async function DELETE(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const tmdbId = searchParams.get("tmdbId");
  const mediaType = searchParams.get("mediaType");

  if (!tmdbId || !mediaType) {
    return NextResponse.json({ error: "Missing tmdbId or mediaType." }, { status: 400 });
  }

  await db.favorite.deleteMany({
    where: {
      userId: session.userId,
      tmdbId: Number(tmdbId),
      mediaType: mediaType as "MOVIE" | "TV",
    },
  });

  return NextResponse.json({ message: "Removed from favorites." });
}
