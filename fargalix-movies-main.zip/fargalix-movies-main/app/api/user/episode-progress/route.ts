import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// GET /api/user/episode-progress?tvId=&season=
// Returns all episode progress rows for a show (optionally filtered by season).
export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ items: [] });

  const { searchParams } = new URL(req.url);
  const tvId = searchParams.get("tvId");
  const season = searchParams.get("season");

  if (!tvId) return NextResponse.json({ error: "Missing tvId" }, { status: 400 });

  const items = await db.episodeProgress.findMany({
    where: {
      userId: session.userId,
      tvId: Number(tvId),
      ...(season != null ? { season: Number(season) } : {}),
    },
  });

  return NextResponse.json({ items });
}

// PUT /api/user/episode-progress
// Body: { tvId, season, episode, progress }
export async function PUT(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { tvId, season, episode, progress } = body as {
    tvId: number;
    season: number;
    episode: number;
    progress: number;
  };

  if (tvId == null || season == null || episode == null || progress == null) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  const clamped = Math.min(100, Math.max(0, Number(progress)));
  const where = {
    userId: session.userId,
    tvId: Number(tvId),
    season: Number(season),
    episode: Number(episode),
  };

  try {
    // Use findFirst with individual field filters — avoids the composite-key
    // shorthand (`userId_tvId_season_episode`) which can miscompile in some
    // Prisma 7 driver-adapter setups and cause unhandled 500 errors.
    const existing = await db.episodeProgress.findFirst({
      where,
      select: { progress: true },
    });

    // Progress is monotonically increasing — a low timer tick (e.g. 1 %) must
    // never overwrite a higher value set by "mark as watched" (100 %).
    const finalProgress = existing ? Math.max(existing.progress, clamped) : clamped;

    if (existing === null) {
      // No row yet — create it.
      await db.episodeProgress.create({ data: { ...where, progress: finalProgress } });
    } else if (finalProgress > existing.progress) {
      // Row exists but the new value is strictly higher — update it.
      await db.episodeProgress.updateMany({ where, data: { progress: finalProgress } });
    }
    // If finalProgress === existing.progress the value is unchanged — no-op.

    return NextResponse.json({ ok: true, progress: finalProgress });
  } catch (err) {
    console.error("[episode-progress PUT]", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
