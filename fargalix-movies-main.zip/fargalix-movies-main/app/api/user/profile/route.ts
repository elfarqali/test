import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// PATCH /api/user/profile — change password or update avatar
export async function PATCH(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { currentPassword, newPassword, avatarUrl } = body;

  // --- Change password ---
  if (newPassword !== undefined) {
    if (!currentPassword || !newPassword) {
      return NextResponse.json({ error: "Current and new password are required." }, { status: 400 });
    }
    if (newPassword.length < 8) {
      return NextResponse.json({ error: "New password must be at least 8 characters." }, { status: 400 });
    }

    const user = await db.user.findUnique({ where: { id: session.userId } });
    if (!user) return NextResponse.json({ error: "User not found." }, { status: 404 });

    const valid = await bcrypt.compare(currentPassword, user.password);
    if (!valid) {
      return NextResponse.json({ error: "Current password is incorrect." }, { status: 400 });
    }

    const hashed = await bcrypt.hash(newPassword, 12);
    await db.user.update({ where: { id: session.userId }, data: { password: hashed } });
    return NextResponse.json({ message: "Password updated successfully." });
  }

  // --- Update avatar ---
  if (avatarUrl !== undefined) {
    await db.user.update({ where: { id: session.userId }, data: { avatarUrl: avatarUrl || null } });
    return NextResponse.json({ message: "Avatar updated successfully." });
  }

  return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
}
