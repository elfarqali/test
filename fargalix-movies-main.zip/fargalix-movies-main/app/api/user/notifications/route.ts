import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// GET /api/user/notifications — get current user's notifications
export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  const notifications = await db.notification.findMany({
    where: { userId: session.userId },
    orderBy: { createdAt: "desc" },
    take: 30,
    select: { id: true, title: true, message: true, read: true, createdAt: true },
  });

  const unreadCount = notifications.filter((n: any) => !n.read).length;

  return NextResponse.json({ notifications, unreadCount });
}

// DELETE /api/user/notifications — clear all current user's notifications
export async function DELETE() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  await db.notification.deleteMany({
    where: { userId: session.userId },
  });

  return NextResponse.json({ ok: true });
}
