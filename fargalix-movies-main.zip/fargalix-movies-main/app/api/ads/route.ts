import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/ads?placement=HOME_PAGE
// Returns active ads for a given placement (or ALL_PAGES ads)
//
// ── CACHING ────────────────────────────────────────────────────────────────
// Ads change infrequently.  Cache at edge for 5 minutes so that the vast
// majority of requests never reach the serverless function or DB.
// With ~8 ad-slot requests per page view × thousands of page views,
// this alone eliminates tens of thousands of function invocations.
export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const placement = searchParams.get("placement");

    if (!placement) {
        return NextResponse.json({ error: "placement is required." }, { status: 400 });
    }

    // Fetch ads that match the exact placement OR are set to ALL_PAGES
    const ads = await db.ad.findMany({
        where: {
            active: true,
            OR: [
                { placement: placement as any },
                { placement: "ALL_PAGES" },
            ],
        },
        orderBy: [{ displayOrder: "asc" }, { createdAt: "asc" }],
        select: {
            id: true,
            name: true,
            code: true,
            placement: true,
            position: true,
            displayOrder: true,
        },
    });

    return NextResponse.json(
        { ads },
        {
            headers: {
                // CDN caches for 24h, serves stale for 7 days while revalidating
                "Cache-Control": "public, s-maxage=86400, stale-while-revalidate=604800",
            },
        }
    );
}
