import { NextRequest, NextResponse } from "next/server";
import { getTVSeasonDetail } from "@/lib/tmdb";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  const season = searchParams.get("season");

  if (!id || !season) {
    return NextResponse.json({ error: "Missing id or season" }, { status: 400 });
  }

  const detail = await getTVSeasonDetail(id, parseInt(season, 10));
  if (!detail) {
    return NextResponse.json({ episodes: [] });
  }

  return NextResponse.json(
    { episodes: detail.episodes },
    {
      headers: {
        // Episode lists rarely change — cache at CDN for 24h
        "Cache-Control": "public, s-maxage=86400, stale-while-revalidate=604800",
      },
    }
  );
}
