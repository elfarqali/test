import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// DELETE /api/discussions/[id]
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;
    const discussion = await db.discussion.findUnique({
      where: { id },
      select: { userId: true },
    });

    if (!discussion) return NextResponse.json({ error: "Not found." }, { status: 404 });

    if (discussion.userId !== session.userId && session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden." }, { status: 403 });
    }

    await db.discussion.delete({ where: { id } });
    return NextResponse.json({ message: "Deleted." });
  } catch (err) {
    console.error("[DELETE /api/discussions/[id]]", err);
    return NextResponse.json({ error: "Failed to delete discussion." }, { status: 500 });
  }
}
