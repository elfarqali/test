import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

// POST /api/discussions/[id]/like — toggle like
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id: discussionId } = await params;

    const exists = await db.discussion.findUnique({
      where: { id: discussionId },
      select: { id: true },
    });
    if (!exists) return NextResponse.json({ error: "Discussion not found." }, { status: 404 });

    const existing = await db.discussionLike.findUnique({
      where: { userId_discussionId: { userId: session.userId, discussionId } },
    });

    if (existing) {
      await db.discussionLike.delete({ where: { id: existing.id } });
      const likeCount = await db.discussionLike.count({ where: { discussionId } });
      return NextResponse.json({ liked: false, likeCount });
    } else {
      await db.discussionLike.create({ data: { userId: session.userId, discussionId } });
      const likeCount = await db.discussionLike.count({ where: { discussionId } });
      return NextResponse.json({ liked: true, likeCount });
    }
  } catch (err) {
    console.error("[POST /api/discussions/[id]/like]", err);
    return NextResponse.json({ error: "Failed to toggle like." }, { status: 500 });
  }
}
