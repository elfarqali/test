import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

type Ctx = { params: Promise<{ id: string }> };

// GET /api/discussions/[id]/replies
export async function GET(
  _req: NextRequest,
  { params }: Ctx
) {
  const { id } = await params;

  const replies = await db.discussionReply.findMany({
    where: { discussionId: id },
    orderBy: { createdAt: "asc" },
    select: {
      id: true,
      body: true,
      createdAt: true,
      userId: true,
      user: { select: { id: true, username: true, avatarUrl: true } },
    },
  });

  return NextResponse.json({ replies });
}

// POST /api/discussions/[id]/replies
export async function POST(
  req: NextRequest,
  { params }: Ctx
) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  const { id } = await params;
  const { body } = await req.json();

  if (!body?.trim()) {
    return NextResponse.json({ error: "Reply body is required." }, { status: 400 });
  }
  if (body.trim().length > 2000) {
    return NextResponse.json({ error: "Reply must be 2000 characters or less." }, { status: 400 });
  }
  // Block external links for non-admins
  if (session.role !== "ADMIN") {
    const URL_PATTERN = /https?:\/\/|www\.\S+\.\S+|\b\S+\.(com|net|org|io|co|tv|gg|me|app|xyz)\b/i;
    if (URL_PATTERN.test(body)) {
      return NextResponse.json({ error: "Links are not allowed." }, { status: 400 });
    }
  }

  const discussion = await db.discussion.findUnique({ where: { id }, select: { id: true } });
  if (!discussion) {
    return NextResponse.json({ error: "Discussion not found." }, { status: 404 });
  }

  const reply = await db.discussionReply.create({
    data: { discussionId: id, userId: session.userId, body: body.trim() },
    select: {
      id: true,
      body: true,
      createdAt: true,
      userId: true,
      user: { select: { id: true, username: true, avatarUrl: true } },
    },
  });

  return NextResponse.json({ reply }, { status: 201 });
}

// DELETE /api/discussions/[id]/replies?replyId=
export async function DELETE(
  req: NextRequest,
  { params }: Ctx
) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  const { id } = await params;
  const replyId = new URL(req.url).searchParams.get("replyId");
  if (!replyId) {
    return NextResponse.json({ error: "replyId is required." }, { status: 400 });
  }

  const reply = await db.discussionReply.findUnique({
    where: { id: replyId },
    select: { userId: true, discussionId: true },
  });

  if (!reply || reply.discussionId !== id) {
    return NextResponse.json({ error: "Reply not found." }, { status: 404 });
  }
  if (reply.userId !== session.userId && session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  await db.discussionReply.delete({ where: { id: replyId } });
  return NextResponse.json({ ok: true });
}
