import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { estimateWatchMinutes, getLevelData } from "@/lib/level";

// GET /api/discussions?page=1&limit=20
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const page = Math.max(1, Number(searchParams.get("page") ?? 1));
    const limit = Math.min(50, Number(searchParams.get("limit") ?? 20));
    const session = await getSession();

    const [discussions, total, dbTopUsers] = await Promise.all([
      db.discussion.findMany({
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: "desc" },
        include: {
          user: { select: { id: true, username: true, avatarUrl: true } },
          likes: { select: { userId: true } },
          _count: { select: { replies: true } },
        },
      }),
      db.discussion.count(),
      db.user.findMany({
        take: 5,
        orderBy: { discussions: { _count: "desc" } },
        select: {
          id: true,
          username: true,
          avatarUrl: true,
          _count: { select: { discussions: true } },
          bonusMinutes: true,
          continueWatching: { select: { mediaType: true, progress: true } },
        },
        where: { discussions: { some: {} } },
      }),
    ]);

    const currentUserId = session?.userId ?? null;

    const topUsers = dbTopUsers.map((u: any) => ({
      id: u.id,
      username: u.username,
      avatarUrl: u.avatarUrl,
      _count: u._count,
      level: getLevelData(estimateWatchMinutes(u.continueWatching) + u.bonusMinutes).level,
    }));

    return NextResponse.json(
      {
        discussions: discussions.map((d: any) => ({
          id: d.id,
          title: d.title,
          body: d.body,
          createdAt: d.createdAt,
          user: d.user,
          likeCount: d.likes.length,
          likedByMe: currentUserId ? d.likes.some((l: any) => l.userId === currentUserId) : false,
          isOwner: d.userId === currentUserId,
          replyCount: d._count.replies,
        })),
        topUsers,
        total,
        page,
        totalPages: Math.ceil(total / limit),
      },
      {
        headers: {
          // CDN caches for 30s — tolerable staleness for a forum
          "Cache-Control": "public, s-maxage=30, stale-while-revalidate=300",
        },
      }
    );
  } catch (err) {
    console.error("[GET /api/discussions]", err);
    return NextResponse.json(
      { error: "Failed to load discussions. The database tables may not exist yet — run `npx prisma db push`." },
      { status: 500 }
    );
  }
}

// POST /api/discussions — create a discussion (auth required)
export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { title, body } = await req.json();

    if (!title?.trim() || !body?.trim()) {
      return NextResponse.json({ error: "Title and body are required." }, { status: 400 });
    }
    if (title.trim().length > 120) {
      return NextResponse.json({ error: "Title must be 120 characters or less." }, { status: 400 });
    }

    // Non-admins cannot post links
    if (session.role !== "ADMIN") {
      const urlPattern = /https?:\/\/|www\./i;
      if (urlPattern.test(title) || urlPattern.test(body)) {
        return NextResponse.json({ error: "Only admins can post links." }, { status: 403 });
      }
    }

    // Non-admins are limited to 1 discussion per 24 hours
    if (session.role !== "ADMIN") {
      const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const recentCount = await db.discussion.count({
        where: { userId: session.userId, createdAt: { gte: since } },
      });
      if (recentCount >= 1) {
        return NextResponse.json(
          { error: "You can only create 1 discussion per day." },
          { status: 429 }
        );
      }
    }

    const discussion = await db.discussion.create({
      data: {
        userId: session.userId,
        title: title.trim(),
        body: body.trim(),
      },
      include: {
        user: { select: { id: true, username: true, avatarUrl: true } },
      },
    });

    return NextResponse.json(
      {
        discussion: {
          id: discussion.id,
          title: discussion.title,
          body: discussion.body,
          createdAt: discussion.createdAt,
          user: discussion.user,
          likeCount: 0,
          likedByMe: false,
          isOwner: true,
        },
      },
      { status: 201 }
    );
  } catch (err) {
    console.error("[POST /api/discussions]", err);
    return NextResponse.json({ error: "Failed to create discussion." }, { status: 500 });
  }
}
