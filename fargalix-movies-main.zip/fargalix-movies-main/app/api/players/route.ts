import { NextResponse } from "next/server";
import { getCachedPlayers } from "@/lib/players";

// GET /api/players — public: returns all active players ordered by default first, then order
// Cached at CDN edge for 1 hour — players rarely change
export async function GET() {
  const players = await getCachedPlayers();
  return NextResponse.json(
    { players },
    {
      headers: {
        "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=86400",
      },
    }
  );
}
