import { NextRequest, NextResponse } from "next/server";
import { searchMulti } from "@/lib/tmdb";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q") ?? "";
  if (!q.trim()) return NextResponse.json({ results: [] });

  try {
    const data = await searchMulti(q, 1);
    const results = data.results
      .filter(
        (r) =>
          r.media_type !== "person" &&
          (r.poster_path || r.backdrop_path)
      )
      .slice(0, 7)
      .map((r) => ({
        id: r.id,
        mediaType: r.media_type,
        title: r.title ?? r.name ?? "",
        year: (r.release_date ?? r.first_air_date ?? "").slice(0, 4),
        poster: r.poster_path
          ? `https://image.tmdb.org/t/p/w92${r.poster_path}`
          : null,
      }));
    return NextResponse.json(
      { results },
      {
        headers: {
          // CDN caches search suggestions for 1 hour; serves stale for 24h while revalidating
          "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=86400",
        },
      }
    );
  } catch {
    return NextResponse.json({ results: [] });
  }
}
