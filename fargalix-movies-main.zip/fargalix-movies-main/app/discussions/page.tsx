"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import { useAuth } from "@/components/auth/auth-provider";
import type { AuthUser } from "@/components/auth/auth-provider";
import {
  Heart, MessageSquare, Plus, X, Trash2,
  Trophy, Loader2, AlertTriangle, Send, ChevronDown, ChevronUp, CornerDownRight,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface DiscussionUser {
  id: string;
  username: string;
  avatarUrl: string | null;
}

interface Reply {
  id: string;
  body: string;
  createdAt: string;
  userId: string;
  user: DiscussionUser;
}

interface DiscussionItem {
  id: string;
  title: string;
  body: string;
  createdAt: string;
  user: DiscussionUser;
  likeCount: number;
  likedByMe: boolean;
  isOwner: boolean;
  replyCount: number;
}

interface TopUser {
  id: string;
  username: string;
  avatarUrl: string | null;
  _count: { discussions: number };
  level: number;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function timeAgo(date: string): string {
  const secs = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
  if (secs < 60) return "just now";
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  const mos = Math.floor(days / 30);
  if (mos < 12) return `${mos}mo ago`;
  return `${Math.floor(mos / 12)}y ago`;
}

function Avatar({ user, size = 40 }: { user: DiscussionUser; size?: number }) {
  const initials = user.username.slice(0, 2).toUpperCase();
  return (
    <div
      style={{
        width: size, height: size,
        borderRadius: "50%",
        overflow: "hidden",
        flexShrink: 0,
        background: user.avatarUrl
          ? "transparent"
          : "linear-gradient(135deg,#7c3aed 0%,#a78bfa 100%)",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: size * 0.32, fontWeight: 800, color: "#fff",
        position: "relative",
        border: "1.5px solid rgba(124,58,237,0.25)",
      }}
    >
      {user.avatarUrl ? (
        <Image src={user.avatarUrl} alt={user.username} fill sizes={`${size}px`} style={{ objectFit: "cover" }} unoptimized />
      ) : initials}
    </div>
  );
}

// ─── Single Reply Row ─────────────────────────────────────────────────────────

function ReplyRow({
  reply,
  currentUserId,
  isAdmin,
  onDelete,
  deletingId,
}: {
  reply: Reply;
  currentUserId: string | undefined;
  isAdmin: boolean;
  onDelete: (id: string) => void;
  deletingId: string | null;
}) {
  const canDelete = reply.userId === currentUserId || isAdmin;
  const isDeleting = deletingId === reply.id;

  return (
    <div
      style={{
        display: "flex", gap: 10,
        padding: "11px 0",
        borderBottom: "1px solid rgba(255,255,255,0.04)",
        opacity: isDeleting ? 0.4 : 1,
        transition: "opacity 0.15s ease",
      }}
    >
      <Avatar user={reply.user} size={28} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4, flexWrap: "wrap" }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: "#c4b5fd" }}>
            @{reply.user.username}
          </span>
          <span style={{ fontSize: 11, color: "rgba(255,255,255,0.28)" }}>
            · {timeAgo(reply.createdAt)}
          </span>
        </div>
        <p style={{
          fontSize: 13, color: "rgba(255,255,255,0.7)",
          lineHeight: 1.6, wordBreak: "break-word",
        }}>
          {reply.body}
        </p>
      </div>
      {canDelete && (
        <button
          onClick={() => onDelete(reply.id)}
          disabled={isDeleting}
          title="Delete reply"
          style={{
            width: 26, height: 26, borderRadius: 6,
            background: "transparent",
            border: "1px solid rgba(239,68,68,0.15)",
            color: "rgba(239,68,68,0.4)",
            cursor: isDeleting ? "wait" : "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            flexShrink: 0, alignSelf: "flex-start", marginTop: 2,
            transition: "all 0.15s ease",
          }}
          className="hover:bg-red-500/10 hover:!border-red-500/40 hover:!text-red-400"
        >
          <Trash2 size={11} />
        </button>
      )}
    </div>
  );
}

// ─── Replies Panel ────────────────────────────────────────────────────────────

function RepliesPanel({
  discussionId,
  user,
  onCountChange,
}: {
  discussionId: string;
  user: AuthUser | null;
  onCountChange: (delta: number) => void;
}) {
  const [replies, setReplies] = useState<Reply[]>([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/discussions/${discussionId}/replies`)
      .then((r) => r.json())
      .then((data) => { if (!cancelled) setReplies(data.replies ?? []); })
      .catch(() => { })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [discussionId]);

  // Auto-focus textarea after replies load
  useEffect(() => {
    if (!loading && user) {
      setTimeout(() => textareaRef.current?.focus(), 50);
    }
  }, [loading, user]);

  async function submitReply() {
    const body = text.trim();
    if (!body || submitting) return;
    setSubmitError("");
    // Block external links (mirrors server-side check)
    const URL_PATTERN = /https?:\/\/|www\.\S+\.\S+|\b\S+\.(com|net|org|io|co|tv|gg|me|app|xyz)\b/i;
    if (user?.role !== "ADMIN" && URL_PATTERN.test(body)) {
      setSubmitError("Links are not allowed.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch(`/api/discussions/${discussionId}/replies`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body }),
      });
      const data = await res.json();
      if (!res.ok) { setSubmitError(data.error ?? "Failed to post reply."); return; }
      setReplies((prev) => [...prev, data.reply]);
      onCountChange(1);
      setText("");
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" }), 60);
    } finally {
      setSubmitting(false);
    }
  }

  async function deleteReply(replyId: string) {
    setDeletingId(replyId);
    try {
      const res = await fetch(
        `/api/discussions/${discussionId}/replies?replyId=${replyId}`,
        { method: "DELETE" }
      );
      if (res.ok) {
        setReplies((prev) => prev.filter((r) => r.id !== replyId));
        onCountChange(-1);
      }
    } finally {
      setDeletingId(null);
    }
  }

  const userAsDiscussionUser: DiscussionUser | null = user
    ? { id: user.id, username: user.username, avatarUrl: user.avatarUrl }
    : null;

  return (
    <div style={{ marginTop: 18, paddingTop: 18, borderTop: "1px solid rgba(255,255,255,0.06)" }}>
      <div
        style={{
          marginLeft: 8,
          paddingLeft: 16,
          borderLeft: "2px solid rgba(124,58,237,0.3)",
        }}
      >
        {/* Reply list */}
        {loading ? (
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px 0", color: "rgba(255,255,255,0.28)", fontSize: 12 }}>
            <Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} />
            Loading replies…
          </div>
        ) : replies.length === 0 ? (
          <p style={{ fontSize: 12, color: "rgba(255,255,255,0.22)", padding: "8px 0 12px", fontStyle: "italic" }}>
            No replies yet — be the first!
          </p>
        ) : (
          <div>
            {replies.map((r) => (
              <ReplyRow
                key={r.id}
                reply={r}
                currentUserId={user?.id}
                isAdmin={user?.role === "ADMIN"}
                onDelete={deleteReply}
                deletingId={deletingId}
              />
            ))}
          </div>
        )}

        {/* Reply input */}
        {user ? (
          <div style={{ display: "flex", gap: 9, marginTop: 14, alignItems: "flex-start" }}>
            {userAsDiscussionUser && <Avatar user={userAsDiscussionUser} size={28} />}
            <div style={{ flex: 1 }}>
              <textarea
                ref={textareaRef}
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    submitReply();
                  }
                }}
                placeholder="Write a reply… (Enter to post, Shift+Enter for new line)"
                rows={2}
                maxLength={2000}
                style={{
                  width: "100%", boxSizing: "border-box",
                  padding: "8px 11px",
                  borderRadius: 9,
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  color: "#fff", fontSize: 13,
                  outline: "none", resize: "vertical",
                  minHeight: 60, fontFamily: "inherit", lineHeight: 1.5,
                  transition: "border-color 0.15s ease",
                }}
                onFocus={(e) => { e.target.style.borderColor = "rgba(124,58,237,0.5)"; }}
                onBlur={(e) => { e.target.style.borderColor = "rgba(255,255,255,0.1)"; }}
              />
              {submitError && (
                <p style={{ fontSize: 11, color: "#f87171", marginTop: 4 }}>{submitError}</p>
              )}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 7 }}>
                <span style={{ fontSize: 10, color: "rgba(255,255,255,0.2)" }}>
                  {text.length}/2000
                </span>
                <button
                  onClick={submitReply}
                  disabled={!text.trim() || submitting}
                  style={{
                    display: "flex", alignItems: "center", gap: 6,
                    padding: "6px 14px", borderRadius: 8,
                    background: !text.trim() || submitting ? "rgba(124,58,237,0.2)" : "rgba(124,58,237,0.75)",
                    border: "1px solid rgba(124,58,237,0.4)",
                    color: !text.trim() || submitting ? "rgba(255,255,255,0.35)" : "#fff",
                    fontSize: 12, fontWeight: 700,
                    cursor: !text.trim() || submitting ? "not-allowed" : "pointer",
                    transition: "all 0.15s ease",
                  }}
                >
                  {submitting
                    ? <Loader2 size={12} style={{ animation: "spin 1s linear infinite" }} />
                    : <Send size={12} />}
                  {submitting ? "Posting…" : "Post Reply"}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div style={{ marginTop: 12, padding: "10px 14px", borderRadius: 9, background: "rgba(124,58,237,0.07)", border: "1px solid rgba(124,58,237,0.18)" }}>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.45)" }}>
              <Link href="/signin?redirect=/discussions" style={{ color: "#a78bfa", fontWeight: 700, textDecoration: "none" }}>
                Sign in
              </Link>
              {" "}to write a reply.
            </p>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}

// ─── Discussion Card ──────────────────────────────────────────────────────────

function DiscussionCard({
  item,
  user,
  onLike,
  onDelete,
}: {
  item: DiscussionItem;
  user: AuthUser | null;
  onLike: (id: string) => void;
  onDelete: (id: string) => void;
}) {
  const [hovered, setHovered] = useState(false);
  const [repliesOpen, setRepliesOpen] = useState(false);
  const [replyCount, setReplyCount] = useState(item.replyCount);

  return (
    <article
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? "rgba(124,58,237,0.07)" : "rgba(255,255,255,0.03)",
        border: repliesOpen
          ? "1px solid rgba(124,58,237,0.45)"
          : hovered
            ? "1px solid rgba(124,58,237,0.38)"
            : "1px solid rgba(255,255,255,0.07)",
        borderRadius: 16,
        padding: "22px 24px",
        cursor: "default",
        transform: hovered && !repliesOpen ? "translateY(-3px)" : "translateY(0)",
        boxShadow: hovered
          ? "0 8px 32px rgba(124,58,237,0.18), 0 2px 8px rgba(0,0,0,0.4)"
          : "0 2px 8px rgba(0,0,0,0.25)",
        transition: "all 0.22s ease",
        position: "relative",
      }}
    >
      {/* Header row */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
        <Avatar user={item.user} size={40} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 13, fontWeight: 700, color: "#c4b5fd" }}>
              @{item.user.username}
            </span>
            <span style={{ fontSize: 11, color: "rgba(255,255,255,0.3)" }}>
              · {timeAgo(item.createdAt)}
            </span>
          </div>
        </div>
        {(item.isOwner || user?.role === "ADMIN") && (
          <button
            onClick={() => onDelete(item.id)}
            title="Delete discussion"
            style={{
              width: 30, height: 30, borderRadius: 7,
              background: "transparent",
              border: "1px solid rgba(239,68,68,0.2)",
              color: "rgba(239,68,68,0.5)",
              cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center",
              transition: "all 0.15s ease", flexShrink: 0,
            }}
            className="hover:bg-red-500/15 hover:border-red-500/50 hover:!text-red-400"
          >
            <Trash2 size={13} />
          </button>
        )}
      </div>

      {/* Title */}
      <h3 style={{ fontSize: 17, fontWeight: 800, color: "#fff", letterSpacing: "-0.02em", marginBottom: 8, lineHeight: 1.35 }}>
        {item.title}
      </h3>

      {/* Body */}
      <p
        style={{
          fontSize: 13, color: "rgba(255,255,255,0.48)", lineHeight: 1.65, marginBottom: 16,
          display: "-webkit-box",
          WebkitLineClamp: repliesOpen ? undefined : 3,
          WebkitBoxOrient: "vertical",
          overflow: repliesOpen ? "visible" : "hidden",
        }}
      >
        {item.body}
      </p>

      {/* Footer */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
        {/* Like */}
        <button
          onClick={() => onLike(item.id)}
          style={{
            display: "flex", alignItems: "center", gap: 6,
            background: item.likedByMe ? "rgba(124,58,237,0.18)" : "transparent",
            border: item.likedByMe ? "1px solid rgba(124,58,237,0.4)" : "1px solid rgba(255,255,255,0.1)",
            borderRadius: 20, padding: "5px 12px",
            color: item.likedByMe ? "#a78bfa" : "rgba(255,255,255,0.45)",
            fontSize: 12, fontWeight: 600, cursor: "pointer",
            transition: "all 0.15s ease",
          }}
          className="hover:border-purple-500/50 hover:text-purple-400"
        >
          <Heart size={13} fill={item.likedByMe ? "#a78bfa" : "none"} style={{ transition: "all 0.15s ease" }} />
          {item.likeCount}
        </button>

        {/* Reply count badge — toggles panel */}
        <button
          onClick={() => setRepliesOpen((o) => !o)}
          style={{
            display: "flex", alignItems: "center", gap: 6,
            background: repliesOpen ? "rgba(124,58,237,0.14)" : "transparent",
            border: repliesOpen ? "1px solid rgba(124,58,237,0.35)" : "1px solid rgba(255,255,255,0.1)",
            borderRadius: 20, padding: "5px 12px",
            color: repliesOpen ? "#a78bfa" : "rgba(255,255,255,0.45)",
            fontSize: 12, fontWeight: 600, cursor: "pointer",
            transition: "all 0.15s ease",
          }}
          className="hover:border-purple-500/40 hover:text-purple-400"
        >
          <MessageSquare size={13} />
          {replyCount} {replyCount === 1 ? "Reply" : "Replies"}
          {repliesOpen
            ? <ChevronUp size={12} style={{ opacity: 0.6 }} />
            : <ChevronDown size={12} style={{ opacity: 0.6 }} />}
        </button>

        {/* Quick "Reply" shortcut when collapsed */}
        {!repliesOpen && (
          <button
            onClick={() => setRepliesOpen(true)}
            style={{
              display: "flex", alignItems: "center", gap: 5,
              background: "transparent", border: "none",
              color: "rgba(255,255,255,0.25)", fontSize: 11, fontWeight: 600,
              cursor: "pointer", padding: "5px 2px",
              transition: "color 0.15s ease",
            }}
            className="hover:!text-purple-400"
          >
            <CornerDownRight size={12} />
            Reply
          </button>
        )}
      </div>

      {/* Replies panel — lazy mounted */}
      {repliesOpen && (
        <RepliesPanel
          discussionId={item.id}
          user={user}
          onCountChange={(delta) => setReplyCount((c) => c + delta)}
        />
      )}
    </article>
  );
}

// ─── Create Discussion Modal ──────────────────────────────────────────────────

function CreateModal({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: (item: DiscussionItem) => void;
}) {
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    // Client-side URL guard (mirrors server-side check for instant feedback)
    if (user?.role !== "ADMIN") {
      const urlPattern = /https?:\/\/|www\./i;
      if (urlPattern.test(title) || urlPattern.test(body)) {
        setError("Only admins can post links.");
        return;
      }
    }

    setSaving(true);
    try {
      const res = await fetch("/api/discussions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, body }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to create.");
      onCreated({ ...data.discussion, replyCount: 0 });
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div
      style={{
        position: "fixed", inset: 0,
        background: "rgba(0,0,0,0.8)", backdropFilter: "blur(6px)",
        display: "flex", alignItems: "center", justifyContent: "center",
        zIndex: 9999, padding: 20,
      }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        style={{
          background: "#111827",
          border: "1px solid rgba(124,58,237,0.35)",
          borderRadius: 20, padding: "32px",
          width: "100%", maxWidth: 560,
          boxShadow: "0 32px 80px rgba(0,0,0,0.8), 0 0 0 1px rgba(124,58,237,0.1)",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
          <div>
            <h2 style={{ fontSize: 18, fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}>
              New Discussion
            </h2>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", marginTop: 3 }}>
              Share a thought with the community
            </p>
          </div>
          <button
            onClick={onClose}
            style={{
              width: 32, height: 32, borderRadius: 8,
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.1)",
              color: "rgba(255,255,255,0.5)",
              cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
            }}
          >
            <X size={16} />
          </button>
        </div>

        <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <label style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.4)", letterSpacing: "0.07em" }}>
              TITLE
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="What's on your mind?"
              maxLength={120}
              required
              style={modalInputStyle}
            />
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.2)", textAlign: "right" }}>
              {title.length}/120
            </span>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <label style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.4)", letterSpacing: "0.07em" }}>
              DESCRIPTION
            </label>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Share more details, ask a question, or start a conversation…"
              required
              rows={5}
              style={{ ...modalInputStyle, resize: "vertical", minHeight: 120, fontFamily: "inherit" }}
            />
          </div>

          {error && (
            <div style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "10px 14px", borderRadius: 9,
              background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.25)",
              color: "#fca5a5", fontSize: 13,
            }}>
              <AlertTriangle size={13} />
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={saving || !title.trim() || !body.trim()}
            style={{
              display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
              padding: "12px", borderRadius: 11,
              background: saving || !title.trim() || !body.trim()
                ? "rgba(124,58,237,0.35)"
                : "linear-gradient(135deg,#7c3aed 0%,#5b21b6 100%)",
              border: "none", color: "#fff",
              fontSize: 14, fontWeight: 700,
              cursor: saving || !title.trim() || !body.trim() ? "not-allowed" : "pointer",
              transition: "all 0.15s ease", letterSpacing: "0.02em",
            }}
          >
            {saving ? <Loader2 size={16} style={{ animation: "spin 1s linear infinite" }} /> : <Send size={15} />}
            {saving ? "Posting…" : "Post Discussion"}
          </button>
        </form>
      </div>
    </div>
  );
}

// ─── Delete Discussion Modal ──────────────────────────────────────────────────

function DeleteModal({ onConfirm, onCancel, loading }: {
  onConfirm: () => void;
  onCancel: () => void;
  loading: boolean;
}) {
  return (
    <div
      style={{
        position: "fixed", inset: 0,
        background: "rgba(0,0,0,0.8)", backdropFilter: "blur(4px)",
        display: "flex", alignItems: "center", justifyContent: "center",
        zIndex: 9999, padding: 20,
      }}
      onClick={(e) => { if (e.target === e.currentTarget) onCancel(); }}
    >
      <div style={{
        background: "#111827", border: "1px solid rgba(124,58,237,0.3)",
        borderRadius: 16, padding: "28px",
        maxWidth: 400, width: "100%",
        boxShadow: "0 24px 64px rgba(0,0,0,0.8)",
      }}>
        <div style={{
          width: 48, height: 48, borderRadius: 12,
          background: "rgba(239,68,68,0.12)", border: "1px solid rgba(239,68,68,0.25)",
          display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16,
        }}>
          <AlertTriangle size={22} style={{ color: "#ef4444" }} />
        </div>
        <h3 style={{ fontSize: 17, fontWeight: 700, color: "#fff", marginBottom: 8 }}>
          Delete Discussion?
        </h3>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", lineHeight: 1.6, marginBottom: 24 }}>
          This discussion and all its replies will be permanently removed. This action cannot be undone.
        </p>
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
          <button onClick={onCancel} disabled={loading} style={cancelBtnStyle}>Cancel</button>
          <button
            onClick={onConfirm} disabled={loading}
            style={{
              display: "flex", alignItems: "center", gap: 6,
              padding: "9px 20px", borderRadius: 9,
              background: loading ? "rgba(239,68,68,0.3)" : "rgba(239,68,68,0.85)",
              border: "none", color: "#fff", fontSize: 13, fontWeight: 700,
              cursor: loading ? "wait" : "pointer",
            }}
          >
            {loading ? "Deleting…" : <><Trash2 size={13} /> Delete</>}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

function Sidebar({
  topUsers,
  onCreateClick,
  isAuthed,
}: {
  topUsers: TopUser[];
  onCreateClick: () => void;
  isAuthed: boolean;
}) {
  const rankLabels = ["🥇", "🥈", "🥉", "4th", "5th"];

  return (
    <aside style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <button
        onClick={onCreateClick}
        style={{
          display: "flex", alignItems: "center", justifyContent: "center", gap: 9,
          width: "100%", padding: "14px",
          borderRadius: 14,
          background: "linear-gradient(135deg,#7c3aed 0%,#5b21b6 100%)",
          border: "1px solid rgba(124,58,237,0.4)",
          color: "#fff", fontSize: 14, fontWeight: 800,
          cursor: "pointer", letterSpacing: "0.02em",
          boxShadow: "0 4px 20px rgba(124,58,237,0.35)",
          transition: "all 0.18s ease",
        }}
        className="hover:shadow-[0_6px_28px_rgba(124,58,237,0.55)] hover:-translate-y-0.5"
      >
        <Plus size={18} strokeWidth={2.5} />
        {isAuthed ? "Create Discussion" : "Sign In to Discuss"}
      </button>

      {topUsers.length > 0 && (
        <div style={{
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.07)",
          borderRadius: 16, padding: "20px",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 18 }}>
            <Trophy size={15} style={{ color: "#f59e0b" }} />
            <h3 style={{ fontSize: 13, fontWeight: 800, color: "#fff", letterSpacing: "0.03em", textTransform: "uppercase" }}>
              Top Contributors
            </h3>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {topUsers.map((u, i) => (
              <div
                key={u.id}
                style={{
                  display: "flex", alignItems: "center", gap: 12,
                  padding: "10px 12px", borderRadius: 11,
                  background: i === 0 ? "rgba(245,158,11,0.08)" : "transparent",
                  border: i === 0 ? "1px solid rgba(245,158,11,0.2)" : "1px solid transparent",
                  transition: "all 0.15s ease",
                }}
                className="hover:bg-white/5"
              >
                <div style={{
                  width: 28, height: 28, borderRadius: "50%",
                  background: i === 0
                    ? "linear-gradient(135deg,#f59e0b,#d97706)"
                    : i === 1 ? "linear-gradient(135deg,#94a3b8,#64748b)"
                      : i === 2 ? "linear-gradient(135deg,#b45309,#92400e)"
                        : "rgba(255,255,255,0.08)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: i < 3 ? 13 : 11, fontWeight: 800,
                  color: i < 3 ? "#fff" : "rgba(255,255,255,0.5)",
                  flexShrink: 0,
                }}>
                  {i < 3 ? rankLabels[i] : `${i + 1}`}
                </div>
                <Avatar user={u} size={34} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
                    <p style={{
                      fontSize: 12, fontWeight: 700,
                      color: i === 0 ? "#fbbf24" : "#e2d9f3",
                      overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                    }}>
                      @{u.username}
                    </p>
                    <span style={{
                      fontSize: 9, fontWeight: 800, color: "#fff",
                      background: i === 0 ? "linear-gradient(135deg, #f59e0b, #d97706)" : "rgba(124,58,237,0.8)",
                      padding: "2px 5px", borderRadius: 4, letterSpacing: "0.05em", lineHeight: 1
                    }}>
                      LVL {u.level}
                    </span>
                  </div>
                  <p style={{ fontSize: 10, color: "rgba(255,255,255,0.3)" }}>
                    {u._count.discussions} {u._count.discussions === 1 ? "post" : "posts"}
                  </p>
                </div>
                {i === 0 && <span style={{ fontSize: 16 }}>👑</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{
        background: "rgba(124,58,237,0.07)",
        border: "1px solid rgba(124,58,237,0.18)",
        borderRadius: 16, padding: "18px 20px",
      }}>
        <h4 style={{ fontSize: 12, fontWeight: 800, color: "#a78bfa", marginBottom: 10, letterSpacing: "0.05em", textTransform: "uppercase" }}>
          Community Guidelines
        </h4>
        {[
          "Be respectful to other members",
          "No spoilers without warning",
          "Keep discussions on topic",
          "No spam or self-promotion",
        ].map((tip) => (
          <p key={tip} style={{ fontSize: 12, color: "rgba(255,255,255,0.38)", lineHeight: 1.6, marginBottom: 4 }}>
            · {tip}
          </p>
        ))}
      </div>
    </aside>
  );
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function Skeleton({ h, w = "100%", style }: { h: number; w?: string | number; style?: React.CSSProperties }) {
  return (
    <div style={{ height: h, width: w, borderRadius: 8, background: "rgba(255,255,255,0.05)", ...style }} />
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function DiscussionsPage() {
  const { user, loading: authLoading } = useAuth();

  const [discussions, setDiscussions] = useState<DiscussionItem[]>([]);
  const [topUsers, setTopUsers] = useState<TopUser[]>([]);
  const [fetching, setFetching] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    setFetching(true);
    setFetchError(null);
    try {
      const res = await fetch("/api/discussions?limit=50");
      const data = await res.json();
      if (!res.ok) { setFetchError(data.error ?? "Failed to load discussions."); return; }
      setDiscussions(data.discussions);
      setTopUsers(data.topUsers);
    } catch {
      setFetchError("Could not reach the server. Please try again.");
    } finally {
      setFetching(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleLike(id: string) {
    if (!user) { window.location.href = "/signin?redirect=/discussions"; return; }
    const res = await fetch(`/api/discussions/${id}/like`, { method: "POST" });
    if (!res.ok) return;
    const data = await res.json();
    setDiscussions((prev) =>
      prev.map((d) => d.id === id ? { ...d, likeCount: data.likeCount, likedByMe: data.liked } : d)
    );
  }

  async function handleDelete() {
    if (!deleteId) return;
    setDeleting(true);
    try {
      await fetch(`/api/discussions/${deleteId}`, { method: "DELETE" });
      setDiscussions((prev) => prev.filter((d) => d.id !== deleteId));
    } finally {
      setDeleting(false);
      setDeleteId(null);
    }
  }

  function handleCreateClick() {
    if (!user) { window.location.href = "/signin?redirect=/discussions"; return; }
    setShowCreate(true);
  }

  return (
    <>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>

      <div style={{ backgroundColor: "#0f0f14", minHeight: "100vh", color: "#fff" }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "40px 20px 80px" }}>

          {/* Page header */}
          <div style={{ marginBottom: 36 }}>
            <h1 style={{ fontSize: 28, fontWeight: 900, color: "#fff", letterSpacing: "-0.03em", marginBottom: 6 }}>
              Community{" "}
              <span style={{
                background: "linear-gradient(135deg,#c4b5fd 0%,#7c3aed 100%)",
                WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
              }}>
                Discussions
              </span>
            </h1>
            <p style={{ fontSize: 14, color: "rgba(255,255,255,0.38)" }}>
              Join the conversation · {discussions.length} {discussions.length === 1 ? "post" : "posts"}
            </p>
          </div>

          {/* Two-column layout */}
          <div
            style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 28, alignItems: "start" }}
            className="discussions-grid"
          >
            {/* LEFT: Posts */}
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {fetchError ? (
                <div style={{
                  padding: "32px 24px", borderRadius: 16,
                  background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.2)",
                  display: "flex", alignItems: "flex-start", gap: 14,
                }}>
                  <AlertTriangle size={20} style={{ color: "#ef4444", flexShrink: 0, marginTop: 1 }} />
                  <div>
                    <p style={{ fontSize: 14, fontWeight: 700, color: "#fca5a5", marginBottom: 6 }}>
                      Failed to load discussions
                    </p>
                    <p style={{ fontSize: 13, color: "rgba(255,255,255,0.45)", lineHeight: 1.6, marginBottom: 14 }}>
                      {fetchError}
                    </p>
                    <button
                      onClick={load}
                      style={{
                        padding: "7px 16px", borderRadius: 8,
                        background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)",
                        color: "#fca5a5", fontSize: 12, fontWeight: 700, cursor: "pointer",
                      }}
                    >
                      Try Again
                    </button>
                  </div>
                </div>
              ) : fetching || authLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 16, padding: "22px 24px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
                      <Skeleton h={40} w={40} style={{ borderRadius: "50%" }} />
                      <div style={{ flex: 1 }}>
                        <Skeleton h={11} w={120} style={{ marginBottom: 6 }} />
                        <Skeleton h={9} w={80} />
                      </div>
                    </div>
                    <Skeleton h={18} style={{ marginBottom: 10 }} />
                    <Skeleton h={13} style={{ marginBottom: 6 }} />
                    <Skeleton h={13} w="70%" />
                  </div>
                ))
              ) : discussions.length === 0 ? (
                <div style={{ padding: "64px 24px", textAlign: "center", borderRadius: 16, border: "1px dashed rgba(255,255,255,0.08)" }}>
                  <MessageSquare size={40} style={{ color: "rgba(124,58,237,0.4)", marginBottom: 14 }} />
                  <p style={{ fontSize: 16, fontWeight: 700, color: "rgba(255,255,255,0.4)", marginBottom: 6 }}>
                    No discussions yet
                  </p>
                  <p style={{ fontSize: 13, color: "rgba(255,255,255,0.22)", marginBottom: 20 }}>
                    Be the first to start a conversation!
                  </p>
                  <button
                    onClick={handleCreateClick}
                    style={{
                      display: "inline-flex", alignItems: "center", gap: 8,
                      padding: "10px 22px", borderRadius: 10,
                      background: "linear-gradient(135deg,#7c3aed,#5b21b6)",
                      border: "none", color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer",
                    }}
                  >
                    <Plus size={15} />
                    Start Discussion
                  </button>
                </div>
              ) : (
                discussions.map((item) => (
                  <DiscussionCard
                    key={item.id}
                    item={item}
                    user={user}
                    onLike={handleLike}
                    onDelete={(id) => setDeleteId(id)}
                  />
                ))
              )}
            </div>

            {/* RIGHT: Sidebar */}
            {!fetching && (
              <Sidebar
                topUsers={topUsers}
                onCreateClick={handleCreateClick}
                isAuthed={!!user}
              />
            )}
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .discussions-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>

      {showCreate && (
        <CreateModal
          onClose={() => setShowCreate(false)}
          onCreated={(item) => setDiscussions((prev) => [item, ...prev])}
        />
      )}
      {deleteId && (
        <DeleteModal
          onConfirm={handleDelete}
          onCancel={() => setDeleteId(null)}
          loading={deleting}
        />
      )}
    </>
  );
}

// ─── Shared styles ────────────────────────────────────────────────────────────

const modalInputStyle: React.CSSProperties = {
  padding: "11px 14px", borderRadius: 10,
  background: "rgba(255,255,255,0.05)",
  border: "1px solid rgba(255,255,255,0.1)",
  color: "#fff", fontSize: 14, outline: "none",
  width: "100%", boxSizing: "border-box",
};

const cancelBtnStyle: React.CSSProperties = {
  padding: "9px 20px", borderRadius: 9,
  background: "transparent", border: "1px solid rgba(255,255,255,0.12)",
  color: "rgba(255,255,255,0.6)", fontSize: 13, fontWeight: 600, cursor: "pointer",
};
