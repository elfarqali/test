import Link from "next/link";
import { ArrowLeft, Calendar } from "lucide-react";
import { notFound } from "next/navigation";
import { fetchMatches, type APIMatch } from "../page";
import { StreamSelector } from "./stream-selector";

// Revalidate every 5 minutes — reduces ISR writes by 80% vs 60s
export const revalidate = 300;

interface APIStream {
    id: string;
    streamNo: number;
    language: string;
    hd: boolean;
    embedUrl: string;
    source: string;
}

async function findMatch(id: string): Promise<APIMatch | null> {
    const matches = await fetchMatches();
    return matches.find(m => m.id === id) || null;
}

async function fetchMatchStreams(match: APIMatch): Promise<APIStream[]> {
    let allStreams: APIStream[] = [];
    for (const src of match.sources || []) {
        try {
            const res = await fetch(`https://streamed.pk/api/stream/${src.source}/${src.id}`, {
                next: { revalidate: 60 },
            });
            if (res.ok) {
                const data = await res.json() as APIStream[];
                allStreams = allStreams.concat(data || []);
            }
        } catch { }
    }
    return allStreams;
}

function isLiveNow(m: APIMatch): boolean {
    const now = Date.now();
    return m.date > 0 && m.date <= now && (now - m.date) < 3 * 3600 * 1000;
}

function formatDateTime(tsMs: number) {
    if (!tsMs) return null;
    return new Date(tsMs).toLocaleString(undefined, {
        weekday: "short", month: "short", day: "numeric",
        hour: "2-digit", minute: "2-digit",
    });
}

export default async function LivePlayerPage({
    params,
    searchParams
}: {
    params: Promise<{ id: string }>,
    searchParams?: Promise<{ stream?: string }>
}) {
    const { id } = await params;
    const { stream: streamIdParam } = (await searchParams) || {};

    const match = await findMatch(id);
    if (!match) notFound();

    const streams = await fetchMatchStreams(match);

    let activeStream = streams[0];
    if (streamIdParam) {
        const found = streams.find(s => `${s.source}-${s.streamNo}` === streamIdParam);
        if (found) activeStream = found;
    }

    const live = isLiveNow(match);

    return (
        <div style={{ backgroundColor: "#0b0f1a", minHeight: "100vh" }}>
            <div className="max-w-[1400px] mx-auto px-4 py-6">
                {/* Back link */}
                <Link
                    href="/live"
                    style={{
                        display: "inline-flex", alignItems: "center", gap: 7,
                        color: "rgba(255,255,255,0.4)", fontSize: 12, fontWeight: 600,
                        textDecoration: "none", marginBottom: 20,
                        transition: "color 0.15s ease",
                    }}
                    className="hover:text-white/80"
                >
                    <ArrowLeft size={14} />
                    Back to Live
                </Link>

                {/* Title row */}
                <div style={{ marginBottom: 16, display: "flex", flexWrap: "wrap", alignItems: "flex-start", gap: 12 }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6, flexWrap: "wrap" }}>
                            {live ? (
                                <span style={{
                                    display: "inline-flex", alignItems: "center", gap: 4,
                                    padding: "3px 9px", borderRadius: 20,
                                    background: "rgba(239,68,68,0.9)", color: "#fff",
                                    fontSize: 9, fontWeight: 800, letterSpacing: "0.08em",
                                    boxShadow: "0 0 12px rgba(239,68,68,0.5)",
                                }}>
                                    <span style={{ width: 5, height: 5, borderRadius: "50%", background: "#fff" }} />
                                    LIVE
                                </span>
                            ) : (
                                <span style={{
                                    padding: "3px 9px", borderRadius: 20,
                                    background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.45)",
                                    fontSize: 9, fontWeight: 700,
                                }}>UPCOMING</span>
                            )}
                            <span style={{
                                padding: "2px 8px", borderRadius: 5,
                                background: "rgba(124,58,237,0.15)", border: "1px solid rgba(124,58,237,0.3)",
                                color: "#a78bfa", fontSize: 10, fontWeight: 700,
                            }}>
                                {match.category}
                            </span>
                        </div>

                        <h1 style={{
                            fontSize: 20, fontWeight: 800, color: "#fff",
                            letterSpacing: "-0.025em", lineHeight: 1.3,
                        }}>
                            {match.title}
                        </h1>

                        <div style={{ display: "flex", gap: 14, marginTop: 8, flexWrap: "wrap" }}>
                            {match.date > 0 && (
                                <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: "rgba(255,255,255,0.35)" }}>
                                    <Calendar size={11} />
                                    {formatDateTime(match.date)}
                                </span>
                            )}
                        </div>
                    </div>
                </div>

                {/* Player */}
                {activeStream ? (
                    <div style={{
                        position: "relative",
                        paddingBottom: "56.25%", /* 16:9 */
                        height: 0,
                        borderRadius: 16,
                        overflow: "hidden",
                        background: "#000",
                        border: "1px solid rgba(255,255,255,0.08)",
                        boxShadow: "0 24px 64px rgba(0,0,0,0.8)",
                    }}>
                        <iframe
                            src={activeStream.embedUrl}
                            style={{
                                position: "absolute",
                                top: 0, left: 0,
                                width: "100%", height: "100%",
                                border: "none",
                            }}
                            allowFullScreen
                            allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                            referrerPolicy="no-referrer-when-downgrade"
                            title={`${match.title} - Stream ${activeStream.streamNo}`}
                        />
                    </div>
                ) : (
                    <div style={{
                        paddingBottom: "56.25%", height: 0, position: "relative",
                        borderRadius: 16, background: "#111827", border: "1px solid rgba(255,255,255,0.08)"
                    }}>
                        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                            <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 13 }}>Stream will be available closer to start time.</p>
                        </div>
                    </div>
                )}

                {/* Multiple streams selection */}
                {streams.length > 1 && (
                    <StreamSelector
                        streams={streams}
                        matchId={match.id}
                        activeStreamId={activeStream ? `${activeStream.source}-${activeStream.streamNo}` : ""}
                    />
                )}

                {/* Footer note */}
                <p style={{ marginTop: 24, fontSize: 11, color: "rgba(255,255,255,0.2)", textAlign: "center" }}>
                    Stream provided by streamed.pk · Content may vary by region
                </p>
            </div>
        </div>
    );
}
