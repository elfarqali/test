"use client";

import { useState } from "react";
import Link from "next/link";
import { ChevronDown, ChevronUp, Radio, MonitorPlay } from "lucide-react";

export interface APIStream {
    id: string;
    streamNo: number;
    language: string;
    hd: boolean;
    embedUrl: string;
    source: string;
}

interface StreamSelectorProps {
    streams: APIStream[];
    matchId: string;
    activeStreamId: string;
}

export function StreamSelector({ streams, matchId, activeStreamId }: StreamSelectorProps) {
    if (!streams.length) return null;

    // Group streams by source
    const grouped = streams.reduce((acc, s) => {
        const src = s.source || "Unknown";
        if (!acc[src]) acc[src] = [];
        acc[src].push(s);
        return acc;
    }, {} as Record<string, APIStream[]>);

    // Initial open server (the one containing the active stream)
    const activeSource = streams.find(s => `${s.source}-${s.streamNo}` === activeStreamId)?.source || Object.keys(grouped)[0];

    const [openServers, setOpenServers] = useState<Record<string, boolean>>({
        [activeSource]: true
    });

    const toggleServer = (server: string) => {
        setOpenServers(prev => ({ ...prev, [server]: !prev[server] }));
    };

    return (
        <div style={{ marginTop: 24, display: "flex", flexDirection: "column", gap: 16 }}>
            <p style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.6)", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                Select Stream Server
            </p>

            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {Object.entries(grouped).map(([server, serverStreams]) => {
                    const isOpen = openServers[server];
                    const hasActive = serverStreams.some(s => `${s.source}-${s.streamNo}` === activeStreamId);

                    return (
                        <div key={server} style={{
                            background: "rgba(20, 24, 38, 0.6)",
                            border: hasActive ? "1px solid rgba(124, 58, 237, 0.4)" : "1px solid rgba(255, 255, 255, 0.05)",
                            borderRadius: 12,
                            overflow: "hidden",
                            transition: "all 0.3s ease",
                            boxShadow: hasActive ? "0 4px 20px rgba(124, 58, 237, 0.1)" : "none",
                        }}>
                            <button
                                onClick={() => toggleServer(server)}
                                style={{
                                    width: "100%", padding: "14px 18px", display: "flex", alignItems: "center", justifyContent: "space-between",
                                    background: hasActive ? "rgba(124, 58, 237, 0.05)" : "transparent",
                                    border: "none", cursor: "pointer", color: "#fff", transition: "background 0.2s"
                                }}
                                className="hover:bg-white/5"
                            >
                                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                                    <div style={{
                                        width: 32, height: 32, borderRadius: 8,
                                        background: hasActive ? "linear-gradient(135deg, #a78bfa 0%, #7c3aed 100%)" : "rgba(255, 255, 255, 0.1)",
                                        display: "flex", alignItems: "center", justifyContent: "center",
                                        boxShadow: hasActive ? "0 2px 10px rgba(124, 58, 237, 0.3)" : "none",
                                    }}>
                                        <MonitorPlay size={16} color={hasActive ? "#fff" : "rgba(255, 255, 255, 0.6)"} />
                                    </div>
                                    <div style={{ textAlign: "left" }}>
                                        <h3 style={{ fontSize: 14, fontWeight: 700, margin: 0, color: hasActive ? "#fff" : "rgba(255, 255, 255, 0.8)" }}>
                                            Server {server.charAt(0).toUpperCase() + server.slice(1)}
                                        </h3>
                                        <p style={{ fontSize: 11, color: "rgba(255, 255, 255, 0.4)", margin: 0, marginTop: 2 }}>
                                            {serverStreams.length} stream{serverStreams.length !== 1 && "s"} available
                                        </p>
                                    </div>
                                </div>
                                <div>
                                    {isOpen ? <ChevronUp size={18} color="rgba(255, 255, 255, 0.4)" /> : <ChevronDown size={18} color="rgba(255, 255, 255, 0.4)" />}
                                </div>
                            </button>

                            {isOpen && (
                                <div style={{ padding: "0 14px 14px 14px", display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 10 }}>
                                    {serverStreams.map(s => {
                                        const streamKey = `${s.source}-${s.streamNo}`;
                                        const isActive = streamKey === activeStreamId;
                                        return (
                                            <Link
                                                key={streamKey}
                                                href={`/live/${matchId}?stream=${streamKey}`}
                                                className="group"
                                                style={{ textDecoration: "none" }}
                                            >
                                                <div style={{
                                                    padding: "12px 16px", borderRadius: 10,
                                                    background: isActive ? "linear-gradient(90deg, rgba(124, 58, 237, 0.15), rgba(124, 58, 237, 0.05))" : "rgba(255, 255, 255, 0.03)",
                                                    border: isActive ? "1px solid rgba(124, 58, 237, 0.5)" : "1px solid rgba(255, 255, 255, 0.05)",
                                                    display: "flex", alignItems: "center", justifyContent: "space-between",
                                                    transition: "all 0.2s ease"
                                                }}
                                                    className="group-hover:bg-white/5 group-hover:border-white/20"
                                                >
                                                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                                                        <div style={{
                                                            position: "relative", display: "flex", alignItems: "center", justifyContent: "center",
                                                            width: 24, height: 24, borderRadius: "50%",
                                                            background: isActive ? "rgba(239, 68, 68, 0.2)" : "rgba(255, 255, 255, 0.05)"
                                                        }}>
                                                            {isActive ? (
                                                                <>
                                                                    <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#ef4444", zIndex: 2 }} />
                                                                    <div style={{ position: "absolute", inset: 0, borderRadius: "50%", border: "2px solid #ef4444", animation: "ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite", opacity: 0.7 }} />
                                                                </>
                                                            ) : (
                                                                <Radio size={12} color="rgba(255, 255, 255, 0.4)" />
                                                            )}
                                                        </div>
                                                        <div>
                                                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                                                <span style={{ fontSize: 13, fontWeight: 700, color: isActive ? "#fff" : "rgba(255, 255, 255, 0.8)", transition: "color 0.2s" }} className="group-hover:text-white">
                                                                    Stream {s.streamNo}
                                                                </span>
                                                                <span style={{
                                                                    fontSize: 9, fontWeight: 800, padding: "2px 6px", borderRadius: 4,
                                                                    background: s.hd ? "rgba(34, 197, 94, 0.15)" : "rgba(249, 115, 22, 0.15)",
                                                                    color: s.hd ? "#4ade80" : "#fb923c", letterSpacing: "0.05em"
                                                                }}>
                                                                    {s.hd ? "HD" : "SD"}
                                                                </span>
                                                            </div>
                                                            <div style={{ fontSize: 11, color: "rgba(255, 255, 255, 0.4)", marginTop: 2 }}>
                                                                Language: {s.language || "Unknown"}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </Link>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
}
