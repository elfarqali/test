"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { Radio } from "lucide-react";
import type { APIMatch } from "./page";

const CATEGORY_COLORS: Record<string, string> = {
    Football: "#22c55e",
    Basketball: "#f97316",
    Baseball: "#3b82f6",
    Cricket: "#84cc16",
    Darts: "#a855f7",
    Wrestling: "#ef4444",
    Fight: "#ef4444",
    "24/7 Streams": "#06b6d4",
};

function categoryColor(cat: string) {
    return CATEGORY_COLORS[cat] ?? "#7c3aed";
}

function isLiveNow(m: APIMatch, now: number): boolean {
    return m.date > 0 && m.date <= now && (now - m.date) < 3 * 3600 * 1000;
}

function formatTime(tsMs: number): string {
    if (!tsMs) return "";
    const d = new Date(tsMs);
    return d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

function LiveBadge({ match, now }: { match: APIMatch; now: number }) {
    const live = isLiveNow(match, now);
    if (live) {
        return (
            <span style={{
                display: "inline-flex", alignItems: "center", gap: 4,
                padding: "2px 7px", borderRadius: 20,
                background: "rgba(239,68,68,0.92)",
                color: "#fff", fontSize: 9, fontWeight: 800,
                letterSpacing: "0.08em", textTransform: "uppercase",
                boxShadow: "0 0 10px rgba(239,68,68,0.5)",
            }}>
                <span style={{ width: 4, height: 4, borderRadius: "50%", background: "#fff", flexShrink: 0 }} />
                LIVE
            </span>
        );
    }
    return (
        <span style={{
            padding: "2px 7px", borderRadius: 20,
            background: "rgba(255,255,255,0.12)",
            color: "rgba(255,255,255,0.5)", fontSize: 9, fontWeight: 700,
            letterSpacing: "0.06em", textTransform: "uppercase",
        }}>
            UPCOMING
        </span>
    );
}

function StreamCard({ match, now }: { match: APIMatch; now: number }) {
    const [imgError, setImgError] = useState(false);
    const accColor = categoryColor(match.category);

    let posterSrc = "";
    if (match.poster) {
        if (match.poster.startsWith("http")) {
            posterSrc = match.poster;
        } else if (match.poster.startsWith("/")) {
            posterSrc = `https://streamed.pk${match.poster}`;
        } else {
            posterSrc = `https://streamed.pk/api/images/proxy/${match.poster}.webp`;
        }
    } else if (match.teams?.home?.badge && match.teams?.away?.badge) {
        let h = String(match.teams.home.badge).split("/").pop()?.replace(".webp", "") || "";
        let a = String(match.teams.away.badge).split("/").pop()?.replace(".webp", "") || "";
        if (h && a) {
            posterSrc = `https://streamed.pk/api/images/poster/${h}/${a}.webp`;
        }
    }

    return (
        <Link
            href={`/live/${match.id}`}
            style={{ textDecoration: "none", display: "block", height: "100%" }}
            className="group"
            draggable={false}
        >
            <div style={{
                borderRadius: 14,
                overflow: "hidden",
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.07)",
                transition: "all 0.22s ease",
                cursor: "pointer",
                height: "100%",
                display: "flex",
                flexDirection: "column",
            }}
                className="group-hover:border-[rgba(124,58,237,0.4)] group-hover:shadow-[0_8px_32px_rgba(124,58,237,0.18)] group-hover:-translate-y-1"
            >
                <div style={{ position: "relative", aspectRatio: "16/9", background: "#0d1120", overflow: "hidden", flexShrink: 0 }}>
                    {posterSrc && !imgError ? (
                        <Image
                            src={posterSrc}
                            alt={match.title}
                            fill
                            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                            style={{ objectFit: "cover", transition: "transform 0.3s ease" }}
                            className="group-hover:scale-105"
                            onError={() => setImgError(true)}
                            unoptimized
                            draggable={false}
                        />
                    ) : (
                        <div style={{
                            width: "100%", height: "100%",
                            display: "flex", alignItems: "center", justifyContent: "center",
                            background: `linear-gradient(135deg, #1a1a2e 0%, #0d1120 100%)`,
                        }}>
                            <Radio size={28} style={{ color: "rgba(255,255,255,0.2)" }} />
                        </div>
                    )}

                    <div style={{
                        position: "absolute", inset: 0,
                        background: "linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 50%)",
                    }} />

                    <div style={{ position: "absolute", top: 8, left: 8 }}>
                        <LiveBadge match={match} now={now} />
                    </div>

                    <div style={{ position: "absolute", bottom: 8, left: 8 }}>
                        <span style={{
                            padding: "2px 7px", borderRadius: 5,
                            background: "rgba(0,0,0,0.72)", backdropFilter: "blur(4px)",
                            color: "rgba(255,255,255,0.6)", fontSize: 9, fontWeight: 700,
                            letterSpacing: "0.04em",
                        }}>
                            {match.category}
                        </span>
                    </div>
                </div>

                <div style={{ padding: "12px 14px 14px", flex: 1, display: "flex", flexDirection: "column" }}>
                    <p style={{
                        fontSize: 12, fontWeight: 700, color: "#e2d9f3",
                        lineHeight: 1.4, marginBottom: 6,
                        overflow: "hidden", display: "-webkit-box",
                        WebkitLineClamp: 2, WebkitBoxOrient: "vertical",
                        flex: 1,
                    }}>
                        {match.title}
                    </p>

                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, marginTop: "auto" }}>
                        <span style={{
                            padding: "2px 8px", borderRadius: 5,
                            background: `${accColor}18`,
                            border: `1px solid ${accColor}35`,
                            color: accColor, fontSize: 9, fontWeight: 700,
                            letterSpacing: "0.06em", textTransform: "uppercase",
                        }}>
                            {match.category}
                        </span>

                        {match.date > 0 && !isLiveNow(match, now) && (
                            <span style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", whiteSpace: "nowrap" }}>
                                {formatTime(match.date)}
                            </span>
                        )}
                    </div>
                </div>
            </div>
        </Link>
    );
}

function CategoryRow({ title, matches, now }: { title: string; matches: APIMatch[]; now: number }) {
    const scrollRef = useRef<HTMLDivElement>(null);
    const [hovering, setHovering] = useState(false);

    const scroll = useCallback((dir: "left" | "right") => {
        const el = scrollRef.current;
        if (!el) return;
        const amount = el.clientWidth * 0.75;
        el.scrollBy({ left: dir === "right" ? amount : -amount, behavior: "smooth" });
    }, []);

    if (!matches.length) return null;

    const btnStyle: React.CSSProperties = {
        position: "absolute",
        top: "50%",
        transform: "translateY(-50%)",
        zIndex: 10,
        width: 38,
        height: 38,
        borderRadius: "50%",
        border: "1px solid rgba(255,255,255,0.15)",
        backgroundColor: "rgba(10,10,10,0.9)",
        color: "#fff",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        transition: "opacity 0.25s, background-color 0.2s, transform 0.2s",
        opacity: hovering ? 1 : 0,
        pointerEvents: hovering ? "auto" : "none",
        padding: 0,
        boxShadow: "0 2px 12px rgba(0,0,0,0.5)",
    };

    return (
        <section
            style={{ marginBottom: 44, position: "relative" }}
            onMouseEnter={() => setHovering(true)}
            onMouseLeave={() => setHovering(false)}
        >
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
                <span style={{
                    display: "inline-block", width: 4, height: 18, borderRadius: 2,
                    background: "linear-gradient(180deg, #ef4444 0%, #b91c1c 100%)",
                    flexShrink: 0, boxShadow: "0 0 8px rgba(239,68,68,0.45)",
                }} />
                <h2 style={{ color: "#ffffff", fontSize: 18, fontWeight: 700, margin: 0, padding: 0, letterSpacing: "-0.01-em" }}>
                    Live {title}
                </h2>
            </div>

            <button onClick={() => scroll("left")} aria-label="Scroll left" style={{ ...btnStyle, left: -19 }}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="15 18 9 12 15 6" />
                </svg>
            </button>

            <button onClick={() => scroll("right")} aria-label="Scroll right" style={{ ...btnStyle, right: -19 }}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="9 18 15 12 9 6" />
                </svg>
            </button>

            <div
                ref={scrollRef}
                className="scroll-row"
                style={{
                    display: "flex", flexDirection: "row", flexWrap: "nowrap", gap: 14,
                    overflowX: "auto", overflowY: "visible", paddingBottom: 16,
                    scrollbarWidth: "none", msOverflowStyle: "none", WebkitOverflowScrolling: "touch",
                }}
            >
                {matches.map((m) => (
                    <div key={m.id} style={{ flexShrink: 0, width: 280 }}>
                        <StreamCard match={m} now={now} />
                    </div>
                ))}
            </div>
        </section>
    );
}

const CATEGORY_ORDER = [
    "Football",
    "Basketball",
    "Cricket",
    "Fight",
    "Hockey",
    "Motor-sports"
];

function getCategoryPriority(cat: string) {
    const idx = CATEGORY_ORDER.indexOf(cat);
    return idx === -1 ? 999 : idx;
}

export function LiveGrid({ matches }: { matches: APIMatch[] }) {
    const [now, setNow] = useState<number>(Date.now());

    // Auto-refresh badges every 60s
    useEffect(() => {
        setNow(Date.now());
        const id = setInterval(() => setNow(Date.now()), 60_000);
        return () => clearInterval(id);
    }, []);

    // Format categories to ensure capitalization matches our priority sorting map (e.g. "football" -> "Football")
    const formattedMatches = matches.map((m) => {
        if (!m.category) return m;
        return { ...m, category: m.category.charAt(0).toUpperCase() + m.category.slice(1) };
    });

    // Extract unique categories
    const categoriesSet = new Set<string>();
    formattedMatches.forEach((m) => {
        categoriesSet.add(m.category);
    });

    // Sort categories based on forced priority, then alphabetically
    const categories = Array.from(categoriesSet).sort((a, b) => {
        const pA = getCategoryPriority(a);
        const pB = getCategoryPriority(b);
        if (pA !== pB) return pA - pB;
        return a.localeCompare(b);
    });

    // Ensure "All" is selected by default on page load
    const [activeFilter, setActiveFilter] = useState("All");

    // Group items by category and sort them (live first, then by date)
    const getStatus = useCallback((m: APIMatch, n: number) => {
        return isLiveNow(m, n) ? 0 : 1;
    }, []);

    const groupedMatches = categories.reduce((acc, cat) => {
        acc[cat] = formattedMatches
            .filter((m) => m.category === cat)
            .sort((a, b) => getStatus(a, now) - getStatus(b, now) || a.date - b.date);
        return acc;
    }, {} as Record<string, APIMatch[]>);

    const handleFilterClick = (cat: string) => {
        setActiveFilter(cat);
        // Find the top of the container and scroll to it
        document.getElementById("live-grid-top")?.scrollIntoView({ behavior: "smooth", block: "start" });
    };

    const visibleCategories = activeFilter === "All" ? categories : categories.filter(c => c === activeFilter);

    return (
        <div id="live-grid-top">
            {categories.length === 0 ? (
                <div className="flex flex-col items-center py-20 gap-2 text-center">
                    <p className="text-sm text-white/30">No matches available right now.</p>
                </div>
            ) : (
                <div style={{ display: "flex", flexDirection: "column" }}>
                    {/* Modern Filter Strip */}
                    <div style={{
                        display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 32,
                        paddingBottom: 8, overflowX: "auto", scrollbarWidth: "none", msOverflowStyle: "none"
                    }} className="scroll-row">
                        {["All", ...categories].map((cat) => {
                            const isActive = activeFilter === cat;
                            const accColor = cat === "All" ? "#7c3aed" : categoryColor(cat);
                            return (
                                <button
                                    key={cat}
                                    onClick={() => handleFilterClick(cat)}
                                    style={{
                                        padding: "8px 20px",
                                        borderRadius: 24,
                                        background: isActive ? `linear-gradient(135deg, ${accColor} 0%, ${accColor}dd 100%)` : "rgba(255,255,255,0.05)",
                                        border: isActive ? `1px solid ${accColor}aa` : "1px solid rgba(255,255,255,0.1)",
                                        color: isActive ? "#fff" : "rgba(255,255,255,0.6)",
                                        fontSize: 13,
                                        fontWeight: isActive ? 700 : 500,
                                        cursor: "pointer",
                                        transition: "all 0.25s ease",
                                        boxShadow: isActive ? `0 4px 16px ${accColor}40` : "none",
                                        whiteSpace: "nowrap",
                                        flexShrink: 0
                                    }}
                                    className="hover:bg-white/10 hover:text-white"
                                >
                                    {cat}
                                </button>
                            );
                        })}
                    </div>

                    {/* Rendering the netflix style rows, one for each visible category */}
                    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                        {visibleCategories.map((cat) => (
                            <CategoryRow key={cat} title={cat} matches={groupedMatches[cat] || []} now={now} />
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}
