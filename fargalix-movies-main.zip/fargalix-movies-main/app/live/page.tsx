import { Suspense } from "react";
import { LiveGrid } from "./live-grid";

export const metadata = {
    title: "Live Streams",
    description: "Watch live sports, shows and 24/7 streams.",
};

// Revalidate every 5 minutes — reduces ISR writes while staying reasonably fresh
export const revalidate = 300;

export interface APIMatch {
    id: string;
    title: string;
    category: string;
    date: number; // ms
    poster?: string;
    popular: boolean;
    teams?: {
        home?: { name: string; badge: string };
        away?: { name: string; badge: string };
    };
    sources: { source: string; id: string }[];
}

export async function fetchMatches(): Promise<APIMatch[]> {
    try {
        const res = await fetch("https://streamed.pk/api/matches/all", {
            next: { revalidate: 60 },
            headers: { "Accept": "application/json" },
        });
        if (!res.ok) return [];
        return await res.json() as APIMatch[];
    } catch {
        return [];
    }
}

export default async function LivePage() {
    const matches = await fetchMatches();

    return (
        <div style={{ backgroundColor: "#0b0f1a", minHeight: "100vh" }}>
            <div className="max-w-[1400px] mx-auto px-4 py-6">
                {/* Header */}
                <div className="mb-6 flex items-center gap-3 flex-wrap">
                    <span className="inline-block w-0.5 h-4 rounded-full" style={{ backgroundColor: "#ef4444" }} />
                    <h1 className="text-sm font-semibold text-white">Live Streams</h1>
                    <span className="text-[11px] text-white/40">— {matches.length} matches available</span>
                    <div className="flex-1" />
                    {/* Auto-refresh badge */}
                    <span style={{
                        display: "inline-flex", alignItems: "center", gap: 5,
                        padding: "3px 10px", borderRadius: 20,
                        border: "1px solid rgba(239,68,68,0.25)",
                        background: "rgba(239,68,68,0.08)",
                        color: "rgba(239,68,68,0.7)", fontSize: 10, fontWeight: 700,
                        letterSpacing: "0.06em", textTransform: "uppercase",
                    }}>
                        <span style={{
                            width: 5, height: 5, borderRadius: "50%",
                            background: "#ef4444",
                            boxShadow: "0 0 6px #ef4444",
                            display: "inline-block",
                            animation: "pulse 2s infinite",
                        }} />
                        LIVE
                    </span>
                </div>

                {matches.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-32 text-center gap-3">
                        <div style={{ fontSize: 42, opacity: 0.2 }}>📡</div>
                        <p className="text-sm text-white/30">Live streams unavailable right now.</p>
                        <p className="text-xs text-white/20">Try refreshing in a moment.</p>
                    </div>
                ) : (
                    <Suspense>
                        <LiveGrid matches={matches} />
                    </Suspense>
                )}
            </div>
        </div>
    );
}
