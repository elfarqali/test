import { Suspense } from "react";
import { getPopularMovies, type TMDBMediaItem } from "@/lib/tmdb";
import { MediaCard } from "@/components/media-card";
import { PaginationControls } from "@/components/pagination-controls";
import { SortDropdown, type SortOption } from "@/components/sort-dropdown";

interface MoviesPageProps {
  searchParams: Promise<{ page?: string; sort?: string }>;
}

export const metadata = {
  title: "Movies",
  description: "Browse the most popular movies right now.",
};

// ISR — each ?page=N variant is generated once, then cached for 24h
export const revalidate = 86400;

function sortItems(items: TMDBMediaItem[], sort: SortOption): TMDBMediaItem[] {
  return [...items].sort((a, b) => {
    switch (sort) {
      case "newest": {
        const da = a.release_date ?? "";
        const db = b.release_date ?? "";
        return db.localeCompare(da);
      }
      case "oldest": {
        const da = a.release_date ?? "";
        const db = b.release_date ?? "";
        return da.localeCompare(db);
      }
      case "score_desc":
        return (b.vote_average ?? 0) - (a.vote_average ?? 0);
      case "score_asc":
        return (a.vote_average ?? 0) - (b.vote_average ?? 0);
      default:
        return 0;
    }
  });
}

export default async function MoviesPage({ searchParams }: MoviesPageProps) {
  const params = await searchParams;
  const page = Math.max(1, parseInt(params.page ?? "1", 10) || 1);
  const sort = (params.sort ?? "newest") as SortOption;

  // Fetch 3 TMDB pages instead of 7 — each returns 20 items (~60 per page)
  const startPage = (page - 1) * 3 + 1;
  const pageNums = Array.from({ length: 3 }, (_, i) => startPage + i);
  const responses = await Promise.all(pageNums.map((p) => getPopularMovies(p)));

  const seen = new Set<number>();
  const raw: TMDBMediaItem[] = [];
  for (const res of responses) {
    for (const item of res.results) {
      if (!seen.has(item.id)) { seen.add(item.id); raw.push(item); }
    }
  }

  const allItems = sortItems(raw, sort);
  const totalPages = Math.ceil(responses[0].total_pages / 3);
  const hasResults = allItems.length > 0;

  return (
    <div style={{ backgroundColor: "#0b0f1a", minHeight: "100vh" }}>
      <div className="max-w-[1400px] mx-auto px-4 py-6">
        {/* Header row */}
        <div className="mb-5 flex items-center gap-3 flex-wrap">
          <span className="inline-block w-0.5 h-4 rounded-full" style={{ backgroundColor: "#7c3aed" }} />
          <h1 className="text-sm font-semibold text-white">Popular Movies</h1>
          <span className="text-[11px] text-white/40">— {allItems.length} titles</span>
          <div className="flex-1" />
          <Suspense>
            <SortDropdown defaultSort="newest" />
          </Suspense>
        </div>

        {hasResults ? (
          <>
            <div className="grid gap-x-3 gap-y-5" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(105px, 1fr))" }}>
              {allItems.map((item) => (
                <MediaCard key={item.id} item={item} width={"100%"} />
              ))}
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={`ph-${i}`} aria-hidden="true" style={{ visibility: "hidden", minWidth: 105 }} />
              ))}
            </div>
            <Suspense fallback={<div className="h-16" />}>
              <PaginationControls currentPage={page} totalPages={totalPages} />
            </Suspense>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <p className="text-sm text-white/30">No results found</p>
            <p className="mt-1 text-xs text-white/20">Check your TMDB API key in .env.local</p>
          </div>
        )}
      </div>
    </div>
  );
}
