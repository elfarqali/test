"use client";

import { useState, useRef, useEffect } from "react";
import Image from "next/image";
import { useAuth } from "@/components/auth/auth-provider";
import { useRouter } from "next/navigation";
import { Camera, Lock, CheckCircle, AlertCircle, Eye, EyeOff } from "lucide-react";

const BG = "#0b0f1a";
const CARD = "rgba(255,255,255,0.035)";
const BORDER = "rgba(124,58,237,0.22)";
const ACCENT = "#7c3aed";

export default function SettingsPage() {
  const { user, loading, refetch } = useAuth();
  const router = useRouter();

  // Redirect unauthenticated handled by middleware, but guard here too
  useEffect(() => {
    if (!loading && !user) router.replace("/signin?redirect=/settings");
  }, [loading, user, router]);

  // ── Avatar ──────────────────────────────────────────────────────────────
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [avatarSaving, setAvatarSaving] = useState(false);
  const [avatarMsg, setAvatarMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setAvatarPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  }

  async function saveAvatar() {
    if (!avatarPreview) return;
    setAvatarSaving(true);
    setAvatarMsg(null);
    try {
      const res = await fetch("/api/user/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatarUrl: avatarPreview }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setAvatarMsg({ type: "success", text: "Avatar updated!" });
      refetch();
      setAvatarPreview(null);
    } catch (err: unknown) {
      setAvatarMsg({ type: "error", text: err instanceof Error ? err.message : "Failed to save avatar." });
    } finally {
      setAvatarSaving(false);
    }
  }

  async function removeAvatar() {
    setAvatarSaving(true);
    setAvatarMsg(null);
    try {
      const res = await fetch("/api/user/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatarUrl: "" }),
      });
      if (!res.ok) throw new Error("Failed to remove avatar.");
      setAvatarMsg({ type: "success", text: "Avatar removed." });
      setAvatarPreview(null);
      refetch();
    } catch (err: unknown) {
      setAvatarMsg({ type: "error", text: err instanceof Error ? err.message : "Error." });
    } finally {
      setAvatarSaving(false);
    }
  }

  // ── Password ─────────────────────────────────────────────────────────────
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [pwSaving, setPwSaving] = useState(false);
  const [pwMsg, setPwMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  async function savePassword(e: React.FormEvent) {
    e.preventDefault();
    setPwMsg(null);
    if (newPw !== confirmPw) {
      setPwMsg({ type: "error", text: "New passwords do not match." });
      return;
    }
    if (newPw.length < 8) {
      setPwMsg({ type: "error", text: "Password must be at least 8 characters." });
      return;
    }
    setPwSaving(true);
    try {
      const res = await fetch("/api/user/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword: currentPw, newPassword: newPw }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setPwMsg({ type: "success", text: "Password changed successfully!" });
      setCurrentPw(""); setNewPw(""); setConfirmPw("");
    } catch (err: unknown) {
      setPwMsg({ type: "error", text: err instanceof Error ? err.message : "Failed to change password." });
    } finally {
      setPwSaving(false);
    }
  }

  if (loading || !user) return <PageSkeleton />;

  const displayAvatar = avatarPreview ?? user.avatarUrl;
  const initials = user.username.slice(0, 2).toUpperCase();

  return (
    <div style={{ backgroundColor: BG, minHeight: "100vh", color: "#fff" }}>
      <div className="max-w-[700px] mx-auto" style={{ padding: "40px 20px 80px" }}>

        {/* Page header */}
        <div style={{ marginBottom: 36 }}>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}>
            Settings
          </h1>
          <p style={{ fontSize: 13, color: "rgba(255,255,255,0.38)", marginTop: 4 }}>
            Manage your account preferences
          </p>
        </div>

        {/* ── Avatar Card ──────────────────────────────────────────────── */}
        <Card title="Profile Picture" icon={<Camera size={16} />}>
          <div style={{ display: "flex", alignItems: "center", gap: 24, flexWrap: "wrap" }}>
            {/* Preview */}
            <div
              style={{
                width: 88,
                height: 88,
                borderRadius: "50%",
                overflow: "hidden",
                background: displayAvatar
                  ? "transparent"
                  : "linear-gradient(135deg, #7c3aed 0%, #a78bfa 100%)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 28,
                fontWeight: 900,
                color: "#fff",
                flexShrink: 0,
                border: avatarPreview
                  ? "3px solid rgba(124,58,237,0.7)"
                  : "3px solid rgba(124,58,237,0.3)",
                position: "relative",
                transition: "border-color 0.2s ease",
              }}
            >
              {displayAvatar ? (
                <Image
                  src={displayAvatar}
                  alt="Avatar preview"
                  fill
                  sizes="88px"
                  style={{ objectFit: "cover" }}
                  unoptimized
                />
              ) : (
                initials
              )}
            </div>

            <div style={{ flex: 1 }}>
              {avatarPreview && (
                <div
                  style={{
                    marginBottom: 10,
                    padding: "7px 12px",
                    borderRadius: 8,
                    background: "rgba(124,58,237,0.12)",
                    border: "1px solid rgba(124,58,237,0.3)",
                    fontSize: 12,
                    color: "#c4b5fd",
                  }}
                >
                  Preview — save to apply
                </div>
              )}

              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  style={btnOutlineStyle}
                  className="hover:bg-purple-500/10 hover:border-purple-500/50"
                >
                  Choose Image
                </button>
                {avatarPreview && (
                  <button
                    onClick={saveAvatar}
                    disabled={avatarSaving}
                    style={btnPrimaryStyle(avatarSaving)}
                  >
                    {avatarSaving ? "Saving…" : "Save Avatar"}
                  </button>
                )}
                {user.avatarUrl && !avatarPreview && (
                  <button
                    onClick={removeAvatar}
                    disabled={avatarSaving}
                    style={btnDangerStyle}
                    className="hover:bg-red-500/10"
                  >
                    Remove
                  </button>
                )}
              </div>

              <p style={{ fontSize: 11, color: "rgba(255,255,255,0.28)", marginTop: 8 }}>
                JPG, PNG or GIF · Max 5 MB recommended
              </p>
            </div>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: "none" }}
            onChange={handleFileChange}
          />

          {avatarMsg && <StatusMessage msg={avatarMsg} />}
        </Card>

        {/* ── Password Card ─────────────────────────────────────────────── */}
        <Card title="Change Password" icon={<Lock size={16} />} style={{ marginTop: 20 }}>
          <form onSubmit={savePassword} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <PasswordField
              label="Current Password"
              value={currentPw}
              onChange={setCurrentPw}
              show={showCurrent}
              onToggle={() => setShowCurrent((v) => !v)}
              placeholder="Enter current password"
            />
            <PasswordField
              label="New Password"
              value={newPw}
              onChange={setNewPw}
              show={showNew}
              onToggle={() => setShowNew((v) => !v)}
              placeholder="At least 8 characters"
            />
            <PasswordField
              label="Confirm New Password"
              value={confirmPw}
              onChange={setConfirmPw}
              show={showConfirm}
              onToggle={() => setShowConfirm((v) => !v)}
              placeholder="Repeat new password"
            />

            {/* Strength indicator */}
            {newPw.length > 0 && (
              <PasswordStrength password={newPw} />
            )}

            {pwMsg && <StatusMessage msg={pwMsg} />}

            <button
              type="submit"
              disabled={pwSaving || !currentPw || !newPw || !confirmPw}
              style={{
                ...btnPrimaryStyle(pwSaving || !currentPw || !newPw || !confirmPw),
                alignSelf: "flex-start",
                padding: "10px 24px",
              }}
            >
              {pwSaving ? "Saving…" : "Change Password"}
            </button>
          </form>
        </Card>

      </div>
    </div>
  );
}

// ── Sub-components ──────────────────────────────────────────────────────────

function Card({ title, icon, children, style }: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  style?: React.CSSProperties;
}) {
  return (
    <div
      style={{
        background: CARD,
        border: `1px solid ${BORDER}`,
        borderRadius: 16,
        padding: "24px",
        boxShadow: "0 8px 32px rgba(0,0,0,0.35)",
        ...style,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 20 }}>
        <span style={{ color: "#a78bfa" }}>{icon}</span>
        <h2 style={{ fontSize: 15, fontWeight: 700, color: "#fff", letterSpacing: "-0.01em" }}>
          {title}
        </h2>
      </div>
      {children}
    </div>
  );
}

function PasswordField({ label, value, onChange, show, onToggle, placeholder }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  show: boolean;
  onToggle: () => void;
  placeholder: string;
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <label style={{ fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.45)", letterSpacing: "0.05em" }}>
        {label.toUpperCase()}
      </label>
      <div style={{ position: "relative" }}>
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          style={{ ...inputStyle, paddingRight: 42 }}
        />
        <button
          type="button"
          onClick={onToggle}
          style={{
            position: "absolute",
            right: 12,
            top: "50%",
            transform: "translateY(-50%)",
            background: "none",
            border: "none",
            cursor: "pointer",
            color: "rgba(255,255,255,0.35)",
            display: "flex",
            alignItems: "center",
            padding: 0,
          }}
        >
          {show ? <EyeOff size={15} /> : <Eye size={15} />}
        </button>
      </div>
    </div>
  );
}

function PasswordStrength({ password }: { password: string }) {
  const score = [
    password.length >= 8,
    /[A-Z]/.test(password),
    /[0-9]/.test(password),
    /[^A-Za-z0-9]/.test(password),
  ].filter(Boolean).length;

  const labels = ["Weak", "Fair", "Good", "Strong"];
  const colors = ["#ef4444", "#f97316", "#eab308", "#22c55e"];

  return (
    <div>
      <div style={{ display: "flex", gap: 4, marginBottom: 5 }}>
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            style={{
              flex: 1,
              height: 3,
              borderRadius: 2,
              background: i < score ? colors[score - 1] : "rgba(255,255,255,0.1)",
              transition: "background 0.2s ease",
            }}
          />
        ))}
      </div>
      <p style={{ fontSize: 11, color: score > 0 ? colors[score - 1] : "rgba(255,255,255,0.3)" }}>
        {score > 0 ? labels[score - 1] : ""}
      </p>
    </div>
  );
}

function StatusMessage({ msg }: { msg: { type: "success" | "error"; text: string } }) {
  const ok = msg.type === "success";
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        padding: "10px 14px",
        borderRadius: 9,
        background: ok ? "rgba(34,197,94,0.1)" : "rgba(239,68,68,0.1)",
        border: `1px solid ${ok ? "rgba(34,197,94,0.25)" : "rgba(239,68,68,0.25)"}`,
        color: ok ? "#86efac" : "#fca5a5",
        fontSize: 13,
        marginTop: 4,
      }}
    >
      {ok ? <CheckCircle size={14} /> : <AlertCircle size={14} />}
      {msg.text}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div style={{ backgroundColor: BG, minHeight: "100vh" }}>
      <div className="max-w-[700px] mx-auto" style={{ padding: "40px 20px" }}>
        <div style={{ width: 140, height: 28, borderRadius: 6, background: "rgba(255,255,255,0.06)", marginBottom: 36 }} />
        {[180, 260].map((h, i) => (
          <div key={i} style={{ height: h, borderRadius: 16, background: "rgba(255,255,255,0.04)", marginBottom: 20 }} />
        ))}
      </div>
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  padding: "10px 14px",
  borderRadius: 9,
  background: "rgba(255,255,255,0.05)",
  border: "1px solid rgba(255,255,255,0.1)",
  color: "#fff",
  fontSize: 14,
  outline: "none",
  width: "100%",
  boxSizing: "border-box",
};

const btnOutlineStyle: React.CSSProperties = {
  padding: "8px 16px",
  borderRadius: 8,
  background: "transparent",
  border: "1px solid rgba(124,58,237,0.35)",
  color: "#c4b5fd",
  fontSize: 13,
  fontWeight: 600,
  cursor: "pointer",
  transition: "all 0.15s ease",
};

function btnPrimaryStyle(disabled: boolean): React.CSSProperties {
  return {
    padding: "8px 16px",
    borderRadius: 8,
    background: disabled
      ? "rgba(124,58,237,0.35)"
      : "linear-gradient(135deg, #7c3aed 0%, #5b21b6 100%)",
    border: "none",
    color: "#fff",
    fontSize: 13,
    fontWeight: 700,
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.7 : 1,
    transition: "all 0.15s ease",
  };
}

const btnDangerStyle: React.CSSProperties = {
  padding: "8px 16px",
  borderRadius: 8,
  background: "transparent",
  border: "1px solid rgba(239,68,68,0.3)",
  color: "rgba(239,68,68,0.75)",
  fontSize: 13,
  fontWeight: 600,
  cursor: "pointer",
  transition: "all 0.15s ease",
};
