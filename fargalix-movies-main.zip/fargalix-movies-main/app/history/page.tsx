"use client";

import { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import { useAuth } from "@/components/auth/auth-provider";
import { useRouter } from "next/navigation";
import { Trash2, History, AlertTriangle, X } from "lucide-react";
import { IMAGE_BASE_URL, IMAGE_BACKDROP_URL } from "@/lib/tmdb";

const BG = "#0b0f1a";
const ACCENT = "#7c3aed";

interface HistoryItem {
  id: string;
  tmdbId: number;
  mediaType: "MOVIE" | "TV";
  title: string;
  posterPath: string | null;
  backdropPath: string | null;
  season: number | null;
  episode: number | null;
  episodeName: string | null;
  progress: number;
  updatedAt: string;
}

type ModalState =
  | { type: "single"; item: HistoryItem }
  | { type: "all" }
  | null;

export default function HistoryPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [items, setItems] = useState<HistoryItem[]>([]);
  const [fetching, setFetching] = useState(true);
  const [modal, setModal] = useState<ModalState>(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/signin?redirect=/history");
  }, [loading, user, router]);

  const fetchHistory = useCallback(async () => {
    setFetching(true);
    try {
      const res = await fetch("/api/user/continue-watching");
      if (res.ok) {
        const data = await res.json();
        setItems(data.items ?? []);
      }
    } finally {
      setFetching(false);
    }
  }, []);

  useEffect(() => {
    if (user) fetchHistory();
  }, [user, fetchHistory]);

  async function deleteItem(item: HistoryItem) {
    setDeleting(true);
    try {
      await fetch(
        `/api/user/continue-watching?tmdbId=${item.tmdbId}&mediaType=${item.mediaType}`,
        { method: "DELETE" }
      );
      setItems((prev) => prev.filter((i) => i.id !== item.id));
    } finally {
      setDeleting(false);
      setModal(null);
    }
  }

  async function clearAll() {
    setDeleting(true);
    try {
      await fetch("/api/user/continue-watching?clearAll=true", { method: "DELETE" });
      setItems([]);
    } finally {
      setDeleting(false);
      setModal(null);
    }
  }

  if (loading || !user) return <PageSkeleton />;

  return (
    <div style={{ backgroundColor: BG, minHeight: "100vh", color: "#fff" }}>
      <div className="max-w-[1200px] mx-auto" style={{ padding: "40px 24px 80px" }}>

        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 32, flexWrap: "wrap", gap: 12 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
              <History size={20} style={{ color: "#a78bfa" }} />
              <h1 style={{ fontSize: 24, fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}>
                Watch History
              </h1>
              {items.length > 0 && (
                <span style={{
                  fontSize: 11, fontWeight: 700, color: "#a78bfa",
                  background: "rgba(124,58,237,0.14)", border: "1px solid rgba(124,58,237,0.26)",
                  padding: "2px 9px", borderRadius: 20,
                }}>
                  {items.length}
                </span>
              )}
            </div>
            <p style={{ fontSize: 13, color: "rgba(255,255,255,0.38)" }}>
              Movies and series you&apos;ve watched
            </p>
          </div>

          {items.length > 0 && (
            <button
              onClick={() => setModal({ type: "all" })}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 7,
                padding: "9px 18px",
                borderRadius: 9,
                background: "transparent",
                border: "1px solid rgba(239,68,68,0.35)",
                color: "rgba(239,68,68,0.8)",
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                transition: "all 0.15s ease",
              }}
              className="hover:bg-red-500/10"
            >
              <Trash2 size={14} />
              Clear All History
            </button>
          )}
        </div>

        {/* Content */}
        {fetching ? (
          <GridSkeleton />
        ) : items.length === 0 ? (
          <EmptyState />
        ) : (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
              gap: 16,
            }}
          >
            {items.map((item) => (
              <HistoryCard
                key={item.id}
                item={item}
                onDelete={() => setModal({ type: "single", item })}
              />
            ))}
          </div>
        )}
      </div>

      {/* Confirmation Modal */}
      {modal && (
        <ConfirmModal
          title={modal.type === "all" ? "Clear All History?" : "Remove from History?"}
          message={
            modal.type === "all"
              ? "This will permanently delete your entire watch history. This action cannot be undone."
              : `Remove "${(modal as { type: "single"; item: HistoryItem }).item.title}" from your watch history?`
          }
          onConfirm={() => {
            if (modal.type === "all") clearAll();
            else deleteItem((modal as { type: "single"; item: HistoryItem }).item);
          }}
          onCancel={() => setModal(null)}
          loading={deleting}
        />
      )}
    </div>
  );
}

// ── History Card ──────────────────────────────────────────────────────────

function HistoryCard({ item, onDelete }: { item: HistoryItem; onDelete: () => void }) {
  const [hovered, setHovered] = useState(false);

  const img = item.backdropPath
    ? `${IMAGE_BACKDROP_URL}${item.backdropPath}`
    : item.posterPath
      ? `${IMAGE_BASE_URL}${item.posterPath}`
      : null;

  const href =
    item.mediaType === "TV" && item.season && item.episode
      ? `/tv/${item.tmdbId}?play=1&season=${item.season}&episode=${item.episode}`
      : item.mediaType === "MOVIE"
        ? `/movie/${item.tmdbId}`
        : `/tv/${item.tmdbId}`;

  const progressPct = Math.min(Math.round(item.progress), 100);

  return (
    <div
      style={{
        borderRadius: 12,
        overflow: "hidden",
        background: "#13182b",
        border: hovered ? "1px solid rgba(124,58,237,0.4)" : "1px solid rgba(255,255,255,0.06)",
        transition: "all 0.2s ease",
        transform: hovered ? "translateY(-2px)" : "translateY(0)",
        boxShadow: hovered ? "0 8px 24px rgba(0,0,0,0.5)" : "none",
        position: "relative",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Thumbnail */}
      <Link href={href} style={{ textDecoration: "none" }}>
        <div style={{ position: "relative", width: "100%", paddingTop: "56.25%", background: "#1a2035" }}>
          {img && (
            <Image
              src={img}
              alt={item.title}
              fill
              sizes="(max-width: 768px) 50vw, 200px"
              style={{ objectFit: "cover" }}
              unoptimized
            />
          )}
          {/* Progress bar */}
          <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 3, background: "rgba(255,255,255,0.1)" }}>
            <div
              style={{
                height: "100%",
                width: `${progressPct}%`,
                background: "linear-gradient(90deg, #7c3aed, #a78bfa)",
                borderRadius: "0 2px 2px 0",
              }}
            />
          </div>
          {/* Media type badge */}
          <span style={{
            position: "absolute", top: 7, left: 7,
            fontSize: 8, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase",
            color: "#fff", background: "rgba(124,58,237,0.88)", padding: "2px 7px", borderRadius: 4,
          }}>
            {item.mediaType === "MOVIE" ? "Movie" : "Series"}
          </span>
          {/* TV episode badge */}
          {item.mediaType === "TV" && item.season && item.episode && (
            <span style={{
              position: "absolute", bottom: 6, right: 8,
              fontSize: 9, fontWeight: 700, color: "#fff",
              background: "rgba(0,0,0,0.75)", padding: "2px 6px", borderRadius: 4,
            }}>
              S{item.season}·E{item.episode}
            </span>
          )}
        </div>
      </Link>

      {/* Info */}
      <div style={{ padding: "10px 12px 12px" }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 6 }}>
          <Link href={href} style={{ textDecoration: "none", flex: 1, minWidth: 0 }}>
            <p style={{
              fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.85)",
              overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
            }}>
              {item.title}
            </p>
            {item.episodeName && (
              <p style={{
                fontSize: 10, color: "rgba(255,255,255,0.38)", marginTop: 2,
                overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
              }}>
                {item.episodeName}
              </p>
            )}
            <p style={{ fontSize: 10, color: "rgba(124,58,237,0.7)", marginTop: 3 }}>
              {progressPct}% watched
            </p>
          </Link>

          {/* Delete button */}
          <button
            onClick={(e) => { e.preventDefault(); onDelete(); }}
            title="Remove from history"
            style={{
              flexShrink: 0,
              width: 28,
              height: 28,
              borderRadius: 6,
              background: "transparent",
              border: "1px solid rgba(239,68,68,0.2)",
              color: "rgba(239,68,68,0.5)",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              transition: "all 0.15s ease",
            }}
            className="hover:bg-red-500/15 hover:border-red-500/50 hover:text-red-400"
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Confirm Modal ─────────────────────────────────────────────────────────

function ConfirmModal({ title, message, onConfirm, onCancel, loading }: {
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
  loading: boolean;
}) {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.75)",
        backdropFilter: "blur(4px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 9999,
        padding: 20,
      }}
      onClick={(e) => { if (e.target === e.currentTarget) onCancel(); }}
    >
      <div
        style={{
          background: "#111827",
          border: "1px solid rgba(124,58,237,0.3)",
          borderRadius: 16,
          padding: "28px",
          maxWidth: 420,
          width: "100%",
          boxShadow: "0 24px 64px rgba(0,0,0,0.8)",
        }}
      >
        <button
          onClick={onCancel}
          style={{
            position: "absolute",
            top: 0,
            right: 0,
            display: "none",
          }}
        />

        {/* Icon */}
        <div style={{
          width: 48, height: 48, borderRadius: 12,
          background: "rgba(239,68,68,0.12)",
          border: "1px solid rgba(239,68,68,0.25)",
          display: "flex", alignItems: "center", justifyContent: "center",
          marginBottom: 16,
        }}>
          <AlertTriangle size={22} style={{ color: "#ef4444" }} />
        </div>

        <h3 style={{ fontSize: 17, fontWeight: 700, color: "#fff", marginBottom: 8 }}>
          {title}
        </h3>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", lineHeight: 1.6, marginBottom: 24 }}>
          {message}
        </p>

        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
          <button
            onClick={onCancel}
            disabled={loading}
            style={{
              padding: "9px 20px",
              borderRadius: 9,
              background: "transparent",
              border: "1px solid rgba(255,255,255,0.12)",
              color: "rgba(255,255,255,0.6)",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              padding: "9px 20px",
              borderRadius: 9,
              background: loading ? "rgba(239,68,68,0.3)" : "rgba(239,68,68,0.85)",
              border: "none",
              color: "#fff",
              fontSize: 13,
              fontWeight: 700,
              cursor: loading ? "wait" : "pointer",
            }}
          >
            {loading ? (
              "Deleting…"
            ) : (
              <>
                <Trash2 size={13} />
                Delete
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div style={{
      padding: "64px 24px",
      textAlign: "center",
      borderRadius: 16,
      border: "1px dashed rgba(255,255,255,0.08)",
    }}>
      <History size={40} style={{ color: "rgba(124,58,237,0.4)", marginBottom: 14 }} />
      <p style={{ fontSize: 15, fontWeight: 600, color: "rgba(255,255,255,0.4)", marginBottom: 6 }}>
        No watch history yet
      </p>
      <p style={{ fontSize: 13, color: "rgba(255,255,255,0.22)" }}>
        Start watching movies or series to build your history
      </p>
      <Link
        href="/"
        style={{
          display: "inline-block",
          marginTop: 20,
          padding: "9px 22px",
          borderRadius: 9,
          background: "linear-gradient(135deg, #7c3aed, #5b21b6)",
          color: "#fff",
          fontSize: 13,
          fontWeight: 700,
          textDecoration: "none",
        }}
      >
        Browse Content
      </Link>
    </div>
  );
}

function GridSkeleton() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 16 }}>
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} style={{ borderRadius: 12, overflow: "hidden", background: "#13182b" }}>
          <div style={{ width: "100%", paddingTop: "56.25%", background: "rgba(255,255,255,0.04)" }} />
          <div style={{ padding: "10px 12px 12px" }}>
            <div style={{ height: 11, borderRadius: 4, background: "rgba(255,255,255,0.06)", marginBottom: 6, width: "75%" }} />
            <div style={{ height: 9, borderRadius: 4, background: "rgba(255,255,255,0.04)", width: "50%" }} />
          </div>
        </div>
      ))}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div style={{ backgroundColor: BG, minHeight: "100vh" }}>
      <div className="max-w-[1200px] mx-auto" style={{ padding: "40px 24px" }}>
        <div style={{ width: 180, height: 28, borderRadius: 6, background: "rgba(255,255,255,0.06)", marginBottom: 32 }} />
        <GridSkeleton />
      </div>
    </div>
  );
}
