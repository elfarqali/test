import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  getMovieFullDetail,
  getPopularMovies,
  getTrendingMovies,
  getTopRatedMovies,
  IMAGE_BASE_URL,
  IMAGE_BACKDROP_URL,
} from "@/lib/tmdb";
import { MediaCard } from "@/components/media-card";
import { WatchHistoryRecorder } from "@/components/watch-history-recorder";
import { TrailerButton } from "@/components/tv/trailer-button";
import { PlayerSwitcher } from "@/components/player-switcher";
import { FavoriteButton } from "@/components/auth/favorite-button";
import { ReportButton } from "@/components/report-button";
import { DiscussionSection } from "@/components/discussion-section";
import { getCachedPlayers } from "@/lib/players";
import { AdSlot } from "@/components/ad-slot";

// ══════════════════════════════════════════════════════════════════════════════
// FULLY STATIC — zero serverless execution after deploy
// ══════════════════════════════════════════════════════════════════════════════
// • dynamicParams = true  → new IDs generate on-demand, then cached forever
// • revalidate = false    → pages NEVER regenerate (no ISR writes)
export const dynamic = "force-static";
export const dynamicParams = true;
export const revalidate = false;

// ── Pre-build ~200 popular movies at deploy time ────────────────────────────
export async function generateStaticParams() {
  try {
    // Fetch 10 pages across multiple endpoints for broad coverage
    const [pop1, pop2, pop3, pop4, pop5, trend1, trend2, trend3, top1, top2] =
      await Promise.all([
        getPopularMovies(1),
        getPopularMovies(2),
        getPopularMovies(3),
        getPopularMovies(4),
        getPopularMovies(5),
        getTrendingMovies(1),
        getTrendingMovies(2),
        getTrendingMovies(3),
        getTopRatedMovies(1),
        getTopRatedMovies(2),
      ]);
    const allItems = [
      ...pop1.results, ...pop2.results, ...pop3.results, ...pop4.results, ...pop5.results,
      ...trend1.results, ...trend2.results, ...trend3.results,
      ...top1.results, ...top2.results,
    ];
    const seen = new Set<number>();
    const params: { id: string }[] = [];
    for (const item of allItems) {
      if (!seen.has(item.id)) {
        seen.add(item.id);
        params.push({ id: String(item.id) });
      }
    }
    return params;
  } catch {
    return [];
  }
}

interface MoviePageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: MoviePageProps) {
  const { id } = await params;

  // ── ID validation (backup — proxy catches most invalid IDs) ───────────────
  const numericId = parseInt(id, 10);
  if (isNaN(numericId) || numericId < 1 || numericId > 9_999_999) {
    return { title: "Movie – StreamVault" };
  }

  const movie = await getMovieFullDetail(numericId);
  if (!movie) return { title: "Movie – StreamVault" };

  const title = movie.title || movie.original_title;
  const year = movie.release_date ? new Date(movie.release_date).getFullYear() : "";
  const canonicalUrl = `https://sixflix.blog/movie/${movie.id}`;

  return {
    title: `${title} (${year}) – Watch Free on StreamVault`,
    description: movie.overview?.slice(0, 155),
    alternates: {
      canonical: canonicalUrl,
    },
    openGraph: {
      title: `${title} (${year}) – Watch Free on StreamVault`,
      description: movie.overview?.slice(0, 155),
      url: canonicalUrl,
      images: movie.backdrop_path ? [{ url: `${IMAGE_BACKDROP_URL}${movie.backdrop_path}` }] : [],
    },
    twitter: {
      card: "summary_large_image",
    }
  };
}

export default async function MoviePage({ params }: MoviePageProps) {
  const { id } = await params;

  // ── Strict ID validation before ANY fetch ─────────────────────────────────
  // This prevents wasted TMDB API calls + DB queries for invalid IDs.
  // The proxy already blocks most invalid IDs at the edge, but this is
  // a defense-in-depth measure.
  const numericId = parseInt(id, 10);
  if (isNaN(numericId) || numericId < 1 || numericId > 9_999_999) {
    notFound();
  }

  // Single TMDB call via append_to_response (was 5 separate calls)
  const [movie, players] = await Promise.all([
    getMovieFullDetail(numericId),
    getCachedPlayers(),
  ]);

  if (!movie) notFound();

  // Extract sub-resources from the combined response
  const credits = movie.credits ?? { cast: [], crew: [] };
  const videos = movie.videos?.results ?? [];
  const similar = (movie.similar?.results ?? []).map((i: any) => ({ ...i, media_type: "movie" as const }));
  const keywords = movie.keywords?.keywords ?? [];

  const trailer =
    videos.find((v: any) => v.site === "YouTube" && v.type === "Trailer" && v.official) ??
    videos.find((v: any) => v.site === "YouTube" && v.type === "Trailer") ??
    videos.find((v: any) => v.site === "YouTube");

  const backdrop = movie.backdrop_path
    ? `${IMAGE_BACKDROP_URL}${movie.backdrop_path}`
    : null;
  const posterSrc = movie.poster_path ? `${IMAGE_BASE_URL}${movie.poster_path}` : null;

  const year = movie.release_date ? new Date(movie.release_date).getFullYear() : null;
  const rating = movie.vote_average?.toFixed(1);
  const runtime = movie.runtime
    ? `${Math.floor(movie.runtime / 60)}h ${movie.runtime % 60}m`
    : null;

  const director = credits.crew.find((c: any) => c.job === "Director");
  const topCast = credits.cast.slice(0, 12);
  const country = movie.production_countries?.[0]?.name ?? null;
  const topKeywords = keywords.slice(0, 12);

  const releaseFormatted = movie.release_date
    ? new Date(movie.release_date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
    : null;

  const movieSources = players.map((p: any) => ({
    name: p.name,
    src: p.movieUrl.replace(/\{id\}/g, movie.id.toString()),
  }));

  /* ─── Design tokens (identical to series page) ─── */
  const BG = "#0b0f1a";
  const ACCENT = "#7c3aed";
  const ACCENT_SOFT = "rgba(124,58,237,0.15)";
  const ACCENT_BORDER = "rgba(124,58,237,0.26)";

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Movie",
    name: movie.title,
    image: posterSrc || undefined,
    datePublished: movie.release_date || undefined,
    director: director ? { "@type": "Person", name: director.name } : undefined,
    actor: topCast.map(a => ({ "@type": "Person", name: a.name })),
    description: movie.overview,
  };

  return (
    <div style={{ backgroundColor: BG, minHeight: "100vh", color: "#fff" }}>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <WatchHistoryRecorder
        id={movie.id}
        media_type="movie"
        title={movie.title}
        poster_path={movie.poster_path ?? null}
        backdrop_path={movie.backdrop_path ?? null}
        runtimeMinutes={movie.runtime ?? undefined}
      />

      {/* ══════════════════════════════════════════════════════
          HERO — Backdrop background + player embedded
      ══════════════════════════════════════════════════════ */}
      <div style={{ position: "relative", overflow: "hidden" }}>
        {/* Backdrop as background layer */}
        {backdrop && (
          <>
            <Image
              src={backdrop}
              alt={movie.title}
              fill
              priority
              sizes="100vw"
              className="object-cover object-top"
              unoptimized
            />
            {/* Dark vignette overlay */}
            <div
              className="absolute inset-0"
              style={{ backgroundColor: "rgba(11,15,26,0.72)" }}
            />
            {/* Bottom fade to page bg */}
            <div
              className="absolute bottom-0 left-0 right-0"
              style={{
                height: 120,
                background: `linear-gradient(to top, ${BG}, transparent)`,
              }}
            />
          </>
        )}

        {/* Player on top of backdrop */}
        <div
          className="max-w-[1400px] mx-auto"
          style={{
            position: "relative",
            zIndex: 1,
            padding: backdrop ? "64px 28px 48px" : "32px 28px",
          }}
        >
          <div
            style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}
          >
            <span
              style={{
                display: "inline-block",
                width: 3,
                height: 20,
                borderRadius: 2,
                background: `linear-gradient(180deg, #a78bfa 0%, ${ACCENT} 100%)`,
              }}
            />
            <h2
              style={{
                fontSize: 16,
                fontWeight: 700,
                color: "#fff",
                letterSpacing: "-0.02em",
              }}
            >
              {movie.title}
            </h2>
          </div>
          {/* Ad — Before Player */}
          <AdSlot placement="MOVIE_PAGE" position="BEFORE_PLAYER" style={{ marginBottom: 12 }} />
          <AdSlot placement="VIDEO_PLAYER" position="BEFORE_PLAYER" style={{ marginBottom: 12 }} />
          <PlayerSwitcher
            sources={movieSources}
            title={`Watch ${movie.title}`}
          />
          {/* Ad — After Player */}
          <AdSlot placement="MOVIE_PAGE" position="AFTER_PLAYER" style={{ marginTop: 12 }} />
          <AdSlot placement="VIDEO_PLAYER" position="AFTER_PLAYER" style={{ marginTop: 12 }} />
          <div style={{ marginTop: 8, display: "flex", justifyContent: "flex-end" }}>
            <ReportButton mediaId={Number(id)} mediaType="MOVIE" />
          </div>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════
          HERO — POSTER LEFT + METADATA RIGHT
      ══════════════════════════════════════════════════════ */}
      <div
        className="max-w-[1400px] mx-auto relative z-10"
        style={{ padding: "40px 28px 0", borderTop: "1px solid rgba(255,255,255,0.05)" }}
      >
        <div style={{ display: "flex", gap: 36, alignItems: "flex-start" }}>

          {/* ── Large vertical poster ── */}
          {posterSrc && (
            <div
              className="hidden md:block"
              style={{
                flexShrink: 0,
                width: 262,
                height: 393,
                borderRadius: 18,
                overflow: "hidden",
                position: "relative",
                boxShadow:
                  "0 28px 68px rgba(0,0,0,0.88), 0 0 0 1px rgba(255,255,255,0.07)",
              }}
            >
              <Image
                src={posterSrc}
                alt={movie.title}
                fill
                sizes="262px"
                className="object-cover"
                unoptimized
              />
            </div>
          )}

          {/* ── Metadata column ── */}
          <div
            style={{
              flex: 1,
              paddingTop: 16,
              paddingBottom: 32,
              minWidth: 0,
            }}
          >
            {/* Genre badges */}
            <div
              style={{ display: "flex", flexWrap: "wrap", gap: 7, marginBottom: 14 }}
            >
              <span
                style={{
                  fontSize: 10,
                  fontWeight: 800,
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  color: "#a78bfa",
                  background: ACCENT_SOFT,
                  border: `1px solid ${ACCENT_BORDER}`,
                  padding: "3px 10px",
                  borderRadius: 7,
                }}
              >
                Movie
              </span>
              {movie.genres.slice(0, 3).map((g: any) => (
                <span
                  key={g.id}
                  style={{
                    fontSize: 10,
                    fontWeight: 600,
                    color: "rgba(255,255,255,0.48)",
                    background: "rgba(255,255,255,0.06)",
                    border: "1px solid rgba(255,255,255,0.09)",
                    padding: "3px 10px",
                    borderRadius: 7,
                  }}
                >
                  {g.name}
                </span>
              ))}
            </div>

            {/* Title */}
            <h1
              style={{
                fontSize: "clamp(26px, 3.8vw, 50px)",
                fontWeight: 900,
                color: "#fff",
                lineHeight: 1.05,
                letterSpacing: "-0.03em",
                textTransform: "uppercase",
                marginBottom: movie.tagline ? 8 : 18,
              }}
            >
              {movie.title}
            </h1>

            {/* Tagline */}
            {movie.tagline && (
              <p
                style={{
                  color: "rgba(255,255,255,0.35)",
                  fontSize: 13,
                  fontStyle: "italic",
                  marginBottom: 16,
                }}
              >
                &ldquo;{movie.tagline}&rdquo;
              </p>
            )}

            {/* Quality / Year / Rating / Runtime badges */}
            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                alignItems: "center",
                gap: 8,
                marginBottom: 26,
              }}
            >
              <span
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  letterSpacing: "0.06em",
                  color: "#e2e8f0",
                  background: "rgba(255,255,255,0.09)",
                  border: "1px solid rgba(255,255,255,0.16)",
                  padding: "4px 11px",
                  borderRadius: 7,
                }}
              >
                HD 1080p
              </span>

              {year && (
                <span
                  style={{
                    fontSize: 11,
                    fontWeight: 600,
                    color: "rgba(255,255,255,0.62)",
                    background: "rgba(255,255,255,0.06)",
                    border: "1px solid rgba(255,255,255,0.1)",
                    padding: "4px 11px",
                    borderRadius: 7,
                  }}
                >
                  {year}
                </span>
              )}

              <span
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 5,
                  fontSize: 11,
                  fontWeight: 700,
                  color: "#facc15",
                  background: "rgba(250,204,21,0.11)",
                  border: "1px solid rgba(250,204,21,0.22)",
                  padding: "4px 11px",
                  borderRadius: 7,
                }}
              >
                <svg width="10" height="10" viewBox="0 0 24 24" fill="#facc15">
                  <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" />
                </svg>
                {rating}
              </span>

              {runtime && (
                <span
                  style={{
                    fontSize: 11,
                    color: "rgba(255,255,255,0.42)",
                    background: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    padding: "4px 11px",
                    borderRadius: 7,
                  }}
                >
                  {runtime}
                </span>
              )}
            </div>

            {/* Action buttons */}
            <div style={{ display: "flex", flexWrap: "wrap", gap: 10, alignItems: "center" }}>
              {trailer && (
                <TrailerButton trailerKey={trailer.key} showName={movie.title} />
              )}
              <FavoriteButton
                tmdbId={movie.id}
                mediaType="MOVIE"
                title={movie.title}
                posterPath={movie.poster_path}
                backdropPath={movie.backdrop_path}
                voteAverage={movie.vote_average}
                year={year ? String(year) : null}
              />
            </div>

            {/* Overview */}
            {movie.overview && (
              <p
                style={{
                  color: "rgba(255,255,255,0.6)",
                  fontSize: 14,
                  lineHeight: 1.85,
                  maxWidth: 580,
                  marginTop: 22,
                  marginBottom: 28,
                }}
              >
                {movie.overview}
              </p>
            )}

            {/* Meta table */}
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: 9,
                marginBottom: 30,
                fontSize: 13,
                maxWidth: 540,
              }}
            >
              {[
                movie.genres.length > 0 && {
                  label: "Genre",
                  value: movie.genres.map((g: any) => g.name).join(", "),
                },
                country && { label: "Country", value: country },
                releaseFormatted && {
                  label: "Release Date",
                  value: releaseFormatted,
                },
                director && { label: "Director", value: director.name },
                movie.status && { label: "Status", value: movie.status },
              ]
                .filter(Boolean)
                .map(
                  (row: any) =>
                    row && (
                      <div key={row.label} style={{ display: "flex", gap: 0 }}>
                        <span
                          style={{
                            color: "rgba(255,255,255,0.3)",
                            minWidth: 112,
                            flexShrink: 0,
                          }}
                        >
                          {row.label}
                        </span>
                        <span style={{ color: "rgba(255,255,255,0.76)" }}>
                          {row.value}
                        </span>
                      </div>
                    )
                )}
            </div>

            {/* Cast circles */}
            {topCast.length > 0 && (
              <div style={{ marginBottom: 28 }}>
                <p
                  style={{
                    color: "rgba(255,255,255,0.27)",
                    fontSize: 11,
                    fontWeight: 700,
                    letterSpacing: "0.1em",
                    textTransform: "uppercase",
                    marginBottom: 14,
                  }}
                >
                  Cast
                </p>
                <div
                  style={{
                    display: "flex",
                    gap: 16,
                    overflowX: "auto",
                    scrollbarWidth: "none",
                    paddingBottom: 4,
                  }}
                >
                  {topCast.map((person: any) => {
                    const photo = person.profile_path
                      ? `${IMAGE_BASE_URL}${person.profile_path}`
                      : null;
                    return (
                      <div
                        key={person.id}
                        style={{ flexShrink: 0, textAlign: "center", width: 64 }}
                      >
                        <div
                          style={{
                            width: 54,
                            height: 54,
                            borderRadius: "50%",
                            overflow: "hidden",
                            margin: "0 auto 8px",
                            background: "rgba(255,255,255,0.06)",
                            border: "2px solid rgba(255,255,255,0.09)",
                            position: "relative",
                          }}
                        >
                          {photo ? (
                            <Image
                              src={photo}
                              alt={person.name}
                              fill
                              sizes="54px"
                              className="object-cover"
                              unoptimized
                            />
                          ) : (
                            <div
                              style={{
                                width: "100%",
                                height: "100%",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                color: "rgba(255,255,255,0.18)",
                                fontSize: 20,
                              }}
                            >
                              ?
                            </div>
                          )}
                        </div>
                        <p
                          className="line-clamp-1"
                          title={person.name}
                          style={{
                            fontSize: 10,
                            fontWeight: 600,
                            color: "rgba(255,255,255,0.7)",
                          }}
                        >
                          {person.name}
                        </p>
                        <p
                          className="line-clamp-1"
                          title={person.character}
                          style={{
                            fontSize: 9,
                            color: "rgba(255,255,255,0.28)",
                            marginTop: 2,
                          }}
                        >
                          {person.character}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Keyword tags */}
            {topKeywords.length > 0 && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
                {topKeywords.map((kw: any) => (
                  <span
                    key={kw.id}
                    style={{
                      fontSize: 11,
                      fontWeight: 500,
                      color: "rgba(167,139,250,0.68)",
                      background: ACCENT_SOFT,
                      border: `1px solid ${ACCENT_BORDER}`,
                      padding: "4px 13px",
                      borderRadius: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    {kw.name}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════
          DISCUSSION
      ══════════════════════════════════════════════════════ */}
      <div
        className="max-w-[1100px] mx-auto"
        style={{
          padding: "40px 28px 0",
          borderTop: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            marginBottom: 24,
          }}
        >
          <span
            style={{
              display: "inline-block",
              width: 3,
              height: 20,
              borderRadius: 2,
              background: "linear-gradient(180deg, #a78bfa 0%, #7c3aed 100%)",
            }}
          />
          <h2
            style={{
              fontSize: 16,
              fontWeight: 700,
              color: "#fff",
              letterSpacing: "-0.02em",
            }}
          >
            Discussion
          </h2>
        </div>
        <DiscussionSection mediaType="MOVIE" mediaId={movie.id} />
      </div>

      {/* ══════════════════════════════════════════════════════
          RECOMMENDED FOR YOU
      ══════════════════════════════════════════════════════ */}
      {similar.length > 0 && (
        <div
          className="max-w-[1400px] mx-auto"
          style={{ padding: "52px 28px 64px" }}
        >
          <div
            style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}
          >
            <span
              style={{
                display: "inline-block",
                width: 3,
                height: 20,
                borderRadius: 2,
                background: `linear-gradient(180deg, #a78bfa 0%, ${ACCENT} 100%)`,
              }}
            />
            <h2
              style={{
                fontSize: 16,
                fontWeight: 700,
                color: "#fff",
                letterSpacing: "-0.02em",
              }}
            >
              Recommended For You
            </h2>
          </div>

          <div
            style={{
              display: "flex",
              gap: 14,
              overflowX: "auto",
              scrollbarWidth: "none",
              paddingBottom: 10,
            }}
          >
            {similar.slice(0, 20).map((item: any) => (
              <div key={item.id} style={{ flexShrink: 0 }}>
                <MediaCard item={item} width={162} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Back link */}
      <div
        className="max-w-[1400px] mx-auto"
        style={{ padding: "0 28px 40px" }}
      >
        <Link
          href="/movies"
          style={{
            fontSize: 12,
            color: "rgba(255,255,255,0.28)",
            textDecoration: "none",
          }}
        >
          ← Back to Movies
        </Link>
      </div>
    </div>
  );
}
