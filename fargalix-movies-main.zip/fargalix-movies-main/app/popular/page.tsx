import { Suspense } from "react";
import { getPopularMovies, getPopularSeries } from "@/lib/tmdb";
import { MediaCard } from "@/components/media-card";
import { PaginationControls } from "@/components/pagination-controls";

interface PopularPageProps {
  searchParams: Promise<{ page?: string }>;
}

import { getSiteName } from "@/lib/settings";

export async function generateMetadata() {
  const siteName = await getSiteName();
  return {
    title: `Popular - ${siteName}`,
    description: "Most popular movies and series right now.",
  };
}

// ISR — each ?page=N variant is generated once, then cached for 24h
export const revalidate = 86400;

export default async function PopularPage({ searchParams }: PopularPageProps) {
  const params = await searchParams;
  const page = Math.max(1, parseInt(params.page ?? "1", 10) || 1);

  const [movies, series] = await Promise.all([
    getPopularMovies(page),
    getPopularSeries(page),
  ]);

  const combined = [
    ...movies.results.map((i) => ({ ...i, _forceType: "Movie" as const })),
    ...series.results.map((i) => ({ ...i, _forceType: "Series" as const })),
  ];

  const totalPages = Math.max(movies.total_pages, series.total_pages);

  return (
    <div style={{ backgroundColor: "#0b0f1a", minHeight: "100vh" }}>
      <div className="max-w-[1400px] mx-auto px-4 py-6">
        <div className="mb-5 flex items-center gap-2">
          <span
            className="inline-block w-0.5 h-4 rounded-full"
            style={{ backgroundColor: "#7c3aed" }}
          />
          <h1 className="text-sm font-semibold text-white">Popular</h1>
          <span className="text-[11px] text-white/40">— movies &amp; series</span>
        </div>

        {combined.length > 0 ? (
          <>
            <div
              className="grid gap-x-3 gap-y-5"
              style={{ gridTemplateColumns: "repeat(auto-fill, minmax(105px, 1fr))" }}
            >
              {combined.map((item) => (
                <MediaCard
                  key={`${item.id}-${item._forceType}`}
                  item={item}
                  showType={true}
                  width={"100%"}
                />
              ))}
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={`ph-${i}`} aria-hidden="true" style={{ visibility: "hidden", minWidth: 105 }} />
              ))}
            </div>

            <Suspense fallback={<div className="h-16" />}>
              <PaginationControls currentPage={page} totalPages={totalPages} />
            </Suspense>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <p className="text-sm text-white/30">No results found</p>
            <p className="mt-1 text-xs text-white/20">Check your TMDB API key in .env.local</p>
          </div>
        )}
      </div>
    </div>
  );
}
