import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  getTVFullDetail,
  getTVSeasonDetail,
  getPopularSeries,
  getTrendingSeries,
  getTopRatedSeries,
  IMAGE_BASE_URL,
  IMAGE_BACKDROP_URL,
} from "@/lib/tmdb";
import { WatchHistoryRecorder } from "@/components/watch-history-recorder";
import { TrailerButton } from "@/components/tv/trailer-button";
import { MediaCard } from "@/components/media-card";
import { FavoriteButton } from "@/components/auth/favorite-button";
import { getCachedPlayers } from "@/lib/players";
import {
  TVClientShell,
  TVEpisodeBrowse,
  TVBackdrop,
  TVHeroMetadata,
  TVMetadataColumn,
} from "@/components/tv-client-shell";
import { DiscussionSection } from "@/components/discussion-section";

// ══════════════════════════════════════════════════════════════════════════════
// • dynamicParams = true  → new IDs generate on-demand, then cached forever
// • revalidate = false    → pages NEVER regenerate (no ISR writes)
export const dynamic = "force-static";
export const dynamicParams = true;
export const revalidate = false;

// ── Pre-build ~200 popular TV shows at deploy time ──────────────────────────
export async function generateStaticParams() {
  try {
    const [pop1, pop2, pop3, pop4, pop5, trend1, trend2, trend3, top1, top2] =
      await Promise.all([
        getPopularSeries(1),
        getPopularSeries(2),
        getPopularSeries(3),
        getPopularSeries(4),
        getPopularSeries(5),
        getTrendingSeries(1),
        getTrendingSeries(2),
        getTrendingSeries(3),
        getTopRatedSeries(1),
        getTopRatedSeries(2),
      ]);
    const allItems = [
      ...pop1.results, ...pop2.results, ...pop3.results, ...pop4.results, ...pop5.results,
      ...trend1.results, ...trend2.results, ...trend3.results,
      ...top1.results, ...top2.results,
    ];
    const seen = new Set<number>();
    const params: { id: string }[] = [];
    for (const item of allItems) {
      if (!seen.has(item.id)) {
        seen.add(item.id);
        params.push({ id: String(item.id) });
      }
    }
    return params;
  } catch {
    return [];
  }
}

/* ─── Types ─────────────────────────────────────────────────── */
interface TVPageProps {
  params: Promise<{ id: string }>;
}

/* ─── Metadata ───────────────────────────────────────────────── */
export async function generateMetadata({ params }: TVPageProps) {
  const { id } = await params;

  const numericId = parseInt(id, 10);
  if (isNaN(numericId) || numericId < 1 || numericId > 9_999_999) {
    return { title: "Series – StreamVault" };
  }

  const show = await getTVFullDetail(numericId);
  if (!show) return { title: "Series – StreamVault" };

  const title = show.name || show.original_name;
  const year = show.first_air_date ? new Date(show.first_air_date).getFullYear() : "";
  const canonicalUrl = `https://sixflix.blog/tv/${show.id}`;

  return {
    title: `${title} (${year}) – Watch Free on StreamVault`,
    description: show.overview?.slice(0, 155),
    alternates: {
      canonical: canonicalUrl,
    },
    openGraph: {
      title: `${title} (${year}) – Watch Free on StreamVault`,
      description: show.overview?.slice(0, 155),
      url: canonicalUrl,
      images: show.backdrop_path ? [{ url: `${IMAGE_BACKDROP_URL}${show.backdrop_path}` }] : [],
    },
    twitter: {
      card: "summary_large_image",
    }
  };
}

/* ─── Page ───────────────────────────────────────────────────── */
export default async function TVPage({ params }: TVPageProps) {
  const { id } = await params;

  // ── Strict ID validation before ANY fetch ─────────────────────────────────
  const numericId = parseInt(id, 10);
  if (isNaN(numericId) || numericId < 1 || numericId > 9_999_999) {
    notFound();
  }

  /* Single TMDB call via append_to_response */
  const [show, players] = await Promise.all([
    getTVFullDetail(numericId),
    getCachedPlayers(),
  ]);

  if (!show) notFound();

  /* Extract sub-resources from the combined response */
  const credits = show.credits ?? { cast: [], crew: [] };
  const videos = show.videos?.results ?? [];
  const similar = (show.similar?.results ?? []).map((i: any) => ({ ...i, media_type: "tv" as const }));
  const keywords = show.keywords?.results ?? [];

  /* Season — always pre-fetch season 1 (default) for the static shell */
  const validSeasons = show.seasons.filter((s: any) => s.season_number > 0);
  const defaultSeason = validSeasons[0]?.season_number ?? 1;
  const seasonDetail = await getTVSeasonDetail(numericId, defaultSeason);
  const defaultEpisodes = seasonDetail?.episodes ?? [];

  /* Trailer */
  const trailer =
    videos.find((v: any) => v.site === "YouTube" && v.type === "Trailer" && v.official) ??
    videos.find((v: any) => v.site === "YouTube" && v.type === "Trailer") ??
    videos.find((v: any) => v.site === "YouTube");

  /* Image URLs */
  const backdrop = show.backdrop_path
    ? `${IMAGE_BACKDROP_URL}${show.backdrop_path}`
    : null;
  const posterSrc = show.poster_path ? `${IMAGE_BASE_URL}${show.poster_path}` : null;

  /* Derived data */
  const year = show.first_air_date
    ? new Date(show.first_air_date).getFullYear()
    : null;
  const rating = show.vote_average?.toFixed(1);
  const topCast = credits.cast.slice(0, 12);
  const country =
    show.production_countries?.[0]?.name ??
    show.origin_country?.[0] ??
    null;
  const topKeywords = keywords.slice(0, 12);
  const releaseFormatted = show.first_air_date
    ? new Date(show.first_air_date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
    : null;

  /* ─── Design tokens ─── */
  const BG = "#0b0f1a";
  const ACCENT = "#7c3aed";
  const ACCENT_SOFT = "rgba(124,58,237,0.15)";
  const ACCENT_BORDER = "rgba(124,58,237,0.26)";

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "TVSeries",
    name: show.name,
    image: posterSrc || undefined,
    datePublished: show.first_air_date || undefined,
    actor: topCast.map(a => ({ "@type": "Person", name: a.name })),
    description: show.overview,
  };

  return (
    <div style={{ backgroundColor: BG, minHeight: "100vh", color: "#fff" }}>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      {/* ── Non-playing watch history (browsing state) ── */}
      <WatchHistoryRecorder
        id={show.id}
        media_type="tv"
        title={show.name}
        poster_path={show.poster_path ?? null}
        backdrop_path={show.backdrop_path ?? null}
      />

      {/* ══════════════════════════════════════════════════════
          CLIENT SHELL — Player + episode selector when ?play=1
          All searchParam logic lives here (client-side only).
      ══════════════════════════════════════════════════════ */}
      <TVClientShell
        show={{
          id: show.id,
          name: show.name,
          poster_path: show.poster_path,
          backdrop_path: show.backdrop_path,
          seasons: show.seasons,
          episode_run_time: show.episode_run_time,
        }}
        players={players}
        defaultEpisodes={defaultEpisodes}
        defaultSeason={defaultSeason}
      />

      {/* ══════════════════════════════════════════════════════
          BACKDROP — classic fixed-height when NOT playing
      ══════════════════════════════════════════════════════ */}
      <TVBackdrop backdropUrl={backdrop} showName={show.name} />

      {/* ══════════════════════════════════════════════════════
          HERO — POSTER LEFT + METADATA RIGHT
      ══════════════════════════════════════════════════════ */}
      <TVHeroMetadata hasBackdrop={!!backdrop}>
        <div style={{ display: "flex", gap: 36, alignItems: "flex-start" }}>

          {/* ── Large vertical poster ── */}
          {posterSrc && (
            <div
              className="hidden md:block"
              style={{
                flexShrink: 0,
                width: 262,
                height: 393,
                borderRadius: 18,
                overflow: "hidden",
                position: "relative",
                boxShadow:
                  "0 28px 68px rgba(0,0,0,0.88), 0 0 0 1px rgba(255,255,255,0.07)",
              }}
            >
              <Image
                src={posterSrc}
                alt={show.name}
                fill
                sizes="262px"
                className="object-cover"
                unoptimized
              />
            </div>
          )}

          {/* ── Metadata column ── */}
          <TVMetadataColumn hasBackdrop={!!backdrop}>
            {/* Genre badges */}
            <div
              style={{ display: "flex", flexWrap: "wrap", gap: 7, marginBottom: 14 }}
            >
              <span
                style={{
                  fontSize: 10,
                  fontWeight: 800,
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  color: "#a78bfa",
                  background: ACCENT_SOFT,
                  border: `1px solid ${ACCENT_BORDER}`,
                  padding: "3px 10px",
                  borderRadius: 7,
                }}
              >
                Series
              </span>
              {show.genres.slice(0, 3).map((g: any) => (
                <span
                  key={g.id}
                  style={{
                    fontSize: 10,
                    fontWeight: 600,
                    color: "rgba(255,255,255,0.48)",
                    background: "rgba(255,255,255,0.06)",
                    border: "1px solid rgba(255,255,255,0.09)",
                    padding: "3px 10px",
                    borderRadius: 7,
                  }}
                >
                  {g.name}
                </span>
              ))}
            </div>

            {/* Title */}
            <h1
              style={{
                fontSize: "clamp(26px, 3.8vw, 50px)",
                fontWeight: 900,
                color: "#fff",
                lineHeight: 1.05,
                letterSpacing: "-0.03em",
                textTransform: "uppercase",
                marginBottom: 18,
              }}
            >
              {show.name}
            </h1>

            {/* Quality / Year / Rating / Season badges */}
            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                alignItems: "center",
                gap: 8,
                marginBottom: 26,
              }}
            >
              <span
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  letterSpacing: "0.06em",
                  color: "#e2e8f0",
                  background: "rgba(255,255,255,0.09)",
                  border: "1px solid rgba(255,255,255,0.16)",
                  padding: "4px 11px",
                  borderRadius: 7,
                }}
              >
                HD 1080p
              </span>
              {year && (
                <span
                  style={{
                    fontSize: 11,
                    fontWeight: 600,
                    color: "rgba(255,255,255,0.62)",
                    background: "rgba(255,255,255,0.06)",
                    border: "1px solid rgba(255,255,255,0.1)",
                    padding: "4px 11px",
                    borderRadius: 7,
                  }}
                >
                  {year}
                </span>
              )}
              <span
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 5,
                  fontSize: 11,
                  fontWeight: 700,
                  color: "#facc15",
                  background: "rgba(250,204,21,0.11)",
                  border: "1px solid rgba(250,204,21,0.22)",
                  padding: "4px 11px",
                  borderRadius: 7,
                }}
              >
                <svg width="10" height="10" viewBox="0 0 24 24" fill="#facc15">
                  <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" />
                </svg>
                {rating}
              </span>
              <span
                style={{
                  fontSize: 11,
                  color: "rgba(255,255,255,0.42)",
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  padding: "4px 11px",
                  borderRadius: 7,
                }}
              >
                {show.number_of_seasons} Season
                {show.number_of_seasons !== 1 ? "s" : ""}
              </span>
            </div>

            {/* Action buttons */}
            <div style={{ display: "flex", flexWrap: "wrap", gap: 10, alignItems: "center" }}>
              {trailer && (
                <TrailerButton trailerKey={trailer.key} showName={show.name} />
              )}
              <FavoriteButton
                tmdbId={show.id}
                mediaType="TV"
                title={show.name}
                posterPath={show.poster_path}
                backdropPath={show.backdrop_path}
                voteAverage={show.vote_average}
                year={year ? String(year) : null}
              />
            </div>

            {/* Overview */}
            {show.overview && (
              <p
                style={{
                  color: "rgba(255,255,255,0.6)",
                  fontSize: 14,
                  lineHeight: 1.85,
                  maxWidth: 580,
                  marginTop: 22,
                  marginBottom: 28,
                }}
              >
                {show.overview}
              </p>
            )}

            {/* Meta table */}
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: 9,
                marginBottom: 30,
                fontSize: 13,
                maxWidth: 540,
              }}
            >
              {[
                show.genres.length > 0 && {
                  label: "Genre",
                  value: show.genres.map((g: any) => g.name).join(", "),
                },
                country && { label: "Country", value: country },
                releaseFormatted && {
                  label: "Release Date",
                  value: releaseFormatted,
                },
                show.status && { label: "Status", value: show.status },
                show.networks?.length > 0 && {
                  label: "Network",
                  value: show.networks.map((n: any) => n.name).join(", "),
                },
              ]
                .filter(Boolean)
                .map(
                  (row: any) =>
                    row && (
                      <div key={row.label} style={{ display: "flex", gap: 0 }}>
                        <span
                          style={{
                            color: "rgba(255,255,255,0.3)",
                            minWidth: 112,
                            flexShrink: 0,
                          }}
                        >
                          {row.label}
                        </span>
                        <span style={{ color: "rgba(255,255,255,0.76)" }}>
                          {row.value}
                        </span>
                      </div>
                    )
                )}
            </div>

            {/* Cast circles */}
            {topCast.length > 0 && (
              <div style={{ marginBottom: 28 }}>
                <p
                  style={{
                    color: "rgba(255,255,255,0.27)",
                    fontSize: 11,
                    fontWeight: 700,
                    letterSpacing: "0.1em",
                    textTransform: "uppercase",
                    marginBottom: 14,
                  }}
                >
                  Cast
                </p>
                <div
                  style={{
                    display: "flex",
                    gap: 16,
                    overflowX: "auto",
                    scrollbarWidth: "none",
                    paddingBottom: 4,
                  }}
                >
                  {topCast.map((person: any) => {
                    const photo = person.profile_path
                      ? `${IMAGE_BASE_URL}${person.profile_path}`
                      : null;
                    return (
                      <div
                        key={person.id}
                        style={{
                          flexShrink: 0,
                          textAlign: "center",
                          width: 64,
                        }}
                      >
                        <div
                          style={{
                            width: 54,
                            height: 54,
                            borderRadius: "50%",
                            overflow: "hidden",
                            margin: "0 auto 8px",
                            background: "rgba(255,255,255,0.06)",
                            border: "2px solid rgba(255,255,255,0.09)",
                            position: "relative",
                          }}
                        >
                          {photo ? (
                            <Image
                              src={photo}
                              alt={person.name}
                              fill
                              sizes="54px"
                              className="object-cover"
                              unoptimized
                            />
                          ) : (
                            <div
                              style={{
                                width: "100%",
                                height: "100%",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                color: "rgba(255,255,255,0.18)",
                                fontSize: 20,
                              }}
                            >
                              ?
                            </div>
                          )}
                        </div>
                        <p
                          className="line-clamp-1"
                          title={person.name}
                          style={{
                            fontSize: 10,
                            fontWeight: 600,
                            color: "rgba(255,255,255,0.7)",
                          }}
                        >
                          {person.name}
                        </p>
                        <p
                          className="line-clamp-1"
                          title={person.character}
                          style={{
                            fontSize: 9,
                            color: "rgba(255,255,255,0.28)",
                            marginTop: 2,
                          }}
                        >
                          {person.character}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Keyword tags */}
            {topKeywords.length > 0 && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
                {topKeywords.map((kw: any) => (
                  <span
                    key={kw.id}
                    style={{
                      fontSize: 11,
                      fontWeight: 500,
                      color: "rgba(167,139,250,0.68)",
                      background: ACCENT_SOFT,
                      border: `1px solid ${ACCENT_BORDER}`,
                      padding: "4px 13px",
                      borderRadius: 20,
                      textTransform: "capitalize",
                    }}
                  >
                    {kw.name}
                  </span>
                ))}
              </div>
            )}
          </TVMetadataColumn>
        </div>
      </TVHeroMetadata>

      {/* ══════════════════════════════════════════════════════
          EPISODES — shown below hero when NOT playing
      ══════════════════════════════════════════════════════ */}
      <TVEpisodeBrowse
        show={{
          id: show.id,
          name: show.name,
          poster_path: show.poster_path,
          backdrop_path: show.backdrop_path,
          seasons: show.seasons,
          episode_run_time: show.episode_run_time,
        }}
        defaultEpisodes={defaultEpisodes}
        defaultSeason={defaultSeason}
      />

      {/* ══════════════════════════════════════════════════════
          DISCUSSION
      ══════════════════════════════════════════════════════ */}
      <div
        className="max-w-[1100px] mx-auto"
        style={{
          padding: "40px 28px 0",
          borderTop: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            marginBottom: 24,
          }}
        >
          <span
            style={{
              display: "inline-block",
              width: 3,
              height: 20,
              borderRadius: 2,
              background: "linear-gradient(180deg, #a78bfa 0%, #7c3aed 100%)",
            }}
          />
          <h2
            style={{
              fontSize: 16,
              fontWeight: 700,
              color: "#fff",
              letterSpacing: "-0.02em",
            }}
          >
            Discussion
          </h2>
        </div>
        <DiscussionSection mediaType="TV" mediaId={show.id} />
      </div>

      {/* ══════════════════════════════════════════════════════
          RECOMMENDED FOR YOU
      ══════════════════════════════════════════════════════ */}
      {similar.length > 0 && (
        <div
          className="max-w-[1400px] mx-auto"
          style={{ padding: "52px 28px 64px" }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              marginBottom: 20,
            }}
          >
            <span
              style={{
                display: "inline-block",
                width: 3,
                height: 20,
                borderRadius: 2,
                background: `linear-gradient(180deg, #a78bfa 0%, ${ACCENT} 100%)`,
              }}
            />
            <h2
              style={{
                fontSize: 16,
                fontWeight: 700,
                color: "#fff",
                letterSpacing: "-0.02em",
              }}
            >
              Recommended For You
            </h2>
          </div>

          <div
            style={{
              display: "flex",
              gap: 14,
              overflowX: "auto",
              scrollbarWidth: "none",
              paddingBottom: 10,
            }}
          >
            {similar.slice(0, 20).map((item: any) => (
              <div key={item.id} style={{ flexShrink: 0 }}>
                <MediaCard item={item} width={162} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Back link */}
      <div
        className="max-w-[1400px] mx-auto"
        style={{ padding: "0 28px 40px" }}
      >
        <Link
          href="/series"
          style={{
            fontSize: 12,
            color: "rgba(255,255,255,0.28)",
            textDecoration: "none",
          }}
        >
          ← Back to Series
        </Link>
      </div>
    </div>
  );
}
