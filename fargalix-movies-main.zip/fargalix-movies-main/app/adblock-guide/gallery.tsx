"use client";

import { useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

const IMAGES = [
    "https://lh3.googleusercontent.com/88e37aB_E34BxLbmSHPxToFEEpl3ugHtf_31P7zvtyckQAObPJRmLJmeXFHDM8LGySmkg0K728QS3fE0Zv-4XBjk=s1280-w1280-h800",
    "https://lh3.googleusercontent.com/CS1wbRgw8yhuN5IOvHuE7fZctG_m08TFVsISzayWZB1dw2wvPbkocdGBaR9P5-sbfq0DDSLOhaM0DwQqYClURq3f7w=s1280-w1280-h800",
    "https://lh3.googleusercontent.com/auKxBQLuzIWWO-uam1UTe-ANIPtHNQQw8gkbLOQRGPa5JRvJinnRHnl9Lemi2vSJwG0Kf20JXVRUfKYL85X6pzs_5g=s1280-w1280-h800"
];

export function AdBlockGallery() {
    const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

    const handlePrev = (e: React.MouseEvent) => {
        e.stopPropagation();
        setSelectedIndex(prev => (prev === null ? null : (prev === 0 ? IMAGES.length - 1 : prev - 1)));
    };

    const handleNext = (e: React.MouseEvent) => {
        e.stopPropagation();
        setSelectedIndex(prev => (prev === null ? null : (prev === IMAGES.length - 1 ? 0 : prev + 1)));
    };

    return (
        <>
            {/* Image Gallery */}
            <div style={{
                marginTop: 32, display: "grid", gap: 20,
                gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))"
            }}>
                {IMAGES.map((src, i) => (
                    <div
                        key={i}
                        onClick={() => setSelectedIndex(i)}
                        style={{
                            position: "relative",
                            aspectRatio: "1280/800",
                            borderRadius: 16,
                            overflow: "hidden",
                            border: "1px solid rgba(255, 255, 255, 0.08)",
                            boxShadow: "0 12px 32px rgba(0,0,0,0.5)",
                            background: "rgba(20, 24, 38, 0.6)",
                            cursor: "zoom-in",
                        }}
                        className="group"
                    >
                        <img
                            src={src}
                            alt={`AdBlocker Preview ${i + 1}`}
                            style={{
                                position: "absolute", top: 0, left: 0,
                                width: "100%", height: "100%", objectFit: "cover",
                                transition: "transform 0.3s ease"
                            }}
                            className="group-hover:scale-105"
                        />
                        <div style={{
                            position: "absolute", inset: 0, background: "rgba(0,0,0,0.2)",
                            opacity: 0, transition: "opacity 0.2s"
                        }} className="group-hover:opacity-100" />
                    </div>
                ))}
            </div>

            {/* Lightbox Modal */}
            {selectedIndex !== null && (
                <div
                    onClick={() => setSelectedIndex(null)}
                    style={{
                        position: "fixed", inset: 0, zIndex: 100,
                        background: "rgba(0, 0, 0, 0.85)", backdropFilter: "blur(8px)",
                        display: "flex", alignItems: "center", justifyContent: "center",
                    }}
                    className="animate-in fade-in duration-200"
                >
                    {/* Close Button */}
                    <button
                        onClick={() => setSelectedIndex(null)}
                        style={{
                            position: "absolute", top: 20, right: 20,
                            background: "rgba(255,255,255,0.1)", border: "none", color: "#fff",
                            width: 44, height: 44, borderRadius: "50%",
                            display: "flex", alignItems: "center", justifyContent: "center",
                            cursor: "pointer", zIndex: 101, transition: "all 0.2s"
                        }}
                        className="hover:bg-white/20 hover:scale-110"
                        aria-label="Close modal"
                    >
                        <X size={24} />
                    </button>

                    {/* Left Arrow */}
                    <button
                        onClick={handlePrev}
                        style={{
                            position: "absolute", left: "3%", top: "50%", transform: "translateY(-50%)",
                            background: "rgba(10, 10, 10, 0.5)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff",
                            width: 52, height: 52, borderRadius: "50%",
                            display: "flex", alignItems: "center", justifyContent: "center",
                            cursor: "pointer", zIndex: 101, transition: "all 0.2s",
                            backdropFilter: "blur(4px)"
                        }}
                        className="hover:bg-white/10 hover:scale-110 hidden md:flex"
                        aria-label="Previous image"
                    >
                        <ChevronLeft size={32} />
                    </button>

                    {/* Right Arrow */}
                    <button
                        onClick={handleNext}
                        style={{
                            position: "absolute", right: "3%", top: "50%", transform: "translateY(-50%)",
                            background: "rgba(10, 10, 10, 0.5)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff",
                            width: 52, height: 52, borderRadius: "50%",
                            display: "flex", alignItems: "center", justifyContent: "center",
                            cursor: "pointer", zIndex: 101, transition: "all 0.2s",
                            backdropFilter: "blur(4px)"
                        }}
                        className="hover:bg-white/10 hover:scale-110 hidden md:flex"
                        aria-label="Next image"
                    >
                        <ChevronRight size={32} />
                    </button>

                    {/* Main Image Container */}
                    <div
                        onClick={e => e.stopPropagation()}
                        style={{
                            position: "relative", maxWidth: "90vw", maxHeight: "85vh",
                            borderRadius: 16, overflow: "hidden",
                            boxShadow: "0 24px 64px rgba(0,0,0,0.8)",
                        }}
                        className="animate-in zoom-in-95 duration-300"
                    >
                        <img
                            src={IMAGES[selectedIndex]}
                            alt={`Preview ${selectedIndex + 1}`}
                            style={{
                                maxWidth: "100%", maxHeight: "85vh",
                                objectFit: "contain", display: "block"
                            }}
                        />
                    </div>

                    {/* Mobile Hint */}
                    <div style={{
                        position: "absolute", bottom: 20, left: 0, right: 0,
                        textAlign: "center", color: "rgba(255,255,255,0.5)",
                        fontSize: 12, pointerEvents: "none"
                    }} className="md:hidden">
                        Tap anywhere to close
                    </div>
                </div>
            )}
        </>
    );
}
