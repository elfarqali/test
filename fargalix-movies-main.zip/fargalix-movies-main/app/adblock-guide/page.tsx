import Link from "next/link";
import { ShieldCheck, Info, ExternalLink, Download, Search, CheckCircle2, RefreshCcw, LayoutPanelLeft } from "lucide-react";
import { AdBlockGallery } from "./gallery";
import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "AdBlock Guide",
    description: "Learn how to block annoying pop-up ads and improve your streaming experience.",
};

export default function AdBlockGuidePage() {
    return (
        <div style={{ backgroundColor: "#0b0f1a", minHeight: "100vh", padding: "60px 20px" }}>
            <div className="max-w-[800px] mx-auto">

                {/* Header Section */}
                <div style={{ textAlign: "center", marginBottom: 48 }}>
                    <div style={{
                        width: 80, height: 80, borderRadius: "50%",
                        background: "linear-gradient(135deg, rgba(124,58,237,0.2) 0%, rgba(167,139,250,0.05) 100%)",
                        border: "1px solid rgba(124,58,237,0.3)",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        margin: "0 auto 24px auto", boxShadow: "0 0 32px rgba(124,58,237,0.15)"
                    }}>
                        <ShieldCheck size={40} color="#a78bfa" />
                    </div>

                    <h1 style={{
                        fontSize: "clamp(24px, 5vw, 36px)", fontWeight: 800, color: "#fff",
                        letterSpacing: "-0.02em", marginBottom: 16, lineHeight: 1.2
                    }}>
                        How to Block Pop-up Ads Using<br />
                        <span style={{
                            background: "linear-gradient(135deg, #c4b5fd 0%, #7c3aed 100%)",
                            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
                            backgroundClip: "text"
                        }}>
                            Popup Blocker Extension
                        </span>
                    </h1>

                    <p style={{
                        fontSize: 16, color: "rgba(255,255,255,0.6)", lineHeight: 1.6,
                        maxWidth: 600, margin: "0 auto"
                    }}>
                        While free streaming sources often rely on third-party advertisements, you don&apos;t have to endure intrusive pop-ups. Follow this simple guide to block them completely and enjoy an uninterrupted experience.
                    </p>
                </div>

                {/* Main Content Card */}
                <div style={{
                    background: "rgba(20, 24, 38, 0.6)",
                    border: "1px solid rgba(255, 255, 255, 0.05)",
                    borderRadius: 24, padding: "clamp(24px, 5vw, 40px)",
                    boxShadow: "0 24px 64px rgba(0,0,0,0.4)"
                }}>

                    <h2 style={{
                        fontSize: 20, fontWeight: 700, color: "#e2d9f3",
                        marginBottom: 24, display: "flex", alignItems: "center", gap: 10
                    }}>
                        <LayoutPanelLeft size={20} color="#a78bfa" />
                        Step-by-Step Installation
                    </h2>

                    <div style={{ display: "flex", flexDirection: "column", gap: 24, position: "relative" }}>
                        {/* Connecting line */}
                        <div className="hidden sm:block" style={{
                            position: "absolute", left: 24, top: 40, bottom: 40, width: 2,
                            background: "linear-gradient(to bottom, rgba(124,58,237,0.3), rgba(124,58,237,0.05))",
                            zIndex: 0
                        }} />

                        {[
                            {
                                icon: <ExternalLink size={20} />,
                                title: "Go to the Chrome Web Store",
                                desc: "Open the official Google Chrome Web Store to ensure you install safe, verified extensions."
                            },
                            {
                                icon: <Search size={20} />,
                                title: "Search for 'Popup Blocker - Block Pop-ups'",
                                desc: "Look for the extension with the red shield icon, or seamlessly jump right to it using our safe link below.",
                                action: (
                                    <a
                                        href="https://chromewebstore.google.com/detail/popup-blocker-block-pop-u/ddbjkeokchfmmigaifbkeodfkggofelm?hl=en"
                                        target="_blank" rel="noopener noreferrer"
                                        style={{
                                            display: "inline-flex", alignItems: "center", gap: 8,
                                            padding: "8px 16px", borderRadius: 8,
                                            background: "rgba(124,58,237,0.15)", border: "1px solid rgba(124,58,237,0.3)",
                                            color: "#c4b5fd", fontSize: 13, fontWeight: 600,
                                            textDecoration: "none", marginTop: 12, transition: "all 0.2s"
                                        }}
                                        className="hover:bg-purple-600/30 hover:text-white"
                                    >
                                        Open Web Store Link <ExternalLink size={14} />
                                    </a>
                                )
                            },
                            {
                                icon: <Download size={20} />,
                                title: "Click 'Add to Chrome'",
                                desc: "Click the blue 'Add to Chrome' button located on the right side of the extension's store page."
                            },
                            {
                                icon: <CheckCircle2 size={20} />,
                                title: "Confirm Installation",
                                desc: "A browser prompt will appear asking for permissions. Click 'Add extension' to confirm."
                            },
                            {
                                icon: <ShieldCheck size={20} />,
                                title: "Make Sure the Extension is Enabled",
                                desc: "Look for the red shield icon in your browser's top-right toolbar. Ensure it is toggled 'On'."
                            },
                            {
                                icon: <RefreshCcw size={20} />,
                                title: "Refresh the Website",
                                desc: "Head back to your stream and press F5 (or the refresh button) to reload the page with your new ad-blocker active!"
                            }
                        ].map((step, idx) => (
                            <div key={idx} style={{ display: "flex", gap: 20, position: "relative", zIndex: 1 }}>
                                <div style={{
                                    width: 48, height: 48, borderRadius: "50%", flexShrink: 0,
                                    background: "#0b0f1a", border: "1px solid rgba(124,58,237,0.3)",
                                    display: "flex", alignItems: "center", justifyContent: "center",
                                    color: "#a78bfa", boxShadow: "0 4px 12px rgba(0,0,0,0.5)"
                                }}>
                                    {step.icon}
                                </div>
                                <div style={{ paddingTop: 4 }}>
                                    <h3 style={{ fontSize: 16, fontWeight: 600, color: "#fff", marginBottom: 6 }}>
                                        {idx + 1}. {step.title}
                                    </h3>
                                    <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", lineHeight: 1.5 }}>
                                        {step.desc}
                                    </p>
                                    {step.action}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <AdBlockGallery />

                {/* Note Section */}
                <div style={{
                    marginTop: 32, padding: 24, borderRadius: 16,
                    background: "rgba(59, 130, 246, 0.08)",
                    border: "1px solid rgba(59, 130, 246, 0.2)",
                    display: "flex", gap: 16, alignItems: "flex-start",
                }}>
                    <Info size={24} color="#60a5fa" style={{ flexShrink: 0, marginTop: 2 }} />
                    <div>
                        <h4 style={{ fontSize: 15, fontWeight: 700, color: "#bfdbfe", marginBottom: 6 }}>
                            Important Note
                        </h4>
                        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", lineHeight: 1.5 }}>
                            Some websites may require popups for legitimate reasons, such as logging into specific third-party providers or initializing certain video playback modules. If a website stops working correctly, you can click the extension icon in your browser and choose to <strong style={{ color: "rgba(255,255,255,0.9)" }}>whitelist the site</strong> explicitly to allow necessary popups to function.
                        </p>
                    </div>
                </div>

                <div style={{ textAlign: "center", marginTop: 40 }}>
                    <Link
                        href="/"
                        style={{
                            display: "inline-block", padding: "12px 24px", borderRadius: 8,
                            background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
                            color: "rgba(255,255,255,0.8)", fontSize: 14, fontWeight: 600,
                            textDecoration: "none", transition: "all 0.2s"
                        }}
                        className="hover:bg-white/10 hover:text-white"
                    >
                        Return to Home
                    </Link>
                </div>

            </div>
        </div>
    );
}
