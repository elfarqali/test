import { Suspense } from "react";
import SignInForm from "./form";
import { getSiteName } from "@/lib/settings";

export default async function SignInPage() {
    const siteName = await getSiteName();
    return (
        <Suspense>
            <SignInForm siteName={siteName} />
        </Suspense>
    );
}
