"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/auth/auth-provider";
import AuthHeader from "@/components/auth-header";

export default function SignUpForm({ siteName }: { siteName: string }) {
  const router = useRouter();
  const { refetch } = useAuth();

  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password !== confirm) {
      setError("Passwords do not match.");
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Sign up failed.");
        return;
      }
      refetch();
      router.push("/");
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ width: "100%", maxWidth: 960, display: "flex", flexWrap: "wrap", gap: 48, justifyContent: "center", alignItems: "center" }}>
      {/* Left Column: Benefits */}
      <div style={{ flex: "1 1 340px", padding: "24px 0" }}>
        <h2 style={{ fontSize: 36, fontWeight: 800, color: "#fff", marginBottom: 16, lineHeight: 1.2 }}>
          Join the community
        </h2>
        <p style={{ fontSize: 16, color: "rgba(255,255,255,0.65)", marginBottom: 40, lineHeight: 1.6 }}>
          Create an account to unlock premium features, connect with like-minded individuals, and elevate your experience to the next level.
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: 32 }}>
          {/* Benefit 1 */}
          <div style={{ display: "flex", gap: 16 }}>
            <div style={{ width: 44, height: 44, borderRadius: "50%", background: "rgba(124,58,237,0.15)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, boxShadow: "0 0 15px rgba(124,58,237,0.3)" }}>
              <span style={{ color: "#a78bfa", fontSize: 20 }}>🚀</span>
            </div>
            <div>
              <h4 style={{ color: "#fff", fontSize: 16, fontWeight: 600, margin: "0 0 6px 0", letterSpacing: "0.02em" }}>Fast & Secure</h4>
              <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 14, margin: 0, lineHeight: 1.5 }}>
                Experience lightning-fast performance built with top-tier security standards.
              </p>
            </div>
          </div>

          {/* Benefit 2 */}
          <div style={{ display: "flex", gap: 16 }}>
            <div style={{ width: 44, height: 44, borderRadius: "50%", background: "rgba(124,58,237,0.15)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, boxShadow: "0 0 15px rgba(124,58,237,0.3)" }}>
              <span style={{ color: "#a78bfa", fontSize: 20 }}>🤝</span>
            </div>
            <div>
              <h4 style={{ color: "#fff", fontSize: 16, fontWeight: 600, margin: "0 0 6px 0", letterSpacing: "0.02em" }}>Connect & Engage</h4>
              <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 14, margin: 0, lineHeight: 1.5 }}>
                Interact with other members, share thoughts, and build your digital network.
              </p>
            </div>
          </div>

          {/* Benefit 3 */}
          <div style={{ display: "flex", gap: 16 }}>
            <div style={{ width: 44, height: 44, borderRadius: "50%", background: "rgba(124,58,237,0.15)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, boxShadow: "0 0 15px rgba(124,58,237,0.3)" }}>
              <span style={{ color: "#a78bfa", fontSize: 20 }}>💎</span>
            </div>
            <div>
              <h4 style={{ color: "#fff", fontSize: 16, fontWeight: 600, margin: "0 0 6px 0", letterSpacing: "0.02em" }}>Exclusive Content</h4>
              <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 14, margin: 0, lineHeight: 1.5 }}>
                Get access to premium materials and customized offerings tailored just for you.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Form */}
      <div style={{ flex: "1 1 400px", maxWidth: 420, width: "100%" }}>
        {/* Logo */}
        <AuthHeader subtitle="Create your free account" siteName={siteName} />

        {/* Card */}
        <div
          style={{
            background: "rgba(255,255,255,0.035)",
            border: "1px solid rgba(124,58,237,0.2)",
            borderRadius: 18,
            padding: "36px 32px",
            boxShadow: "0 24px 64px rgba(0,0,0,0.5), 0 0 0 1px rgba(124,58,237,0.08)",
          }}
        >
          <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {error && (
              <div
                style={{
                  padding: "10px 14px",
                  borderRadius: 8,
                  background: "rgba(239,68,68,0.1)",
                  border: "1px solid rgba(239,68,68,0.25)",
                  color: "#fca5a5",
                  fontSize: 13,
                }}
              >
                {error}
              </div>
            )}

            {/* Email */}
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              <label style={labelStyle}>EMAIL</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoComplete="email"
                placeholder="you@example.com"
                style={inputStyle}
              />
            </div>

            {/* Username */}
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              <label style={labelStyle}>USERNAME</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                autoComplete="username"
                placeholder="johndoe"
                style={inputStyle}
              />
              <span style={{ fontSize: 11, color: "rgba(255,255,255,0.25)" }}>
                3–24 chars, letters, numbers, underscores only
              </span>
            </div>

            {/* Password */}
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              <label style={labelStyle}>PASSWORD</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoComplete="new-password"
                placeholder="Min. 8 characters"
                style={inputStyle}
              />
            </div>

            {/* Confirm password */}
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              <label style={labelStyle}>CONFIRM PASSWORD</label>
              <input
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                required
                autoComplete="new-password"
                placeholder="••••••••"
                style={inputStyle}
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              style={{
                marginTop: 6,
                padding: "12px",
                borderRadius: 10,
                background: loading
                  ? "rgba(124,58,237,0.4)"
                  : "linear-gradient(135deg, #7c3aed 0%, #5b21b6 100%)",
                border: "none",
                color: "#fff",
                fontSize: 14,
                fontWeight: 700,
                cursor: loading ? "wait" : "pointer",
                transition: "all 0.15s ease",
                letterSpacing: "0.02em",
              }}
            >
              {loading ? "Creating account…" : "Create Account"}
            </button>
          </form>
        </div>

        <p style={{ marginTop: 22, textAlign: "center", fontSize: 13, color: "rgba(255,255,255,0.35)" }}>
          Already have an account?{" "}
          <Link href="/signin" style={{ color: "#a78bfa", fontWeight: 600, textDecoration: "none" }}>
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 600,
  color: "rgba(255,255,255,0.45)",
  letterSpacing: "0.05em",
};

const inputStyle: React.CSSProperties = {
  padding: "11px 14px",
  borderRadius: 9,
  background: "rgba(255,255,255,0.05)",
  border: "1px solid rgba(255,255,255,0.1)",
  color: "#fff",
  fontSize: 14,
  outline: "none",
  width: "100%",
  boxSizing: "border-box",
  transition: "border-color 0.15s ease",
};
