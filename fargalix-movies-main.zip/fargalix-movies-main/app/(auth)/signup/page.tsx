import { Suspense } from "react";
import SignUpForm from "./form";
import { getSiteName } from "@/lib/settings";

export default async function SignUpPage() {
    const siteName = await getSiteName();
    return (
        <Suspense>
            <SignUpForm siteName={siteName} />
        </Suspense>
    );
}
