import { db } from "@/lib/db";
import { revalidatePath } from "next/cache";
import Link from "next/link";

async function dismissComment(formData: FormData) {
    "use server";
    const commentId = formData.get("commentId")?.toString();
    if (!commentId) return;

    // Approve the comment removing it from moderation queue
    // @ts-ignore
    await db.mediaComment.update({
        where: { id: commentId },
        data: { approved: true } as any
    }).catch(() => { });

    // Delete any active reports since it's now approved
    // @ts-ignore
    await db.commentReport.deleteMany({
        where: { commentId }
    }).catch(() => { });

    revalidatePath("/admin/comments");
}

async function deleteComment(formData: FormData) {
    "use server";
    const commentId = formData.get("commentId")?.toString();
    if (!commentId) return;

    // Delete the comment permanently (Cascades report deleting automatically)
    await db.mediaComment.delete({
        where: { id: commentId }
    }).catch(() => { });

    revalidatePath("/admin/comments");
}

export default async function AdminCommentsModerationPage() {
    // Fetch comments that have NOT been approved (i.e. needing moderation)
    // @ts-ignore
    const comments = await db.mediaComment.findMany({
        where: { approved: false } as any,
        include: {
            user: { select: { username: true } },
            reports: { select: { reason: true, reporter: { select: { username: true } } } }
        } as any,
        orderBy: { createdAt: "desc" }
    });

    return (
        <div>
            <div style={{ marginBottom: 36 }}>
                <h1 style={{ fontSize: 26, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", marginBottom: 4 }}>
                    Comment Moderation
                </h1>
                <p style={{ fontSize: 13, color: "rgba(255,255,255,0.35)" }}>
                    Review new comments and flagged comments across all media.
                </p>
            </div>

            <div style={{ borderRadius: 12, overflow: "hidden", border: "1px solid rgba(255,255,255,0.07)" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                        <tr style={{ background: "rgba(255,255,255,0.04)" }}>
                            <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Author</th>
                            <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Content</th>
                            <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Media / Location</th>
                            <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Reports</th>
                            <th style={{ padding: "12px 16px", textAlign: "right", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {comments.length === 0 ? (
                            <tr>
                                <td colSpan={5} style={{ padding: "24px", textAlign: "center", fontSize: 13, color: "rgba(255,255,255,0.4)" }}>No comments awaiting moderation. Clean queue!</td>
                            </tr>
                        ) : comments.map((c: any, i: number) => (
                            <tr key={c.id} style={{ borderTop: "1px solid rgba(255,255,255,0.05)", background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.015)" }}>
                                <td style={{ padding: "12px 16px", fontSize: 13, color: "#fff", fontWeight: 600 }}>@{c.user.username}</td>
                                <td style={{ padding: "12px 16px", fontSize: 13, color: "rgba(255,255,255,0.7)", maxWidth: 300, wordBreak: "break-word" }}>
                                    {c.body}
                                </td>
                                <td style={{ padding: "12px 16px", fontSize: 13 }}>
                                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                        <span style={{
                                            fontSize: 9, fontWeight: 800, padding: "2px 6px", borderRadius: 4, textTransform: "uppercase",
                                            background: c.mediaType === "MOVIE" ? "rgba(59,130,246,0.15)" : "rgba(168,85,247,0.15)",
                                            color: c.mediaType === "MOVIE" ? "#93c5fd" : "#d8b4fe"
                                        }}>
                                            {c.mediaType}
                                        </span>
                                        <Link
                                            href={`/${c.mediaType === "MOVIE" ? 'movie' : 'series'}/${c.mediaId}`}
                                            target="_blank"
                                            style={{ color: "#a78bfa", textDecoration: "none", fontSize: 12 }}
                                            className="hover:underline hover:text-white"
                                        >
                                            View Page ↗
                                        </Link>
                                    </div>
                                    <div style={{ marginTop: 4, fontSize: 10, color: "rgba(255,255,255,0.3)" }}>Media ID: {c.mediaId}</div>
                                </td>
                                <td style={{ padding: "12px 16px", fontSize: 12 }}>
                                    {c.reports.length > 0 ? (
                                        <div style={{ color: "#fca5a5" }}>
                                            <span style={{ fontWeight: 700 }}>{c.reports.length} Reports</span>
                                            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>
                                                Last: {c.reports[0].reason}
                                            </div>
                                        </div>
                                    ) : (
                                        <span style={{ color: "rgba(255,255,255,0.3)" }}>None (New)</span>
                                    )}
                                </td>
                                <td style={{ padding: "12px 16px", textAlign: "right" }}>
                                    <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                                        <form action={dismissComment}>
                                            <input type="hidden" name="commentId" value={c.id} />
                                            <button type="submit" style={{
                                                padding: "6px 12px", borderRadius: 6,
                                                background: "rgba(255,255,255,0.1)", color: "#fff",
                                                border: "1px solid rgba(255,255,255,0.2)", fontSize: 11, fontWeight: 600, cursor: "pointer"
                                            }} className="hover:bg-white/20">
                                                Approve
                                            </button>
                                        </form>
                                        <form action={deleteComment}>
                                            <input type="hidden" name="commentId" value={c.id} />
                                            <button type="submit" style={{
                                                padding: "6px 12px", borderRadius: 6,
                                                background: "rgba(239,68,68,0.15)", color: "#fca5a5",
                                                border: "1px solid rgba(239,68,68,0.3)", fontSize: 11, fontWeight: 600, cursor: "pointer"
                                            }} className="hover:bg-red-500/30">
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
