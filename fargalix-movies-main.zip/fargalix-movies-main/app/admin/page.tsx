import { db } from "@/lib/db";

const ACCENT = "#7c3aed";

export default async function AdminDashboardPage() {
  const [totalUsers, totalFavorites, totalCW, recentUsers] = await Promise.all([
    db.user.count(),
    db.favorite.count(),
    db.continueWatching.count(),
    db.user.findMany({
      orderBy: { createdAt: "desc" },
      take: 8,
      select: { id: true, username: true, email: true, role: true, banned: true, createdAt: true },
    }),
  ]);

  const stats = [
    { label: "Total Users", value: totalUsers, color: "#a78bfa", isText: false },
    { label: "Saved Favorites", value: totalFavorites, color: "#34d399", isText: false },
    { label: "Continue Watching", value: totalCW, color: "#60a5fa", isText: false },
  ];

  return (
    <div>
      <div style={{ marginBottom: 36 }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", marginBottom: 4 }}>
          Dashboard
        </h1>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.35)" }}>
          Overview of your platform
        </p>
      </div>

      {/* Stats grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: 16, marginBottom: 48 }}>
        {stats.map((s) => (
          <div
            key={s.label}
            style={{
              padding: "24px 20px",
              borderRadius: 14,
              background: "rgba(255,255,255,0.035)",
              border: "1px solid rgba(255,255,255,0.07)",
              boxShadow: "0 4px 16px rgba(0,0,0,0.3)",
            }}
          >
            <p style={{ fontSize: 28, fontWeight: 800, color: s.color, lineHeight: 1 }}>
              {s.isText ? String(s.value).charAt(0).toUpperCase() + String(s.value).slice(1) : s.value.toLocaleString()}
            </p>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.38)", marginTop: 8 }}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* Recent users */}
      <div>
        <h2 style={{ fontSize: 15, fontWeight: 700, color: "#fff", marginBottom: 16, letterSpacing: "-0.02em" }}>
          Recent Users
        </h2>
        <div
          style={{
            borderRadius: 12,
            overflow: "hidden",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "rgba(255,255,255,0.04)" }}>
                {["Username", "Email", "Role", "Joined"].map((h) => (
                  <th key={h} style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", letterSpacing: "0.08em", textTransform: "uppercase" }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recentUsers.map((u: any, i: number) => (
                <tr
                  key={u.id}
                  style={{ borderTop: "1px solid rgba(255,255,255,0.05)", background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.015)" }}
                >
                  <td style={{ padding: "12px 16px", fontSize: 13, color: u.banned ? "rgba(239,68,68,0.7)" : "#e2d9f3", fontWeight: 600 }}>
                    @{u.username}
                    {u.banned && <span style={{ marginLeft: 6, fontSize: 9, color: "#f87171", background: "rgba(239,68,68,0.15)", padding: "1px 5px", borderRadius: 3, fontWeight: 700 }}>BANNED</span>}
                  </td>
                  <td style={{ padding: "12px 16px", fontSize: 12, color: "rgba(255,255,255,0.45)" }}>{u.email}</td>
                  <td style={{ padding: "12px 16px" }}>
                    <span style={{
                      fontSize: 9, fontWeight: 800, letterSpacing: "0.08em", textTransform: "uppercase",
                      color: u.role === "ADMIN" ? "#a78bfa" : "rgba(255,255,255,0.4)",
                      background: u.role === "ADMIN" ? "rgba(124,58,237,0.18)" : "rgba(255,255,255,0.06)",
                      padding: "3px 8px", borderRadius: 4,
                    }}>
                      {u.role}
                    </span>
                  </td>
                  <td style={{ padding: "12px 16px", fontSize: 12, color: "rgba(255,255,255,0.35)" }}>
                    {u.createdAt.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
