"use client";

import { useEffect, useState, useCallback } from "react";
import { Plus, Trash2, Eye, EyeOff, Edit2, Check, X, Megaphone } from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────

type AdPlacement =
    | "HOME_PAGE"
    | "MOVIE_PAGE"
    | "SERIES_PAGE"
    | "VIDEO_PLAYER"
    | "HEADER"
    | "FOOTER"
    | "ALL_PAGES";

type AdPosition = "TOP" | "BOTTOM" | "BEFORE_PLAYER" | "AFTER_PLAYER";

interface Ad {
    id: string;
    name: string;
    code: string;
    placement: AdPlacement;
    position: AdPosition;
    displayOrder: number;
    active: boolean;
    createdAt: string;
}

type FormState = {
    name: string;
    code: string;
    placement: AdPlacement;
    position: AdPosition;
    displayOrder: string;
    active: boolean;
};

const PLACEMENTS: { value: AdPlacement; label: string }[] = [
    { value: "HOME_PAGE", label: "Home Page" },
    { value: "MOVIE_PAGE", label: "Movie Page" },
    { value: "SERIES_PAGE", label: "Series Page" },
    { value: "VIDEO_PLAYER", label: "Video Player" },
    { value: "HEADER", label: "Header" },
    { value: "FOOTER", label: "Footer" },
    { value: "ALL_PAGES", label: "All Pages" },
];

const POSITIONS: { value: AdPosition; label: string }[] = [
    { value: "TOP", label: "Top" },
    { value: "BOTTOM", label: "Bottom" },
    { value: "BEFORE_PLAYER", label: "Before Player" },
    { value: "AFTER_PLAYER", label: "After Player" },
];

const PLACEMENT_COLORS: Record<AdPlacement, string> = {
    HOME_PAGE: "#60a5fa",
    MOVIE_PAGE: "#34d399",
    SERIES_PAGE: "#f59e0b",
    VIDEO_PLAYER: "#f472b6",
    HEADER: "#a78bfa",
    FOOTER: "#94a3b8",
    ALL_PAGES: "#7c3aed",
};

const DEFAULT_FORM: FormState = {
    name: "",
    code: "",
    placement: "HOME_PAGE",
    position: "TOP",
    displayOrder: "0",
    active: true,
};

// ── Main Component ────────────────────────────────────────────────────────────

export default function AdminAdsPage() {
    const [ads, setAds] = useState<Ad[]>([]);
    const [loading, setLoading] = useState(true);

    // Create form
    const [showForm, setShowForm] = useState(false);
    const [form, setForm] = useState<FormState>(DEFAULT_FORM);
    const [creating, setCreating] = useState(false);
    const [createError, setCreateError] = useState("");

    // Filter
    const [filterPlacement, setFilterPlacement] = useState<AdPlacement | "ALL">("ALL");

    // Inline edit
    const [editingId, setEditingId] = useState<string | null>(null);
    const [editState, setEditState] = useState<FormState>(DEFAULT_FORM);
    const [saving, setSaving] = useState(false);

    // Preview
    const [previewId, setPreviewId] = useState<string | null>(null);

    const fetchAds = useCallback(async () => {
        setLoading(true);
        try {
            const res = await fetch("/api/admin/ads");
            const data = await res.json();
            setAds(data.ads ?? []);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { fetchAds(); }, [fetchAds]);

    // ── CRUD ─────────────────────────────────────────────────────────────────

    const handleCreate = async () => {
        if (!form.name.trim() || !form.code.trim()) {
            setCreateError("Name and Ad Code are required.");
            return;
        }
        setCreating(true);
        setCreateError("");
        try {
            const res = await fetch("/api/admin/ads", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    name: form.name.trim(),
                    code: form.code.trim(),
                    placement: form.placement,
                    position: form.position,
                    displayOrder: parseInt(form.displayOrder) || 0,
                    active: form.active,
                }),
            });
            const data = await res.json();
            if (!res.ok) {
                setCreateError(data.error ?? "Failed to create ad.");
                return;
            }
            setForm(DEFAULT_FORM);
            setShowForm(false);
            fetchAds();
        } finally {
            setCreating(false);
        }
    };

    const patch = async (id: string, changes: Partial<Ad>) => {
        await fetch(`/api/admin/ads/${id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(changes),
        });
        fetchAds();
    };

    const handleDelete = async (id: string) => {
        if (!confirm("Delete this ad? This cannot be undone.")) return;
        await fetch(`/api/admin/ads/${id}`, { method: "DELETE" });
        fetchAds();
    };

    const startEdit = (ad: Ad) => {
        setEditingId(ad.id);
        setEditState({
            name: ad.name,
            code: ad.code,
            placement: ad.placement,
            position: ad.position,
            displayOrder: String(ad.displayOrder),
            active: ad.active,
        });
    };

    const saveEdit = async (id: string) => {
        if (!editState.name.trim() || !editState.code.trim()) return;
        setSaving(true);
        await fetch(`/api/admin/ads/${id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                name: editState.name.trim(),
                code: editState.code.trim(),
                placement: editState.placement,
                position: editState.position,
                displayOrder: parseInt(editState.displayOrder) || 0,
                active: editState.active,
            }),
        });
        setSaving(false);
        setEditingId(null);
        fetchAds();
    };

    // ── Filtered listing ──────────────────────────────────────────────────────

    const filteredAds =
        filterPlacement === "ALL"
            ? ads
            : ads.filter((a) => a.placement === filterPlacement);

    // ── Render ───────────────────────────────────────────────────────────────

    return (
        <div>
            {/* Header */}
            <div style={{ marginBottom: 32, display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
                <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 6 }}>
                        <div style={{
                            width: 38, height: 38, borderRadius: 10,
                            background: "rgba(124,58,237,0.18)", border: "1px solid rgba(124,58,237,0.35)",
                            display: "flex", alignItems: "center", justifyContent: "center",
                        }}>
                            <Megaphone size={18} color="#a78bfa" />
                        </div>
                        <h1 style={{ fontSize: 26, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em" }}>
                            Ads Manager
                        </h1>
                    </div>
                    <p style={{ fontSize: 13, color: "rgba(255,255,255,0.35)", marginLeft: 50 }}>
                        Manage advertisement scripts per page placement. Supports HTML, JS, and iframes.
                    </p>
                </div>
                <button
                    onClick={() => { setShowForm(true); setCreateError(""); setForm(DEFAULT_FORM); }}
                    style={{
                        display: "flex", alignItems: "center", gap: 7,
                        padding: "9px 18px", borderRadius: 9,
                        background: "rgba(124,58,237,0.85)",
                        border: "1px solid rgba(124,58,237,0.6)",
                        color: "#fff", fontSize: 13, fontWeight: 700,
                        cursor: "pointer", flexShrink: 0,
                    }}
                >
                    <Plus size={14} />
                    Add Ad Script
                </button>
            </div>

            {/* Stats row */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px,1fr))", gap: 12, marginBottom: 28 }}>
                {[
                    { label: "Total Ads", value: ads.length, color: "#a78bfa" },
                    { label: "Active", value: ads.filter(a => a.active).length, color: "#34d399" },
                    { label: "Inactive", value: ads.filter(a => !a.active).length, color: "#f87171" },
                    { label: "Placements", value: new Set(ads.map(a => a.placement)).size, color: "#60a5fa" },
                ].map((s) => (
                    <div key={s.label} style={{
                        padding: "16px 18px", borderRadius: 12,
                        background: "rgba(255,255,255,0.03)",
                        border: "1px solid rgba(255,255,255,0.07)",
                    }}>
                        <p style={{ fontSize: 24, fontWeight: 800, color: s.color, lineHeight: 1 }}>{s.value}</p>
                        <p style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 6 }}>{s.label}</p>
                    </div>
                ))}
            </div>

            {/* Create Form */}
            {showForm && (
                <div style={{
                    padding: "24px", borderRadius: 14,
                    background: "rgba(124,58,237,0.06)",
                    border: "1px solid rgba(124,58,237,0.28)",
                    marginBottom: 32,
                }}>
                    <h2 style={{ fontSize: 14, fontWeight: 700, color: "#c4b5fd", marginBottom: 22 }}>New Ad Script</h2>

                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                        <div>
                            <label style={labelStyle}>Script Name *</label>
                            <input
                                placeholder="e.g. Google AdSense Banner"
                                value={form.name}
                                onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))}
                                style={inputStyle}
                            />
                        </div>
                        <div>
                            <label style={labelStyle}>Display Order</label>
                            <input
                                type="number"
                                placeholder="0"
                                value={form.displayOrder}
                                onChange={(e) => setForm(f => ({ ...f, displayOrder: e.target.value }))}
                                style={inputStyle}
                            />
                        </div>
                    </div>

                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                        <div>
                            <label style={labelStyle}>Placement Location *</label>
                            <select
                                value={form.placement}
                                onChange={(e) => setForm(f => ({ ...f, placement: e.target.value as AdPlacement }))}
                                style={selectStyle}
                            >
                                {PLACEMENTS.map(p => (
                                    <option key={p.value} value={p.value}>{p.label}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label style={labelStyle}>Position</label>
                            <select
                                value={form.position}
                                onChange={(e) => setForm(f => ({ ...f, position: e.target.value as AdPosition }))}
                                style={selectStyle}
                            >
                                {POSITIONS.map(p => (
                                    <option key={p.value} value={p.value}>{p.label}</option>
                                ))}
                            </select>
                        </div>
                    </div>

                    <div style={{ marginBottom: 16 }}>
                        <label style={labelStyle}>Ad Script Code * (HTML / JS / iframe)</label>
                        <textarea
                            placeholder={'<script async src="https://..."></script>\n<!-- or -->\n<iframe src="..." width="728" height="90"></iframe>'}
                            value={form.code}
                            onChange={(e) => setForm(f => ({ ...f, code: e.target.value }))}
                            rows={6}
                            style={{ ...inputStyle, resize: "vertical", fontFamily: "monospace", fontSize: 12, lineHeight: 1.6 }}
                        />
                    </div>

                    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                        <button
                            onClick={() => setForm(f => ({ ...f, active: !f.active }))}
                            style={{
                                display: "flex", alignItems: "center", gap: 6,
                                padding: "6px 14px", borderRadius: 7,
                                background: form.active ? "rgba(52,211,153,0.15)" : "rgba(255,255,255,0.05)",
                                border: `1px solid ${form.active ? "rgba(52,211,153,0.4)" : "rgba(255,255,255,0.1)"}`,
                                color: form.active ? "#34d399" : "rgba(255,255,255,0.4)",
                                fontSize: 12, fontWeight: 700, cursor: "pointer",
                            }}
                        >
                            {form.active ? <Eye size={12} /> : <EyeOff size={12} />}
                            {form.active ? "Active" : "Inactive"}
                        </button>
                        <span style={{ fontSize: 11, color: "rgba(255,255,255,0.25)" }}>Toggle to activate/deactivate the ad on save</span>
                    </div>

                    {createError && (
                        <p style={{ fontSize: 12, color: "#f87171", marginBottom: 14 }}>{createError}</p>
                    )}

                    <div style={{ display: "flex", gap: 10 }}>
                        <button
                            onClick={handleCreate}
                            disabled={creating}
                            style={{
                                padding: "8px 20px", borderRadius: 8,
                                background: "rgba(124,58,237,0.85)",
                                border: "1px solid rgba(124,58,237,0.6)",
                                color: "#fff", fontSize: 13, fontWeight: 700,
                                cursor: creating ? "not-allowed" : "pointer",
                                opacity: creating ? 0.6 : 1,
                            }}
                        >
                            {creating ? "Creating…" : "Create Ad"}
                        </button>
                        <button
                            onClick={() => { setShowForm(false); setCreateError(""); }}
                            style={{
                                padding: "8px 18px", borderRadius: 8,
                                background: "transparent",
                                border: "1px solid rgba(255,255,255,0.1)",
                                color: "rgba(255,255,255,0.5)",
                                fontSize: 13, fontWeight: 600, cursor: "pointer",
                            }}
                        >
                            Cancel
                        </button>
                    </div>
                </div>
            )}

            {/* Filter tabs */}
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 20 }}>
                <FilterChip
                    label={`All (${ads.length})`}
                    active={filterPlacement === "ALL"}
                    onClick={() => setFilterPlacement("ALL")}
                    color="#7c3aed"
                />
                {PLACEMENTS.map(p => {
                    const count = ads.filter(a => a.placement === p.value).length;
                    if (count === 0) return null;
                    return (
                        <FilterChip
                            key={p.value}
                            label={`${p.label} (${count})`}
                            active={filterPlacement === p.value}
                            onClick={() => setFilterPlacement(p.value)}
                            color={PLACEMENT_COLORS[p.value]}
                        />
                    );
                })}
            </div>

            {/* Ads List */}
            {loading ? (
                <p style={{ fontSize: 13, color: "rgba(255,255,255,0.3)", padding: "40px 0", textAlign: "center" }}>Loading…</p>
            ) : filteredAds.length === 0 ? (
                <div style={{
                    padding: "64px 24px", textAlign: "center", borderRadius: 14,
                    border: "1px dashed rgba(255,255,255,0.1)",
                }}>
                    <Megaphone size={32} color="rgba(255,255,255,0.12)" style={{ margin: "0 auto 12px" }} />
                    <p style={{ fontSize: 14, color: "rgba(255,255,255,0.25)", marginBottom: 6 }}>No ad scripts configured yet.</p>
                    <p style={{ fontSize: 12, color: "rgba(255,255,255,0.15)" }}>
                        Add your first ad script to start displaying ads on your site.
                    </p>
                </div>
            ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {filteredAds.map((ad) => (
                        <div
                            key={ad.id}
                            style={{
                                padding: "18px 20px", borderRadius: 12,
                                background: "rgba(255,255,255,0.03)",
                                border: `1px solid ${ad.active ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.04)"}`,
                                opacity: ad.active ? 1 : 0.55,
                                transition: "all 0.15s ease",
                            }}
                        >
                            {editingId === ad.id ? (
                                /* ── Edit Mode ── */
                                <div>
                                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                                        <div>
                                            <label style={labelStyle}>Script Name</label>
                                            <input
                                                value={editState.name}
                                                onChange={(e) => setEditState(s => ({ ...s, name: e.target.value }))}
                                                style={inputStyle}
                                            />
                                        </div>
                                        <div>
                                            <label style={labelStyle}>Display Order</label>
                                            <input
                                                type="number"
                                                value={editState.displayOrder}
                                                onChange={(e) => setEditState(s => ({ ...s, displayOrder: e.target.value }))}
                                                style={inputStyle}
                                            />
                                        </div>
                                    </div>
                                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                                        <div>
                                            <label style={labelStyle}>Placement</label>
                                            <select
                                                value={editState.placement}
                                                onChange={(e) => setEditState(s => ({ ...s, placement: e.target.value as AdPlacement }))}
                                                style={selectStyle}
                                            >
                                                {PLACEMENTS.map(p => (
                                                    <option key={p.value} value={p.value}>{p.label}</option>
                                                ))}
                                            </select>
                                        </div>
                                        <div>
                                            <label style={labelStyle}>Position</label>
                                            <select
                                                value={editState.position}
                                                onChange={(e) => setEditState(s => ({ ...s, position: e.target.value as AdPosition }))}
                                                style={selectStyle}
                                            >
                                                {POSITIONS.map(p => (
                                                    <option key={p.value} value={p.value}>{p.label}</option>
                                                ))}
                                            </select>
                                        </div>
                                    </div>
                                    <div style={{ marginBottom: 14 }}>
                                        <label style={labelStyle}>Ad Script Code</label>
                                        <textarea
                                            value={editState.code}
                                            onChange={(e) => setEditState(s => ({ ...s, code: e.target.value }))}
                                            rows={5}
                                            style={{ ...inputStyle, resize: "vertical", fontFamily: "monospace", fontSize: 12, lineHeight: 1.6 }}
                                        />
                                    </div>
                                    <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                                        <button
                                            onClick={() => saveEdit(ad.id)}
                                            disabled={saving}
                                            style={{
                                                display: "flex", alignItems: "center", gap: 5,
                                                padding: "6px 14px", borderRadius: 7,
                                                background: "rgba(52,211,153,0.15)",
                                                border: "1px solid rgba(52,211,153,0.3)",
                                                color: "#34d399", fontSize: 12, fontWeight: 700, cursor: "pointer",
                                            }}
                                        >
                                            <Check size={12} />
                                            {saving ? "Saving…" : "Save"}
                                        </button>
                                        <button
                                            onClick={() => setEditingId(null)}
                                            style={{
                                                display: "flex", alignItems: "center", gap: 5,
                                                padding: "6px 14px", borderRadius: 7,
                                                background: "transparent",
                                                border: "1px solid rgba(255,255,255,0.1)",
                                                color: "rgba(255,255,255,0.4)", fontSize: 12, fontWeight: 600, cursor: "pointer",
                                            }}
                                        >
                                            <X size={12} />
                                            Cancel
                                        </button>
                                        <button
                                            onClick={() => setEditState(s => ({ ...s, active: !s.active }))}
                                            style={{
                                                display: "flex", alignItems: "center", gap: 5,
                                                padding: "6px 14px", borderRadius: 7,
                                                background: editState.active ? "rgba(52,211,153,0.1)" : "rgba(255,255,255,0.04)",
                                                border: `1px solid ${editState.active ? "rgba(52,211,153,0.3)" : "rgba(255,255,255,0.1)"}`,
                                                color: editState.active ? "#34d399" : "rgba(255,255,255,0.35)",
                                                fontSize: 12, fontWeight: 700, cursor: "pointer",
                                            }}
                                        >
                                            {editState.active ? <Eye size={12} /> : <EyeOff size={12} />}
                                            {editState.active ? "Active" : "Inactive"}
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                /* ── View Mode ── */
                                <div>
                                    <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
                                        <div style={{ flex: 1, minWidth: 0 }}>
                                            {/* Name + badges */}
                                            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
                                                <span style={{ fontSize: 15, fontWeight: 700, color: "#e2d9f3" }}>{ad.name}</span>
                                                <PlacementBadge placement={ad.placement} />
                                                <PositionBadge position={ad.position} />
                                                {!ad.active && (
                                                    <span style={{
                                                        fontSize: 10, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase",
                                                        color: "rgba(255,255,255,0.3)", background: "rgba(255,255,255,0.06)",
                                                        border: "1px solid rgba(255,255,255,0.1)", padding: "2px 8px", borderRadius: 8,
                                                    }}>INACTIVE</span>
                                                )}
                                                <span style={{ fontSize: 10, color: "rgba(255,255,255,0.22)" }}>
                                                    order: {ad.displayOrder}
                                                </span>
                                            </div>

                                            {/* Code preview */}
                                            {previewId === ad.id ? (
                                                <div>
                                                    <pre style={{
                                                        fontSize: 11, color: "rgba(255,255,255,0.55)",
                                                        background: "rgba(0,0,0,0.3)", borderRadius: 8, padding: "12px 14px",
                                                        overflowX: "auto", whiteSpace: "pre-wrap", wordBreak: "break-all",
                                                        fontFamily: "monospace", lineHeight: 1.6, maxHeight: 200,
                                                        border: "1px solid rgba(255,255,255,0.07)",
                                                    }}>
                                                        {ad.code}
                                                    </pre>
                                                    <button
                                                        onClick={() => setPreviewId(null)}
                                                        style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", background: "none", border: "none", cursor: "pointer", marginTop: 6 }}
                                                    >
                                                        ▲ Hide code
                                                    </button>
                                                </div>
                                            ) : (
                                                <button
                                                    onClick={() => setPreviewId(ad.id)}
                                                    style={{
                                                        fontSize: 11, color: "rgba(255,255,255,0.3)", background: "none", border: "none",
                                                        cursor: "pointer", display: "flex", alignItems: "center", gap: 4, padding: 0,
                                                    }}
                                                >
                                                    ▼ View code ({ad.code.length} chars)
                                                </button>
                                            )}
                                        </div>

                                        {/* Actions */}
                                        <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                                            <button onClick={() => startEdit(ad)} title="Edit" style={iconBtnStyle}>
                                                <Edit2 size={13} />
                                            </button>
                                            <button
                                                onClick={() => patch(ad.id, { active: !ad.active })}
                                                title={ad.active ? "Deactivate" : "Activate"}
                                                style={{ ...iconBtnStyle, color: ad.active ? "#34d399" : "rgba(255,255,255,0.3)" }}
                                            >
                                                {ad.active ? <Eye size={13} /> : <EyeOff size={13} />}
                                            </button>
                                            <button
                                                onClick={() => handleDelete(ad.id)}
                                                title="Delete"
                                                style={{ ...iconBtnStyle, color: "rgba(248,113,113,0.7)" }}
                                            >
                                                <Trash2 size={13} />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}

            {/* Info box */}
            {ads.length > 0 && (
                <div style={{
                    marginTop: 28, padding: "16px 18px", borderRadius: 10,
                    background: "rgba(255,255,255,0.02)",
                    border: "1px solid rgba(255,255,255,0.06)",
                    fontSize: 12, color: "rgba(255,255,255,0.3)", lineHeight: 1.8,
                }}>
                    <strong style={{ color: "rgba(255,255,255,0.5)" }}>How it works:</strong> Ad scripts are injected into pages using
                    the <code style={{ color: "#c4b5fd" }}>AdSlot</code> component.
                    Ads set to <code style={{ color: "#60a5fa" }}>All Pages</code> render globally everywhere.
                    Use <code style={{ color: "#a78bfa" }}>Display Order</code> to control priority (lower number = shown first).
                    Inactive ads are hidden from all pages without being deleted.
                </div>
            )}
        </div>
    );
}

// ── Sub-components ────────────────────────────────────────────────────────────

function FilterChip({ label, active, onClick, color }: { label: string; active: boolean; onClick: () => void; color: string }) {
    return (
        <button
            onClick={onClick}
            style={{
                padding: "5px 12px", borderRadius: 20, fontSize: 11, fontWeight: 600, cursor: "pointer",
                background: active ? `${color}22` : "rgba(255,255,255,0.03)",
                border: `1px solid ${active ? `${color}66` : "rgba(255,255,255,0.08)"}`,
                color: active ? color : "rgba(255,255,255,0.4)",
                transition: "all 0.15s ease",
            }}
        >
            {label}
        </button>
    );
}

function PlacementBadge({ placement }: { placement: AdPlacement }) {
    const label = PLACEMENTS.find(p => p.value === placement)?.label ?? placement;
    const color = PLACEMENT_COLORS[placement];
    return (
        <span style={{
            fontSize: 10, fontWeight: 700, letterSpacing: "0.05em",
            color, background: `${color}1a`, border: `1px solid ${color}44`,
            padding: "2px 8px", borderRadius: 8, textTransform: "uppercase",
        }}>
            {label}
        </span>
    );
}

function PositionBadge({ position }: { position: AdPosition }) {
    const label = POSITIONS.find(p => p.value === position)?.label ?? position;
    return (
        <span style={{
            fontSize: 10, fontWeight: 600, color: "rgba(255,255,255,0.4)",
            background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.09)",
            padding: "2px 7px", borderRadius: 8,
        }}>
            {label}
        </span>
    );
}

// ── Styles ────────────────────────────────────────────────────────────────────

const labelStyle: React.CSSProperties = {
    display: "block",
    fontSize: 11,
    fontWeight: 600,
    color: "rgba(255,255,255,0.4)",
    letterSpacing: "0.06em",
    textTransform: "uppercase",
    marginBottom: 5,
};

const inputStyle: React.CSSProperties = {
    width: "100%",
    boxSizing: "border-box",
    padding: "9px 12px",
    borderRadius: 8,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.1)",
    color: "#fff",
    fontSize: 13,
    outline: "none",
    fontFamily: "inherit",
};

const selectStyle: React.CSSProperties = {
    ...inputStyle,
    cursor: "pointer",
    appearance: "none" as const,
    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' fill='none'%3E%3Cpath d='M1 1l5 5 5-5' stroke='rgba(255,255,255,0.3)' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
    backgroundRepeat: "no-repeat",
    backgroundPosition: "right 12px center",
    paddingRight: 36,
};

const iconBtnStyle: React.CSSProperties = {
    width: 30, height: 30,
    display: "flex", alignItems: "center", justifyContent: "center",
    borderRadius: 7,
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "rgba(255,255,255,0.45)",
    cursor: "pointer",
    transition: "all 0.15s ease",
};
