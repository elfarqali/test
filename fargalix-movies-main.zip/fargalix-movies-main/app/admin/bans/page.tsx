import { db } from "@/lib/db";
import { revalidatePath } from "next/cache";

async function banUser(formData: FormData) {
    "use server";
    const username = formData.get("username")?.toString();
    const reason = formData.get("reason")?.toString();
    if (!username || !reason) return;

    const user = await db.user.findUnique({ where: { username } });
    if (!user) return;

    await db.user.update({
        where: { id: user.id },
        data: { banned: true }
    });

    // @ts-ignore
    await db.userBan.upsert({
        where: { userId: user.id },
        update: { reason },
        create: { userId: user.id, reason }
    });

    revalidatePath("/admin/bans");
}

async function unbanUser(formData: FormData) {
    "use server";
    const userId = formData.get("userId")?.toString();
    if (!userId) return;

    await db.user.update({
        where: { id: userId },
        data: { banned: false }
    });

    // @ts-ignore
    await db.userBan.delete({
        where: { userId }
    }).catch(() => { });

    revalidatePath("/admin/bans");
}

export default async function AdminBansPage() {
    // @ts-ignore
    const bans = await db.userBan.findMany({
        include: {
            user: {
                select: { username: true, email: true }
            }
        },
        orderBy: { createdAt: "desc" }
    });

    return (
        <div>
            <div style={{ marginBottom: 36 }}>
                <h1 style={{ fontSize: 26, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", marginBottom: 4 }}>
                    Banned Users
                </h1>
                <p style={{ fontSize: 13, color: "rgba(255,255,255,0.35)" }}>
                    Manage user bans and restrictions.
                </p>
            </div>

            <div style={{
                background: "rgba(255,255,255,0.035)",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 14, padding: "24px", marginBottom: 36
            }}>
                <h2 style={{ fontSize: 16, fontWeight: 700, color: "#e2d9f3", marginBottom: 16 }}>Ban User</h2>
                <form action={banUser} style={{ display: "flex", gap: 12, alignItems: "flex-end", flexWrap: "wrap" }}>
                    <div style={{ flex: 1, minWidth: 200 }}>
                        <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.45)", marginBottom: 6 }}>USERNAME</label>
                        <input name="username" placeholder="Target username..." required style={{
                            width: "100%", padding: "10px 14px", borderRadius: 8,
                            background: "rgba(0,0,0,0.2)", border: "1px solid rgba(255,255,255,0.1)",
                            color: "#fff", fontSize: 14, outline: "none"
                        }} />
                    </div>
                    <div style={{ flex: 2, minWidth: 250 }}>
                        <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.45)", marginBottom: 6 }}>REASON</label>
                        <input name="reason" placeholder="Why are they being banned?" required style={{
                            width: "100%", padding: "10px 14px", borderRadius: 8,
                            background: "rgba(0,0,0,0.2)", border: "1px solid rgba(255,255,255,0.1)",
                            color: "#fff", fontSize: 14, outline: "none"
                        }} />
                    </div>
                    <button type="submit" style={{
                        padding: "10px 20px", borderRadius: 8,
                        background: "linear-gradient(135deg, #ef4444 0%, #b91c1c 100%)",
                        color: "#fff", border: "none", fontWeight: 700, cursor: "pointer", height: 40
                    }}>
                        Ban
                    </button>
                </form>
            </div>

            <div>
                <h2 style={{ fontSize: 15, fontWeight: 700, color: "#fff", marginBottom: 16 }}>Active Bans</h2>
                <div style={{ borderRadius: 12, overflow: "hidden", border: "1px solid rgba(255,255,255,0.07)" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                            <tr style={{ background: "rgba(255,255,255,0.04)" }}>
                                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>User</th>
                                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Reason</th>
                                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Date</th>
                                <th style={{ padding: "12px 16px", textAlign: "right", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {bans.length === 0 ? (
                                <tr>
                                    <td colSpan={4} style={{ padding: "24px", textAlign: "center", fontSize: 13, color: "rgba(255,255,255,0.4)" }}>No banned users found.</td>
                                </tr>
                            ) : bans.map((ban: any, i: number) => (
                                <tr key={ban.id} style={{ borderTop: "1px solid rgba(255,255,255,0.05)", background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.015)" }}>
                                    <td style={{ padding: "12px 16px", fontSize: 13, color: "#fff", fontWeight: 600 }}>@{ban.user.username}</td>
                                    <td style={{ padding: "12px 16px", fontSize: 13, color: "#fca5a5" }}>{ban.reason}</td>
                                    <td style={{ padding: "12px 16px", fontSize: 12, color: "rgba(255,255,255,0.45)" }}>{ban.createdAt.toLocaleDateString()}</td>
                                    <td style={{ padding: "12px 16px", textAlign: "right" }}>
                                        <form action={unbanUser}>
                                            <input type="hidden" name="userId" value={ban.userId} />
                                            <button type="submit" style={{
                                                padding: "6px 12px", borderRadius: 6,
                                                background: "rgba(255,255,255,0.1)", color: "#fff",
                                                border: "1px solid rgba(255,255,255,0.2)", fontSize: 11, fontWeight: 600, cursor: "pointer"
                                            }}>
                                                Unban
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
