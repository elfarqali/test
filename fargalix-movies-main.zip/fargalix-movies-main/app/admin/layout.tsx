import Link from "next/link";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { db } from "@/lib/db";

const BG = "#0b0f1a";
const SIDEBAR_BG = "#0e1322";

const navItems = [
  { href: "/admin", label: "Dashboard", icon: "⬡" },
  { href: "/admin/users", label: "Users", icon: "◻" },
  { href: "/admin/notifications", label: "Notifications", icon: "◉" },
  { href: "/admin/players", label: "Players", icon: "▶" },
  { href: "/admin/ads", label: "Ads Manager", icon: "📢" },
  { href: "/admin/settings", label: "Settings", icon: "◈" },
  { href: "/admin/bans", label: "Banned Users", icon: "✖" },
  { href: "/admin/comments", label: "Comment Moderation", icon: "💬" },
  { href: "/admin/reports/videos", label: "Video Reports", icon: "📹" },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") redirect("/");

  const siteNameRecord = await db.siteSetting.findUnique({
    where: { key: "site_name" },
  });
  const siteName = siteNameRecord?.value || "STREAMVAULT";

  return (
    <div style={{ display: "flex", minHeight: "100vh", backgroundColor: BG, color: "#fff" }}>
      {/* ── Sidebar ───────────────────────────────────────────────────────── */}
      <aside
        style={{
          width: 220,
          flexShrink: 0,
          backgroundColor: SIDEBAR_BG,
          borderRight: "1px solid rgba(124,58,237,0.15)",
          display: "flex",
          flexDirection: "column",
          padding: "24px 0",
          position: "sticky",
          top: 0,
          height: "100vh",
          overflowY: "auto",
        }}
      >
        {/* Branding */}
        <div style={{ padding: "0 20px 24px", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
          <Link href="/" style={{ textDecoration: "none" }}>
            <span
              style={{
                fontSize: 11,
                fontWeight: 900,
                letterSpacing: "0.18em",
                textTransform: "uppercase",
                background: "linear-gradient(135deg, #c4b5fd 0%, #7c3aed 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              {siteName.toUpperCase()}
            </span>
          </Link>
          <p style={{ marginTop: 4, fontSize: 10, color: "rgba(255,255,255,0.25)", letterSpacing: "0.12em", textTransform: "uppercase" }}>
            Admin Panel
          </p>
        </div>

        {/* Nav */}
        <nav style={{ padding: "16px 10px", flex: 1 }}>
          {navItems.map(({ href, label, icon }) => (
            <Link
              key={href}
              href={href}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                padding: "9px 12px",
                borderRadius: 8,
                fontSize: 13,
                fontWeight: 500,
                color: "rgba(255,255,255,0.55)",
                textDecoration: "none",
                marginBottom: 2,
                transition: "all 0.15s ease",
              }}
              className="hover:bg-white/5 hover:text-white/90"
            >
              <span style={{ fontSize: 14, color: "#a78bfa" }}>{icon}</span>
              {label}
            </Link>
          ))}
        </nav>

        {/* Back to site */}
        <div style={{ padding: "16px 10px", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
          <Link
            href="/"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: "9px 12px",
              borderRadius: 8,
              fontSize: 12,
              color: "rgba(255,255,255,0.3)",
              textDecoration: "none",
            }}
            className="hover:text-white/60"
          >
            ← Back to site
          </Link>
        </div>
      </aside>

      {/* ── Main ──────────────────────────────────────────────────────────── */}
      <main style={{ flex: 1, padding: "40px 36px", overflowY: "auto", minWidth: 0 }}>
        {children}
      </main>
    </div>
  );
}
