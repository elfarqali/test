import { db } from "@/lib/db";
import { revalidatePath } from "next/cache";
import Link from "next/link";

async function dismissVideoReport(formData: FormData) {
    "use server";
    const reportId = formData.get("reportId")?.toString();
    if (!reportId) return;

    // @ts-ignore
    await db.videoReport.delete({
        where: { id: reportId }
    }).catch(() => { });

    revalidatePath("/admin/reports/videos");
}

export default async function AdminVideoReportsPage() {
    // @ts-ignore
    const reports = await db.videoReport.findMany({
        include: {
            reporter: { select: { username: true } },
        },
        orderBy: { createdAt: "desc" }
    });

    return (
        <div>
            <div style={{ marginBottom: 36 }}>
                <h1 style={{ fontSize: 26, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", marginBottom: 4 }}>
                    Video/Stream Reports
                </h1>
                <p style={{ fontSize: 13, color: "rgba(255,255,255,0.35)" }}>
                    Review user reports about broken videos, streams, or playback issues.
                </p>
            </div>

            <div style={{ borderRadius: 12, overflow: "hidden", border: "1px solid rgba(255,255,255,0.07)" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                        <tr style={{ background: "rgba(255,255,255,0.04)" }}>
                            <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Reporter</th>
                            <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Type</th>
                            <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Media ID / Check Link</th>
                            <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Issue Reason</th>
                            <th style={{ padding: "12px 16px", textAlign: "right", fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {reports.length === 0 ? (
                            <tr>
                                <td colSpan={5} style={{ padding: "24px", textAlign: "center", fontSize: 13, color: "rgba(255,255,255,0.4)" }}>No video reports.</td>
                            </tr>
                        ) : reports.map((r: any, i: number) => (
                            <tr key={r.id} style={{ borderTop: "1px solid rgba(255,255,255,0.05)", background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.015)" }}>
                                <td style={{ padding: "12px 16px", fontSize: 13, color: "#fff", fontWeight: 600 }}>@{r.reporter.username}</td>
                                <td style={{ padding: "12px 16px" }}>
                                    <span style={{
                                        fontSize: 9, fontWeight: 800, padding: "2px 6px", borderRadius: 4, textTransform: "uppercase",
                                        background: r.mediaType === "MOVIE" ? "rgba(59,130,246,0.15)" : "rgba(168,85,247,0.15)",
                                        color: r.mediaType === "MOVIE" ? "#93c5fd" : "#d8b4fe"
                                    }}>
                                        {r.mediaType}
                                    </span>
                                </td>
                                <td style={{ padding: "12px 16px", fontSize: 13 }}>
                                    <Link
                                        href={r.mediaType === "MOVIE" ? `/movie/${r.mediaId}` : `/tv/${r.mediaId}${r.season && r.episode ? `?season=${r.season}&episode=${r.episode}` : ''}`}
                                        target="_blank"
                                        style={{ color: "#a78bfa", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 4 }}
                                        className="hover:underline hover:text-white"
                                    >
                                        Load Item ↗
                                    </Link>
                                    <span style={{ marginLeft: 8, display: "inline-block" }}>
                                        <span style={{ fontSize: 10, color: "rgba(255,255,255,0.3)" }}>ID: {r.mediaId}</span>
                                        {r.mediaType === "TV" && r.season && r.episode && (
                                            <span style={{ marginLeft: 6, fontSize: 10, fontWeight: 700, color: "#94a3b8" }}>
                                                · S{r.season} E{r.episode}
                                            </span>
                                        )}
                                    </span>
                                </td>
                                <td style={{ padding: "12px 16px", fontSize: 13, color: "#fca5a5", maxWidth: 200, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                                    {r.reason}
                                </td>
                                <td style={{ padding: "12px 16px", textAlign: "right" }}>
                                    <form action={dismissVideoReport}>
                                        <input type="hidden" name="reportId" value={r.id} />
                                        <button type="submit" style={{
                                            padding: "6px 12px", borderRadius: 6,
                                            background: "rgba(255,255,255,0.1)", color: "#fff",
                                            border: "1px solid rgba(255,255,255,0.2)", fontSize: 11, fontWeight: 600, cursor: "pointer"
                                        }}>
                                            Dismiss
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
