"use client";

import { useEffect, useState, useCallback } from "react";
import { Search, ShieldOff, Shield, Trash2, ShieldCheck, TrendingUp } from "lucide-react";

interface AdminUser {
  id: string;
  email: string;
  username: string;
  role: "USER" | "ADMIN";
  banned: boolean;
  bonusMinutes: number;
  level: number;
  createdAt: string;
  _count: { favorites: number; continueWatching: number };
}

export default function AdminUsersPage() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page) });
      if (search) params.set("search", search);
      const res = await fetch(`/api/admin/users?${params}`);
      const data = await res.json();
      setUsers(data.users ?? []);
      setTotal(data.total ?? 0);
      setTotalPages(data.totalPages ?? 1);
    } finally {
      setLoading(false);
    }
  }, [page, search]);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const patch = async (id: string, body: object) => {
    setActionLoading(id);
    try {
      const res = await fetch(`/api/admin/users/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        const data = await res.json();
        setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, ...data.user } : u)));
      }
    } finally {
      setActionLoading(null);
    }
  };

  const increaseLevel = async (id: string) => {
    setActionLoading(id + "_level");
    try {
      const res = await fetch(`/api/admin/users/${id}/level`, { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, level: data.level } : u)));
      }
    } finally {
      setActionLoading(null);
    }
  };

  const deleteUser = async (id: string) => {
    setActionLoading(id);
    try {
      const res = await fetch(`/api/admin/users/${id}`, { method: "DELETE" });
      if (res.ok) {
        setUsers((prev) => prev.filter((u) => u.id !== id));
        setTotal((t) => t - 1);
      }
    } finally {
      setActionLoading(null);
      setConfirmDelete(null);
    }
  };

  return (
    <div>
      <div style={{ marginBottom: 32 }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", marginBottom: 4 }}>
          Users
        </h1>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.35)" }}>
          {total.toLocaleString()} total users
        </p>
      </div>

      {/* Search */}
      <div style={{ position: "relative", maxWidth: 340, marginBottom: 28 }}>
        <Search
          size={14}
          style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "rgba(255,255,255,0.3)" }}
        />
        <input
          placeholder="Search by email or username…"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          style={{
            width: "100%", boxSizing: "border-box",
            padding: "9px 12px 9px 34px",
            borderRadius: 9,
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.1)",
            color: "#fff",
            fontSize: 13,
            outline: "none",
          }}
        />
      </div>

      {/* Table */}
      <div style={{ borderRadius: 12, overflow: "hidden", border: "1px solid rgba(255,255,255,0.07)" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "rgba(255,255,255,0.04)" }}>
              {["User", "Role", "Level", "Stats", "Joined", "Actions"].map((h) => (
                <th key={h} style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.35)", letterSpacing: "0.08em", textTransform: "uppercase" }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={6} style={{ padding: "40px", textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: 13 }}>
                  Loading…
                </td>
              </tr>
            ) : users.length === 0 ? (
              <tr>
                <td colSpan={6} style={{ padding: "40px", textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: 13 }}>
                  No users found.
                </td>
              </tr>
            ) : (
              users.map((u, i) => (
                <tr
                  key={u.id}
                  style={{
                    borderTop: "1px solid rgba(255,255,255,0.05)",
                    background: u.banned ? "rgba(239,68,68,0.04)" : i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.015)",
                    opacity: actionLoading === u.id ? 0.5 : 1,
                  }}
                >
                  {/* User info */}
                  <td style={{ padding: "12px 16px" }}>
                    <p style={{ fontSize: 13, fontWeight: 600, color: u.banned ? "#f87171" : "#e2d9f3" }}>
                      @{u.username}
                      {u.banned && (
                        <span style={{ marginLeft: 6, fontSize: 9, color: "#f87171", background: "rgba(239,68,68,0.15)", padding: "1px 5px", borderRadius: 3, fontWeight: 700 }}>
                          BANNED
                        </span>
                      )}
                    </p>
                    <p style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>{u.email}</p>
                  </td>

                  {/* Role */}
                  <td style={{ padding: "12px 16px" }}>
                    <span style={{
                      fontSize: 9, fontWeight: 800, letterSpacing: "0.08em", textTransform: "uppercase",
                      color: u.role === "ADMIN" ? "#a78bfa" : "rgba(255,255,255,0.4)",
                      background: u.role === "ADMIN" ? "rgba(124,58,237,0.18)" : "rgba(255,255,255,0.06)",
                      padding: "3px 8px", borderRadius: 4,
                    }}>
                      {u.role}
                    </span>
                  </td>

                  {/* Level */}
                  <td style={{ padding: "12px 16px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{
                        fontSize: 12, fontWeight: 700,
                        color: "#c4b5fd",
                        background: "rgba(124,58,237,0.14)",
                        border: "1px solid rgba(124,58,237,0.28)",
                        padding: "2px 8px", borderRadius: 4,
                        minWidth: 32, textAlign: "center",
                      }}>
                        {u.level}
                      </span>
                      <button
                        title="Increase level by 1"
                        onClick={() => increaseLevel(u.id)}
                        disabled={actionLoading === u.id + "_level"}
                        style={{
                          ...iconBtnStyle,
                          color: "#34d399",
                          opacity: actionLoading === u.id + "_level" ? 0.5 : 1,
                        }}
                      >
                        <TrendingUp size={13} />
                      </button>
                    </div>
                  </td>

                  {/* Stats */}
                  <td style={{ padding: "12px 16px", fontSize: 12, color: "rgba(255,255,255,0.4)" }}>
                    ♥ {u._count.favorites} · ▶ {u._count.continueWatching}
                  </td>

                  {/* Joined */}
                  <td style={{ padding: "12px 16px", fontSize: 12, color: "rgba(255,255,255,0.35)" }}>
                    {new Date(u.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })}
                  </td>

                  {/* Actions */}
                  <td style={{ padding: "12px 16px" }}>
                    {confirmDelete === u.id ? (
                      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                        <span style={{ fontSize: 11, color: "#f87171" }}>Confirm delete?</span>
                        <button onClick={() => deleteUser(u.id)} style={dangerBtnStyle}>Yes</button>
                        <button onClick={() => setConfirmDelete(null)} style={ghostBtnStyle}>No</button>
                      </div>
                    ) : (
                      <div style={{ display: "flex", gap: 6 }}>
                        {/* Ban / Unban */}
                        <button
                          title={u.banned ? "Unban user" : "Ban user"}
                          onClick={() => patch(u.id, { banned: !u.banned })}
                          disabled={actionLoading === u.id}
                          style={{ ...iconBtnStyle, color: u.banned ? "#34d399" : "#f87171" }}
                        >
                          {u.banned ? <Shield size={14} /> : <ShieldOff size={14} />}
                        </button>

                        {/* Promote / Demote */}
                        <button
                          title={u.role === "ADMIN" ? "Remove admin" : "Make admin"}
                          onClick={() => patch(u.id, { role: u.role === "ADMIN" ? "USER" : "ADMIN" })}
                          disabled={actionLoading === u.id}
                          style={{ ...iconBtnStyle, color: u.role === "ADMIN" ? "#f59e0b" : "#a78bfa" }}
                        >
                          <ShieldCheck size={14} />
                        </button>

                        {/* Delete */}
                        <button
                          title="Delete user"
                          onClick={() => setConfirmDelete(u.id)}
                          disabled={actionLoading === u.id}
                          style={{ ...iconBtnStyle, color: "rgba(239,68,68,0.7)" }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 24 }}>
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            style={{ ...paginationBtnStyle, opacity: page === 1 ? 0.4 : 1 }}
          >
            ← Prev
          </button>
          <span style={{ padding: "6px 12px", fontSize: 12, color: "rgba(255,255,255,0.4)" }}>
            {page} / {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            style={{ ...paginationBtnStyle, opacity: page === totalPages ? 0.4 : 1 }}
          >
            Next →
          </button>
        </div>
      )}
    </div>
  );
}

const iconBtnStyle: React.CSSProperties = {
  padding: "5px 7px",
  borderRadius: 6,
  border: "1px solid rgba(255,255,255,0.08)",
  background: "transparent",
  cursor: "pointer",
  display: "inline-flex",
  alignItems: "center",
  transition: "all 0.12s ease",
};

const ghostBtnStyle: React.CSSProperties = {
  padding: "4px 10px",
  borderRadius: 6,
  border: "1px solid rgba(255,255,255,0.1)",
  background: "transparent",
  color: "rgba(255,255,255,0.5)",
  fontSize: 11,
  cursor: "pointer",
};

const dangerBtnStyle: React.CSSProperties = {
  padding: "4px 10px",
  borderRadius: 6,
  border: "1px solid rgba(239,68,68,0.4)",
  background: "rgba(239,68,68,0.15)",
  color: "#f87171",
  fontSize: 11,
  cursor: "pointer",
};

const paginationBtnStyle: React.CSSProperties = {
  padding: "6px 14px",
  borderRadius: 7,
  border: "1px solid rgba(255,255,255,0.1)",
  background: "transparent",
  color: "rgba(255,255,255,0.55)",
  fontSize: 12,
  cursor: "pointer",
};
