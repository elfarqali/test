"use client";

import { useEffect, useState, useCallback } from "react";
import { Plus, Trash2, Star, StarOff, Eye, EyeOff, Edit2, Check, X } from "lucide-react";

interface Player {
  id: string;
  name: string;
  movieUrl: string;
  tvUrl: string;
  isDefault: boolean;
  active: boolean;
  order: number;
  createdAt: string;
}

type EditingState = {
  name: string;
  movieUrl: string;
  tvUrl: string;
  order: string;
};

export default function AdminPlayersPage() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);

  // Create form
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", movieUrl: "", tvUrl: "", order: "0" });
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState("");

  // Inline edit
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editState, setEditState] = useState<EditingState>({ name: "", movieUrl: "", tvUrl: "", order: "0" });
  const [saving, setSaving] = useState(false);

  const fetchPlayers = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/players");
      const data = await res.json();
      setPlayers(data.players ?? []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchPlayers(); }, [fetchPlayers]);

  const handleCreate = async () => {
    if (!form.name.trim() || !form.movieUrl.trim() || !form.tvUrl.trim()) {
      setCreateError("Name, Movie URL, and TV URL are required.");
      return;
    }
    setCreating(true);
    setCreateError("");
    try {
      const res = await fetch("/api/admin/players", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name.trim(),
          movieUrl: form.movieUrl.trim(),
          tvUrl: form.tvUrl.trim(),
          order: parseInt(form.order) || 0,
          active: true,
          isDefault: players.length === 0, // auto-default if first player
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setCreateError(data.error ?? "Failed to create.");
        return;
      }
      setForm({ name: "", movieUrl: "", tvUrl: "", order: "0" });
      setShowForm(false);
      fetchPlayers();
    } finally {
      setCreating(false);
    }
  };

  const patch = async (id: string, changes: Partial<Player>) => {
    await fetch(`/api/admin/players/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(changes),
    });
    fetchPlayers();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this player? This cannot be undone.")) return;
    await fetch(`/api/admin/players/${id}`, { method: "DELETE" });
    fetchPlayers();
  };

  const startEdit = (p: Player) => {
    setEditingId(p.id);
    setEditState({ name: p.name, movieUrl: p.movieUrl, tvUrl: p.tvUrl, order: String(p.order) });
  };

  const cancelEdit = () => { setEditingId(null); };

  const saveEdit = async (id: string) => {
    if (!editState.name.trim() || !editState.movieUrl.trim() || !editState.tvUrl.trim()) return;
    setSaving(true);
    await fetch(`/api/admin/players/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: editState.name.trim(),
        movieUrl: editState.movieUrl.trim(),
        tvUrl: editState.tvUrl.trim(),
        order: parseInt(editState.order) || 0,
      }),
    });
    setSaving(false);
    setEditingId(null);
    fetchPlayers();
  };

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: 32, display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <div>
          <h1 style={{ fontSize: 26, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", marginBottom: 4 }}>
            Players
          </h1>
          <p style={{ fontSize: 13, color: "rgba(255,255,255,0.35)" }}>
            Manage player API sources for movies and TV shows. Use{" "}
            <code style={{ fontSize: 11, background: "rgba(124,58,237,0.2)", padding: "1px 5px", borderRadius: 4, color: "#c4b5fd" }}>
              {"{id}"}
            </code>
            ,{" "}
            <code style={{ fontSize: 11, background: "rgba(124,58,237,0.2)", padding: "1px 5px", borderRadius: 4, color: "#c4b5fd" }}>
              {"{season}"}
            </code>
            ,{" "}
            <code style={{ fontSize: 11, background: "rgba(124,58,237,0.2)", padding: "1px 5px", borderRadius: 4, color: "#c4b5fd" }}>
              {"{episode}"}
            </code>{" "}
            as placeholders in URLs.
          </p>
        </div>
        <button
          onClick={() => { setShowForm(true); setCreateError(""); }}
          style={{
            display: "flex", alignItems: "center", gap: 7,
            padding: "9px 18px",
            borderRadius: 9,
            background: "rgba(124,58,237,0.85)",
            border: "1px solid rgba(124,58,237,0.6)",
            color: "#fff",
            fontSize: 13, fontWeight: 700,
            cursor: "pointer",
            flexShrink: 0,
          }}
        >
          <Plus size={14} />
          Add Player
        </button>
      </div>

      {/* Create form */}
      {showForm && (
        <div style={{
          padding: "24px",
          borderRadius: 14,
          background: "rgba(124,58,237,0.06)",
          border: "1px solid rgba(124,58,237,0.28)",
          marginBottom: 32,
        }}>
          <h2 style={{ fontSize: 14, fontWeight: 700, color: "#c4b5fd", marginBottom: 20 }}>New Player</h2>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
            <div>
              <label style={labelStyle}>Name</label>
              <input
                placeholder="e.g. VidFast"
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                style={inputStyle}
              />
            </div>
            <div>
              <label style={labelStyle}>Order (sort priority)</label>
              <input
                type="number"
                placeholder="0"
                value={form.order}
                onChange={(e) => setForm((f) => ({ ...f, order: e.target.value }))}
                style={inputStyle}
              />
            </div>
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={labelStyle}>Movie URL Template</label>
            <input
              placeholder="https://example.com/movie/{id}"
              value={form.movieUrl}
              onChange={(e) => setForm((f) => ({ ...f, movieUrl: e.target.value }))}
              style={inputStyle}
            />
          </div>

          <div style={{ marginBottom: 20 }}>
            <label style={labelStyle}>TV URL Template</label>
            <input
              placeholder="https://example.com/tv/{id}/{season}/{episode}"
              value={form.tvUrl}
              onChange={(e) => setForm((f) => ({ ...f, tvUrl: e.target.value }))}
              style={inputStyle}
            />
          </div>

          {createError && (
            <p style={{ fontSize: 12, color: "#f87171", marginBottom: 12 }}>{createError}</p>
          )}

          <div style={{ display: "flex", gap: 10 }}>
            <button
              onClick={handleCreate}
              disabled={creating}
              style={{
                padding: "8px 18px",
                borderRadius: 8,
                background: "rgba(124,58,237,0.85)",
                border: "1px solid rgba(124,58,237,0.6)",
                color: "#fff",
                fontSize: 13, fontWeight: 700,
                cursor: creating ? "not-allowed" : "pointer",
                opacity: creating ? 0.6 : 1,
              }}
            >
              {creating ? "Creating…" : "Create Player"}
            </button>
            <button
              onClick={() => { setShowForm(false); setCreateError(""); }}
              style={{
                padding: "8px 18px",
                borderRadius: 8,
                background: "transparent",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "rgba(255,255,255,0.5)",
                fontSize: 13, fontWeight: 600,
                cursor: "pointer",
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Players list */}
      {loading ? (
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.3)", padding: "40px 0", textAlign: "center" }}>Loading…</p>
      ) : players.length === 0 ? (
        <div style={{
          padding: "64px 24px",
          textAlign: "center",
          borderRadius: 14,
          border: "1px dashed rgba(255,255,255,0.1)",
        }}>
          <p style={{ fontSize: 14, color: "rgba(255,255,255,0.25)", marginBottom: 8 }}>No players configured yet.</p>
          <p style={{ fontSize: 12, color: "rgba(255,255,255,0.15)" }}>
            Add your first player API to enable the video player on movie and TV pages.
          </p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {players.map((p) => (
            <div
              key={p.id}
              style={{
                padding: "18px 20px",
                borderRadius: 12,
                background: "rgba(255,255,255,0.03)",
                border: p.isDefault
                  ? "1px solid rgba(124,58,237,0.4)"
                  : "1px solid rgba(255,255,255,0.07)",
                opacity: p.active ? 1 : 0.5,
              }}
            >
              {editingId === p.id ? (
                /* ── Inline edit mode ── */
                <div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                    <div>
                      <label style={labelStyle}>Name</label>
                      <input
                        value={editState.name}
                        onChange={(e) => setEditState((s) => ({ ...s, name: e.target.value }))}
                        style={inputStyle}
                      />
                    </div>
                    <div>
                      <label style={labelStyle}>Order</label>
                      <input
                        type="number"
                        value={editState.order}
                        onChange={(e) => setEditState((s) => ({ ...s, order: e.target.value }))}
                        style={inputStyle}
                      />
                    </div>
                  </div>
                  <div style={{ marginBottom: 12 }}>
                    <label style={labelStyle}>Movie URL Template</label>
                    <input
                      value={editState.movieUrl}
                      onChange={(e) => setEditState((s) => ({ ...s, movieUrl: e.target.value }))}
                      style={inputStyle}
                    />
                  </div>
                  <div style={{ marginBottom: 16 }}>
                    <label style={labelStyle}>TV URL Template</label>
                    <input
                      value={editState.tvUrl}
                      onChange={(e) => setEditState((s) => ({ ...s, tvUrl: e.target.value }))}
                      style={inputStyle}
                    />
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      onClick={() => saveEdit(p.id)}
                      disabled={saving}
                      style={{
                        display: "flex", alignItems: "center", gap: 5,
                        padding: "6px 14px", borderRadius: 7,
                        background: "rgba(52,211,153,0.15)",
                        border: "1px solid rgba(52,211,153,0.3)",
                        color: "#34d399", fontSize: 12, fontWeight: 700,
                        cursor: "pointer",
                      }}
                    >
                      <Check size={12} />
                      {saving ? "Saving…" : "Save"}
                    </button>
                    <button
                      onClick={cancelEdit}
                      style={{
                        display: "flex", alignItems: "center", gap: 5,
                        padding: "6px 14px", borderRadius: 7,
                        background: "transparent",
                        border: "1px solid rgba(255,255,255,0.1)",
                        color: "rgba(255,255,255,0.4)", fontSize: 12, fontWeight: 600,
                        cursor: "pointer",
                      }}
                    >
                      <X size={12} />
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                /* ── View mode ── */
                <div style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                      <span style={{ fontSize: 15, fontWeight: 700, color: "#e2d9f3" }}>{p.name}</span>
                      {p.isDefault && (
                        <span style={{
                          fontSize: 10, fontWeight: 800, color: "#a78bfa",
                          background: "rgba(124,58,237,0.18)", border: "1px solid rgba(124,58,237,0.35)",
                          padding: "2px 8px", borderRadius: 10, letterSpacing: "0.06em",
                        }}>
                          DEFAULT
                        </span>
                      )}
                      {!p.active && (
                        <span style={{
                          fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.35)",
                          background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
                          padding: "2px 8px", borderRadius: 10,
                        }}>
                          INACTIVE
                        </span>
                      )}
                      <span style={{ fontSize: 10, color: "rgba(255,255,255,0.25)" }}>order: {p.order}</span>
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                      <div style={{ display: "flex", gap: 8, alignItems: "baseline" }}>
                        <span style={{ fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.25)", minWidth: 42, textTransform: "uppercase", letterSpacing: "0.06em" }}>Movie</span>
                        <code style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", wordBreak: "break-all" }}>{p.movieUrl}</code>
                      </div>
                      <div style={{ display: "flex", gap: 8, alignItems: "baseline" }}>
                        <span style={{ fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.25)", minWidth: 42, textTransform: "uppercase", letterSpacing: "0.06em" }}>TV</span>
                        <code style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", wordBreak: "break-all" }}>{p.tvUrl}</code>
                      </div>
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                    {/* Edit */}
                    <button
                      onClick={() => startEdit(p)}
                      title="Edit"
                      style={iconBtnStyle}
                    >
                      <Edit2 size={13} />
                    </button>

                    {/* Toggle active */}
                    <button
                      onClick={() => patch(p.id, { active: !p.active })}
                      title={p.active ? "Deactivate" : "Activate"}
                      style={{ ...iconBtnStyle, color: p.active ? "#34d399" : "rgba(255,255,255,0.3)" }}
                    >
                      {p.active ? <Eye size={13} /> : <EyeOff size={13} />}
                    </button>

                    {/* Toggle default */}
                    <button
                      onClick={() => patch(p.id, { isDefault: !p.isDefault })}
                      title={p.isDefault ? "Remove default" : "Set as default"}
                      style={{ ...iconBtnStyle, color: p.isDefault ? "#a78bfa" : "rgba(255,255,255,0.3)" }}
                    >
                      {p.isDefault ? <Star size={13} /> : <StarOff size={13} />}
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => handleDelete(p.id)}
                      title="Delete"
                      style={{ ...iconBtnStyle, color: "rgba(248,113,113,0.7)" }}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Help text */}
      {players.length > 0 && (
        <div style={{
          marginTop: 28,
          padding: "16px 18px",
          borderRadius: 10,
          background: "rgba(255,255,255,0.02)",
          border: "1px solid rgba(255,255,255,0.06)",
          fontSize: 12,
          color: "rgba(255,255,255,0.3)",
          lineHeight: 1.7,
        }}>
          <strong style={{ color: "rgba(255,255,255,0.5)" }}>URL Placeholders:</strong>{" "}
          <code style={{ color: "#c4b5fd" }}>{"{id}"}</code> — TMDB movie/show ID &nbsp;·&nbsp;
          <code style={{ color: "#c4b5fd" }}>{"{season}"}</code> — season number &nbsp;·&nbsp;
          <code style={{ color: "#c4b5fd" }}>{"{episode}"}</code> — episode number<br />
          The <strong style={{ color: "rgba(255,255,255,0.5)" }}>default</strong> player is shown first in the switcher.
          Inactive players are hidden from the public-facing player.
        </div>
      )}
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: 11,
  fontWeight: 600,
  color: "rgba(255,255,255,0.4)",
  letterSpacing: "0.06em",
  textTransform: "uppercase",
  marginBottom: 5,
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  padding: "9px 12px",
  borderRadius: 8,
  background: "rgba(255,255,255,0.05)",
  border: "1px solid rgba(255,255,255,0.1)",
  color: "#fff",
  fontSize: 13,
  outline: "none",
  fontFamily: "inherit",
};

const iconBtnStyle: React.CSSProperties = {
  width: 30,
  height: 30,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  borderRadius: 7,
  background: "rgba(255,255,255,0.04)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "rgba(255,255,255,0.45)",
  cursor: "pointer",
  transition: "all 0.15s ease",
};
