"use client";

import { useEffect, useState, useCallback } from "react";
import { Send, Bell, Users, User, Trash2, ChevronDown, ChevronUp } from "lucide-react";

interface SentNotification {
  id: string;
  title: string;
  message: string;
  createdAt: string;
  user: { username: string };
}

interface UserOption {
  id: string;
  username: string;
  email: string;
}

function AdminNotificationRow({
  n,
  onDelete,
  index,
}: {
  n: SentNotification;
  onDelete: (id: string) => void;
  index: number;
}) {
  const [expanded, setExpanded] = useState(false);
  const isLong = n.message.length > 80;

  return (
    <tr
      style={{
        borderTop: "1px solid rgba(255,255,255,0.05)",
        background: index % 2 === 0 ? "transparent" : "rgba(255,255,255,0.015)",
      }}
    >
      <td style={{ padding: "12px 16px", fontSize: 13, fontWeight: 600, color: "#c4b5fd", verticalAlign: "top" }}>
        @{n.user.username}
      </td>
      <td style={{ padding: "12px 16px", fontSize: 13, color: "#e2d9f3", maxWidth: 200, verticalAlign: "top", wordBreak: "break-word" }}>
        {n.title}
      </td>
      <td style={{ padding: "12px 16px", fontSize: 12, color: "rgba(255,255,255,0.45)", maxWidth: 320, verticalAlign: "top" }}>
        <div style={{ whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
          {expanded ? n.message : isLong ? `${n.message.substring(0, 80)}...` : n.message}
        </div>
        {isLong && (
          <button
            onClick={() => setExpanded(!expanded)}
            style={{
              background: "none", border: "none", padding: 0,
              fontSize: 11, color: "#a78bfa", cursor: "pointer",
              marginTop: 6, display: "flex", alignItems: "center", gap: 3, fontWeight: 600
            }}
          >
            {expanded ? (
              <>Show Less <ChevronUp size={12} /></>
            ) : (
              <>Show More <ChevronDown size={12} /></>
            )}
          </button>
        )}
      </td>
      <td style={{ padding: "12px 16px", fontSize: 12, color: "rgba(255,255,255,0.35)", whiteSpace: "nowrap", verticalAlign: "top" }}>
        {new Date(n.createdAt).toLocaleString("en-US", {
          month: "short", day: "numeric", year: "numeric",
          hour: "numeric", minute: "2-digit",
        })}
      </td>
      <td style={{ padding: "12px 16px", verticalAlign: "top", textAlign: "right" }}>
        <button
          onClick={() => onDelete(n.id)}
          title="Delete Notification"
          style={{
            background: "transparent",
            border: "none",
            color: "rgba(239,68,68,0.4)",
            cursor: "pointer",
            padding: 4,
            borderRadius: 4,
          }}
          className="hover:bg-red-500/10 hover:text-red-400 transition-colors"
        >
          <Trash2 size={13} />
        </button>
      </td>
    </tr>
  );
}

export default function AdminNotificationsPage() {
  // Compose form
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [target, setTarget] = useState<"all" | "user">("all");
  const [selectedUserId, setSelectedUserId] = useState("");
  const [userSearch, setUserSearch] = useState("");
  const [userOptions, setUserOptions] = useState<UserOption[]>([]);
  const [sending, setSending] = useState(false);
  const [sendResult, setSendResult] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Sent notifications list
  const [notifications, setNotifications] = useState<SentNotification[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  const fetchNotifications = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/notifications?page=${page}`);
      const data = await res.json();
      setNotifications(data.notifications ?? []);
      setTotal(data.total ?? 0);
      setTotalPages(data.totalPages ?? 1);
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => { fetchNotifications(); }, [fetchNotifications]);

  // Search users for specific targeting
  useEffect(() => {
    if (target !== "user") return;
    const t = setTimeout(async () => {
      const params = new URLSearchParams({ page: "1" });
      if (userSearch) params.set("search", userSearch);
      const res = await fetch(`/api/admin/users?${params}`);
      const data = await res.json();
      setUserOptions(data.users ?? []);
    }, 250);
    return () => clearTimeout(t);
  }, [userSearch, target]);

  const handleSend = async () => {
    if (!title.trim() || !message.trim()) {
      setSendResult({ type: "error", text: "Title and message are required." });
      return;
    }
    if (target === "user" && !selectedUserId) {
      setSendResult({ type: "error", text: "Please select a user." });
      return;
    }

    setSending(true);
    setSendResult(null);
    try {
      const res = await fetch("/api/admin/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim(),
          message: message.trim(),
          userId: target === "user" ? selectedUserId : undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setSendResult({ type: "error", text: data.error ?? "Failed to send." });
      } else {
        setSendResult({ type: "success", text: `Sent to ${data.sent} user${data.sent !== 1 ? "s" : ""}.` });
        setTitle("");
        setMessage("");
        setSelectedUserId("");
        setUserSearch("");
        fetchNotifications();
      }
    } finally {
      setSending(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this notification?")) return;
    try {
      await fetch(`/api/admin/notifications?id=${id}`, { method: "DELETE" });
      fetchNotifications();
    } catch {
      // ignore
    }
  };

  const handleClearAll = async () => {
    if (!confirm("WARNING: This will permanently delete ALL sent notifications for ALL users. Are you absolutely sure?")) return;
    try {
      await fetch(`/api/admin/notifications?clearAll=true`, { method: "DELETE" });
      fetchNotifications();
    } catch {
      // ignore
    }
  };

  return (
    <div>
      <div style={{ marginBottom: 32 }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", marginBottom: 4 }}>
          Notifications
        </h1>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.35)" }}>
          Send notifications to individual users or everyone
        </p>
      </div>

      {/* Compose panel */}
      <div style={{
        padding: "28px 28px 24px",
        borderRadius: 16,
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.08)",
        marginBottom: 40,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 24 }}>
          <Bell size={16} style={{ color: "#a78bfa" }} />
          <h2 style={{ fontSize: 15, fontWeight: 700, color: "#fff" }}>Compose Notification</h2>
        </div>

        {/* Target toggle */}
        <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
          {(["all", "user"] as const).map((t) => (
            <button
              key={t}
              onClick={() => { setTarget(t); setSelectedUserId(""); setUserSearch(""); }}
              style={{
                display: "flex", alignItems: "center", gap: 6,
                padding: "7px 14px",
                borderRadius: 8,
                border: target === t ? "1px solid rgba(124,58,237,0.5)" : "1px solid rgba(255,255,255,0.1)",
                background: target === t ? "rgba(124,58,237,0.18)" : "transparent",
                color: target === t ? "#c4b5fd" : "rgba(255,255,255,0.45)",
                fontSize: 12, fontWeight: 600,
                cursor: "pointer",
                transition: "all 0.15s ease",
              }}
            >
              {t === "all" ? <Users size={13} /> : <User size={13} />}
              {t === "all" ? "All Users" : "Specific User"}
            </button>
          ))}
        </div>

        {/* User select (when target = user) */}
        {target === "user" && (
          <div style={{ marginBottom: 16 }}>
            <label style={labelStyle}>Search User</label>
            <input
              placeholder="Search by username or email…"
              value={userSearch}
              onChange={(e) => { setUserSearch(e.target.value); setSelectedUserId(""); }}
              style={inputStyle}
            />
            {userOptions.length > 0 && !selectedUserId && (
              <div style={{
                marginTop: 4,
                borderRadius: 8,
                border: "1px solid rgba(255,255,255,0.1)",
                background: "#0e1322",
                overflow: "hidden",
                maxHeight: 200,
                overflowY: "auto",
              }}>
                {userOptions.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => { setSelectedUserId(u.id); setUserSearch(`@${u.username}`); }}
                    style={{
                      display: "block", width: "100%", textAlign: "left",
                      padding: "9px 14px",
                      background: "transparent",
                      border: "none",
                      borderBottom: "1px solid rgba(255,255,255,0.05)",
                      color: "#e2d9f3",
                      cursor: "pointer",
                      fontSize: 13,
                    }}
                    className="hover:bg-white/5"
                  >
                    <span style={{ fontWeight: 600 }}>@{u.username}</span>
                    <span style={{ marginLeft: 8, fontSize: 11, color: "rgba(255,255,255,0.35)" }}>{u.email}</span>
                  </button>
                ))}
              </div>
            )}
            {selectedUserId && (
              <p style={{ fontSize: 11, color: "#34d399", marginTop: 6 }}>✓ User selected</p>
            )}
          </div>
        )}

        {/* Title */}
        <div style={{ marginBottom: 14 }}>
          <label style={labelStyle}>Title</label>
          <input
            placeholder="Notification title…"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            maxLength={120}
            style={inputStyle}
          />
        </div>

        {/* Message */}
        <div style={{ marginBottom: 20 }}>
          <label style={labelStyle}>Message</label>
          <textarea
            placeholder="Write your message…"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={4}
            style={{
              ...inputStyle,
              resize: "vertical",
              minHeight: 90,
              fontFamily: "inherit",
            }}
          />
        </div>

        {/* Send button + result */}
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <button
            onClick={handleSend}
            disabled={sending}
            style={{
              display: "flex", alignItems: "center", gap: 7,
              padding: "9px 20px",
              borderRadius: 9,
              background: sending ? "rgba(124,58,237,0.4)" : "rgba(124,58,237,0.85)",
              border: "1px solid rgba(124,58,237,0.6)",
              color: "#fff",
              fontSize: 13, fontWeight: 700,
              cursor: sending ? "not-allowed" : "pointer",
              transition: "all 0.15s ease",
            }}
          >
            <Send size={14} />
            {sending ? "Sending…" : "Send Notification"}
          </button>

          {sendResult && (
            <span style={{
              fontSize: 12,
              color: sendResult.type === "success" ? "#34d399" : "#f87171",
              fontWeight: 600,
            }}>
              {sendResult.text}
            </span>
          )}
        </div>
      </div>

      {/* Sent notifications list */}
      <div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <h2 style={{ fontSize: 15, fontWeight: 700, color: "#fff" }}>Sent Notifications</h2>
            <span style={{
              fontSize: 11, fontWeight: 700, color: "#a78bfa",
              background: "rgba(124,58,237,0.14)", border: "1px solid rgba(124,58,237,0.26)",
              padding: "2px 8px", borderRadius: 20,
            }}>
              {total}
            </span>
          </div>

          {total > 0 && (
            <button
              onClick={handleClearAll}
              style={{
                display: "flex", alignItems: "center", gap: 6,
                padding: "6px 12px",
                borderRadius: 8,
                background: "rgba(239,68,68,0.1)",
                border: "1px solid rgba(239,68,68,0.25)",
                color: "#f87171",
                fontSize: 12, fontWeight: 600,
                cursor: "pointer",
                transition: "all 0.15s ease",
              }}
              className="hover:bg-red-500/20"
            >
              <Trash2 size={13} />
              Clear All Sent
            </button>
          )}
        </div>

        <div style={{ borderRadius: 12, overflow: "hidden", border: "1px solid rgba(255,255,255,0.07)" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "rgba(255,255,255,0.04)" }}>
                {["Recipient", "Title", "Message", "Sent At", ""].map((h, i) => (
                  <th key={i} style={{ padding: "12px 16px", textAlign: h ? "left" : "right", fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.35)", letterSpacing: "0.08em", textTransform: "uppercase" }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={4} style={{ padding: "40px", textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: 13 }}>
                    Loading…
                  </td>
                </tr>
              ) : notifications.length === 0 ? (
                <tr>
                  <td colSpan={4} style={{ padding: "40px", textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: 13 }}>
                    No notifications sent yet.
                  </td>
                </tr>
              ) : (
                notifications.map((n, i) => (
                  <AdminNotificationRow key={n.id} n={n} index={i} onDelete={handleDelete} />
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 24 }}>
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              style={{ padding: "6px 14px", borderRadius: 7, border: "1px solid rgba(255,255,255,0.1)", background: "transparent", color: "rgba(255,255,255,0.55)", fontSize: 12, cursor: "pointer", opacity: page === 1 ? 0.4 : 1 }}
            >
              ← Prev
            </button>
            <span style={{ padding: "6px 12px", fontSize: 12, color: "rgba(255,255,255,0.4)" }}>
              {page} / {totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              style={{ padding: "6px 14px", borderRadius: 7, border: "1px solid rgba(255,255,255,0.1)", background: "transparent", color: "rgba(255,255,255,0.55)", fontSize: 12, cursor: "pointer", opacity: page === totalPages ? 0.4 : 1 }}
            >
              Next →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: 11,
  fontWeight: 600,
  color: "rgba(255,255,255,0.4)",
  letterSpacing: "0.06em",
  textTransform: "uppercase",
  marginBottom: 6,
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  padding: "9px 12px",
  borderRadius: 9,
  background: "rgba(255,255,255,0.05)",
  border: "1px solid rgba(255,255,255,0.1)",
  color: "#fff",
  fontSize: 13,
  outline: "none",
};
