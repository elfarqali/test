"use client";

import { useEffect, useState } from "react";
import { Save, CheckCircle } from "lucide-react";

interface Setting {
  key: string;
  value: string;
  label: string | null;
  description: string | null;
}

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<Setting[]>([]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((r) => r.json())
      .then((data) => {
        const s: Setting[] = data.settings ?? [];
        setSettings(s);
        const init: Record<string, string> = {};
        s.forEach((x) => (init[x.key] = x.value));
        setValues(init);
      })
      .finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    setError("");
    setSaved(false);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!res.ok) throw new Error("Failed to save.");
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch {
      setError("Failed to save settings.");
    } finally {
      setSaving(false);
    }
  };

  const renderControl = (s: Setting) => {
    const val = values[s.key] ?? s.value;

    if (s.key === "maintenance_mode" || s.key === "allow_registration") {
      const isOn = val === "true";
      return (
        <button
          onClick={() => setValues((v) => ({ ...v, [s.key]: isOn ? "false" : "true" }))}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            padding: "7px 16px",
            borderRadius: 8,
            border: isOn ? "1.5px solid rgba(124,58,237,0.4)" : "1px solid rgba(255,255,255,0.1)",
            background: isOn ? "rgba(124,58,237,0.15)" : "rgba(255,255,255,0.04)",
            color: isOn ? "#c4b5fd" : "rgba(255,255,255,0.45)",
            fontSize: 13,
            fontWeight: 600,
            cursor: "pointer",
            transition: "all 0.15s ease",
          }}
        >
          <span
            style={{
              width: 32, height: 18, borderRadius: 9,
              background: isOn ? "#7c3aed" : "rgba(255,255,255,0.12)",
              position: "relative",
              display: "inline-block",
              transition: "background 0.2s ease",
              flexShrink: 0,
            }}
          >
            <span
              style={{
                position: "absolute",
                top: 3, left: isOn ? 16 : 3,
                width: 12, height: 12, borderRadius: "50%",
                background: "#fff",
                transition: "left 0.2s ease",
              }}
            />
          </span>
          {isOn ? "Enabled" : "Disabled"}
        </button>
      );
    }

    return (
      <input
        value={val}
        onChange={(e) => setValues((v) => ({ ...v, [s.key]: e.target.value }))}
        style={{
          padding: "9px 14px",
          borderRadius: 9,
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.1)",
          color: "#fff",
          fontSize: 14,
          outline: "none",
          width: "100%",
          maxWidth: 360,
          boxSizing: "border-box",
        }}
      />
    );
  };

  return (
    <div>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 36, flexWrap: "wrap", gap: 16 }}>
        <div>
          <h1 style={{ fontSize: 26, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", marginBottom: 4 }}>
            Settings
          </h1>
          <p style={{ fontSize: 13, color: "rgba(255,255,255,0.35)" }}>
            Configure your platform
          </p>
        </div>

        <button
          onClick={handleSave}
          disabled={saving}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 7,
            padding: "10px 22px",
            borderRadius: 10,
            border: "none",
            background: saved
              ? "rgba(52,211,153,0.2)"
              : "linear-gradient(135deg, #7c3aed 0%, #5b21b6 100%)",
            color: saved ? "#34d399" : "#fff",
            fontSize: 13,
            fontWeight: 700,
            cursor: saving ? "wait" : "pointer",
            transition: "all 0.15s ease",
            opacity: saving ? 0.7 : 1,
          }}
        >
          {saved ? <CheckCircle size={15} /> : <Save size={15} />}
          {saved ? "Saved!" : saving ? "Saving…" : "Save Changes"}
        </button>
      </div>

      {error && (
        <div style={{ marginBottom: 24, padding: "10px 14px", borderRadius: 8, background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.25)", color: "#fca5a5", fontSize: 13 }}>
          {error}
        </div>
      )}

      {loading ? (
        <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 13 }}>Loading settings…</p>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          {settings.map((s) => (
            <div
              key={s.key}
              style={{
                padding: "22px 24px",
                borderRadius: 14,
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.07)",
              }}
            >
              <div style={{ marginBottom: 12 }}>
                <p style={{ fontSize: 14, fontWeight: 700, color: "#e2d9f3", marginBottom: 4 }}>
                  {s.label ?? s.key}
                </p>
                {s.description && (
                  <p style={{ fontSize: 12, color: "rgba(255,255,255,0.35)" }}>{s.description}</p>
                )}
              </div>
              {renderControl(s)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
