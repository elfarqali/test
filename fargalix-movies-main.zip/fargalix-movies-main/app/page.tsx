import { Suspense } from "react";
import {
  getTrending,
  getTrendingMerged,
  getPopularMoviesMerged,
  getPopularSeriesMerged,
  getNowPlayingMerged,
  getTopRatedMoviesMerged,
  getTopRatedSeriesMerged,
} from "@/lib/tmdb";
import { HorizontalRow } from "@/components/horizontal-row";
import { HeroSection } from "@/components/hero-section";
import { KeepWatchingSection } from "@/components/keep-watching-section";
import { AdSlot } from "@/components/ad-slot";
import { getSiteName } from "@/lib/settings";

export async function generateMetadata() {
  const siteName = await getSiteName();

  const title = "Watch Free Movies & TV Series Online in High Quality";
  const description =
    "Stream your favorite movies and TV series online for free in HD. Enjoy unlimited streaming. Discover new releases and watch movies online now!";

  return {
    title: { absolute: title },
    description,
    openGraph: { title, description },
    twitter: { title, description },
  };
}

// FULLY STATIC — built once at deploy, never regenerated
export const dynamic = "force-static";
export const revalidate = false;

// Lower-priority rows streamed in after the fold
async function SecondaryRows() {
  const [popularMovies, popularSeries, topRatedMovies, topRatedSeries] =
    await Promise.all([
      getPopularMoviesMerged(),
      getPopularSeriesMerged(),
      getTopRatedMoviesMerged(),
      getTopRatedSeriesMerged(),
    ]);

  return (
    <>
      <HorizontalRow title="Popular Movies" items={popularMovies} showType={false} />
      <HorizontalRow title="Recently Added Series" items={popularSeries} showType={false} />
      <HorizontalRow title="Top Rated Movies" items={topRatedMovies} showType={false} />
      <HorizontalRow title="Top Rated Series" items={topRatedSeries} showType={false} />
    </>
  );
}

export default async function HomePage() {
  const [trendingHero, trendingAll, nowPlaying] = await Promise.all([
    getTrending(1),
    getTrendingMerged(),
    getNowPlayingMerged(),
  ]);

  const heroItems = trendingHero.results
    .filter((i) => i.media_type !== "person" && i.backdrop_path)
    .slice(0, 10);

  const siteName = await getSiteName();

  return (
    <div style={{ backgroundColor: "#0b0f1a", minHeight: "100vh" }}>
      <HeroSection items={heroItems} />

      {/* Ad — Top of home page content */}
      <AdSlot placement="HOME_PAGE" position="TOP" style={{ padding: "0 16px" }} />

      {/* Shows last titles the user actually opened — reads from localStorage */}
      <KeepWatchingSection />

      <HorizontalRow title="Trending Today" items={trendingAll} showType={true} />
      <HorizontalRow title="Recently Added Movies" items={nowPlaying} showType={false} />

      {/* Lower-priority rows stream in after above-the-fold content is interactive */}
      <Suspense fallback={null}>
        <SecondaryRows />
      </Suspense>

      {/* Ad — Bottom of home page */}
      <AdSlot placement="HOME_PAGE" position="BOTTOM" style={{ padding: "24px 16px 0" }} />

      <footer style={{ marginTop: 40, paddingBottom: 32, textAlign: "center" }}>
        <p style={{ fontSize: 14, fontWeight: 900, textTransform: "uppercase", letterSpacing: "0.2em", color: "#ffffff", marginBottom: 4 }}>
          {siteName.toUpperCase()}
        </p>
        <p style={{ fontSize: 10, color: "#444" }}>Powered by TMDB &nbsp;&bull;&nbsp; All rights reserved</p>
      </footer>
    </div>
  );
}
