import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/navbar";
import { AuthProvider } from "@/components/auth/auth-provider";
import { Analytics } from "@vercel/analytics/react";
import { AdSlot } from "@/components/ad-slot";

const inter = Inter({ subsets: ["latin"], variable: "--font-sans", display: "swap" });

import { getSiteName } from "@/lib/settings";

export async function generateMetadata(): Promise<Metadata> {
  const siteName = await getSiteName();
  return {
    metadataBase: new URL("https://sixflix.blog"),
    title: {
      template: `%s - ${siteName}`,
      default: `${siteName} - Watch Trending Movies & Series`,
    },
    description: "Discover trending movies, popular films, and hit TV series powered by TMDB.",
    openGraph: {
      type: "website",
      siteName: siteName,
      title: `${siteName} - Watch Trending Movies & Series`,
      description: "Discover trending movies, popular films, and hit TV series powered by TMDB.",
    },
    twitter: {
      card: "summary_large_image",
      title: `${siteName} - Watch Trending Movies & Series`,
    },
    icons: {
      icon: '/favicon.ico?v=3',
    },
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const siteName = await getSiteName();

  return (
    <html lang="en" className={`${inter.variable} dark`} suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground min-h-screen" suppressHydrationWarning>
        <AuthProvider>
          {/* Ad — Header placement */}
          <AdSlot placement="HEADER" position="TOP" />
          <Navbar siteName={siteName} />
          <main style={{ paddingTop: 58 }}>{children}</main>
          {/* Ad — Footer placement */}
          <AdSlot placement="FOOTER" position="BOTTOM" style={{ textAlign: "center", padding: "12px 0" }} />
        </AuthProvider>
        <Analytics />
      </body>
    </html>
  );
}
