import { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
    return {
        rules: [
            {
                userAgent: "*",
                allow: ["/", "/movie/", "/tv/", "/movies", "/trending", "/popular", "/search"],
                disallow: [
                    "/api/",      // Never crawl API routes — saves DB queries
                    "/admin/",
                    "/settings/",
                    "/profile/",
                    "/history/",
                    "/discussions/",
                    "/live/",
                ],
            },
            {
                // Block AI training / scraping / SEO bots entirely
                userAgent: [
                    "GPTBot",
                    "Claude-Web",
                    "ClaudeBot",
                    "Claude-SearchBot",
                    "anthropic-ai",
                    "CCBot",
                    "Bytespider",
                    "ChatGPT-User",
                    "SemrushBot",
                    "AhrefsBot",
                    "DotBot",
                    "PetalBot",
                    "MJ12bot",
                    "DataForSeoBot",
                    "BLEXBot",
                ],
                disallow: "/",
            },
        ],
        sitemap: "https://sixflix.blog/sitemap.xml",
    };
}
