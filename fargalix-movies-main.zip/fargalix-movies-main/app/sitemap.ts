import { MetadataRoute } from "next";
import { getTrendingMerged, getPopularMoviesMerged, getPopularSeriesMerged } from "@/lib/tmdb";

// Rebuild sitemap once per day — crawlers hit this frequently
export const revalidate = 86400;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
    const BASE_URL = "https://sixflix.blog";

    // Static pages
    const staticRoutes: MetadataRoute.Sitemap = [
        { url: `${BASE_URL}/`, lastModified: new Date(), changeFrequency: "daily", priority: 1.0 },
        { url: `${BASE_URL}/movies`, lastModified: new Date(), changeFrequency: "daily", priority: 0.9 },
        { url: `${BASE_URL}/series`, lastModified: new Date(), changeFrequency: "daily", priority: 0.9 },
        { url: `${BASE_URL}/popular`, lastModified: new Date(), changeFrequency: "daily", priority: 0.8 },
        { url: `${BASE_URL}/trending`, lastModified: new Date(), changeFrequency: "daily", priority: 0.8 },
        { url: `${BASE_URL}/discuss`, lastModified: new Date(), changeFrequency: "always", priority: 0.7 },
    ];

    // Dynamic media pages (Trending & Popular)
    const [trending, popMovies, popSeries] = await Promise.all([
        getTrendingMerged(),
        getPopularMoviesMerged(),
        getPopularSeriesMerged()
    ]);

    const allMedia = [...trending, ...popMovies, ...popSeries];

    // Deduplicate
    const seenIds = new Set<string>();

    const dynamicRoutes: MetadataRoute.Sitemap = allMedia.reduce<MetadataRoute.Sitemap>((acc, item) => {
        const type = item.media_type === "tv" || item.name ? "tv" : "movie";

        const uniqueKey = `${type}-${item.id}`;
        if (!seenIds.has(uniqueKey)) {
            seenIds.add(uniqueKey);
            acc.push({
                url: `${BASE_URL}/${type}/${item.id}`,
                lastModified: new Date(),
                changeFrequency: "weekly",
                priority: 0.6
            });
        }
        return acc;
    }, []);

    return [...staticRoutes, ...dynamicRoutes];
}
